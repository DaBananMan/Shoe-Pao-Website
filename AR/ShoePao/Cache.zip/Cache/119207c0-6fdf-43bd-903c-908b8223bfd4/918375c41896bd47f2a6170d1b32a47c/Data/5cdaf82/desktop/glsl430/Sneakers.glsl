#version 430
//#include <required.glsl> // [HACK 4/6/2023] See SCC shader_merger.cpp
// SCC_BACKEND_SHADER_FLAGS_BEGIN__
// NGS_FLAG_IS_NORMAL_MAP normalTex
// NGS_FLAG_IS_NORMAL_MAP Tweak_N13
// NGS_FLAG_IS_NORMAL_MAP Tweak_N17
// NGS_FLAG_IS_NORMAL_MAP Tweak_N20
// SCC_BACKEND_SHADER_FLAGS_END__
//SG_REFLECTION_BEGIN(200)
//attribute vec4 boneData 5
//attribute vec3 blendShape0Pos 6
//attribute vec3 blendShape0Normal 12
//attribute vec3 blendShape1Pos 7
//attribute vec3 blendShape1Normal 13
//attribute vec3 blendShape2Pos 8
//attribute vec3 blendShape2Normal 14
//attribute vec3 blendShape3Pos 9
//attribute vec3 blendShape4Pos 10
//attribute vec3 blendShape5Pos 11
//attribute vec4 position 0
//attribute vec3 normal 1
//attribute vec4 tangent 2
//attribute vec2 texture0 3
//attribute vec2 texture1 4
//attribute vec4 color 18
//attribute vec3 positionNext 15
//attribute vec3 positionPrevious 16
//attribute vec4 strandProperties 17
//output vec4 sc_FragData0 0
//output uvec4 sc_RayTracingPositionAndMask 0
//output uvec4 sc_RayTracingNormalAndMore 1
//sampler sampler Tweak_N10SmpSC 0:31
//sampler sampler Tweak_N13SmpSC 0:32
//sampler sampler Tweak_N17SmpSC 0:33
//sampler sampler Tweak_N20SmpSC 0:34
//sampler sampler baseTexSmpSC 0:35
//sampler sampler intensityTextureSmpSC 0:36
//sampler sampler materialParamsTexSmpSC 0:37
//sampler sampler normalTexSmpSC 0:38
//sampler sampler sc_EnvmapDiffuseSmpSC 0:39
//sampler sampler sc_EnvmapSpecularSmpSC 0:40
//sampler sampler sc_OITCommonSampler 0:41
//sampler sampler sc_RayTracingGlobalIlluminationSmpSC 0:42
//sampler sampler sc_RayTracingHitCasterIdAndBarycentricSmpSC 0:43
//sampler sampler sc_RayTracingRayDirectionSmpSC 0:44
//sampler sampler sc_RayTracingReflectionsSmpSC 0:45
//sampler sampler sc_RayTracingShadowsSmpSC 0:46
//sampler sampler sc_SSAOTextureSmpSC 0:47
//sampler sampler sc_ScreenTextureSmpSC 0:48
//sampler sampler sc_ShadowTextureSmpSC 0:49
//texture texture2D Tweak_N10 0:3:0:31
//texture texture2D Tweak_N13 0:4:0:32
//texture texture2D Tweak_N17 0:5:0:33
//texture texture2D Tweak_N20 0:6:0:34
//texture texture2D baseTex 0:7:0:35
//texture texture2D intensityTexture 0:8:0:36
//texture texture2D materialParamsTex 0:9:0:37
//texture texture2D normalTex 0:10:0:38
//texture texture2D sc_EnvmapDiffuse 0:11:0:39
//texture texture2D sc_EnvmapSpecular 0:12:0:40
//texture texture2D sc_OITAlpha0 0:13:0:41
//texture texture2D sc_OITAlpha1 0:14:0:41
//texture texture2D sc_OITDepthHigh0 0:15:0:41
//texture texture2D sc_OITDepthHigh1 0:16:0:41
//texture texture2D sc_OITDepthLow0 0:17:0:41
//texture texture2D sc_OITDepthLow1 0:18:0:41
//texture texture2D sc_OITFilteredDepthBoundsTexture 0:19:0:41
//texture texture2D sc_OITFrontDepthTexture 0:20:0:41
//texture texture2D sc_RayTracingGlobalIllumination 0:21:0:42
//texture utexture2D sc_RayTracingHitCasterIdAndBarycentric 0:22:0:43
//texture texture2D sc_RayTracingRayDirection 0:23:0:44
//texture texture2D sc_RayTracingReflections 0:24:0:45
//texture texture2D sc_RayTracingShadows 0:25:0:46
//texture texture2D sc_SSAOTexture 0:26:0:47
//texture texture2D sc_ScreenTexture 0:27:0:48
//texture texture2D sc_ShadowTexture 0:28:0:49
//texture texture2DArray Tweak_N10ArrSC 0:52:0:31
//texture texture2DArray Tweak_N13ArrSC 0:53:0:32
//texture texture2DArray Tweak_N17ArrSC 0:54:0:33
//texture texture2DArray Tweak_N20ArrSC 0:55:0:34
//texture texture2DArray baseTexArrSC 0:56:0:35
//texture texture2DArray intensityTextureArrSC 0:57:0:36
//texture texture2DArray materialParamsTexArrSC 0:58:0:37
//texture texture2DArray normalTexArrSC 0:59:0:38
//texture texture2DArray sc_EnvmapDiffuseArrSC 0:60:0:39
//texture texture2DArray sc_EnvmapSpecularArrSC 0:61:0:40
//texture texture2DArray sc_RayTracingGlobalIlluminationArrSC 0:62:0:42
//texture texture2DArray sc_RayTracingReflectionsArrSC 0:64:0:45
//texture texture2DArray sc_RayTracingShadowsArrSC 0:65:0:46
//texture texture2DArray sc_ScreenTextureArrSC 0:66:0:48
//ssbo int sc_RayTracingCasterIndexBuffer 0:0:4 {
//uint sc_RayTracingCasterTriangles 0:[1]:4
//}
//ssbo float sc_RayTracingCasterNonAnimatedVertexBuffer 0:2:4 {
//float sc_RayTracingCasterNonAnimatedVertices 0:[1]:4
//}
//ssbo float sc_RayTracingCasterVertexBuffer 0:1:4 {
//float sc_RayTracingCasterVertices 0:[1]:4
//}
//spec_const bool BLEND_MODE_AVERAGE 0 0
//spec_const bool BLEND_MODE_BRIGHT 1 0
//spec_const bool BLEND_MODE_COLOR 2 0
//spec_const bool BLEND_MODE_COLOR_BURN 3 0
//spec_const bool BLEND_MODE_COLOR_DODGE 4 0
//spec_const bool BLEND_MODE_DARKEN 5 0
//spec_const bool BLEND_MODE_DIFFERENCE 6 0
//spec_const bool BLEND_MODE_DIVIDE 7 0
//spec_const bool BLEND_MODE_DIVISION 8 0
//spec_const bool BLEND_MODE_EXCLUSION 9 0
//spec_const bool BLEND_MODE_FORGRAY 10 0
//spec_const bool BLEND_MODE_HARD_GLOW 11 0
//spec_const bool BLEND_MODE_HARD_LIGHT 12 0
//spec_const bool BLEND_MODE_HARD_MIX 13 0
//spec_const bool BLEND_MODE_HARD_PHOENIX 14 0
//spec_const bool BLEND_MODE_HARD_REFLECT 15 0
//spec_const bool BLEND_MODE_HUE 16 0
//spec_const bool BLEND_MODE_INTENSE 17 0
//spec_const bool BLEND_MODE_LIGHTEN 18 0
//spec_const bool BLEND_MODE_LINEAR_LIGHT 19 0
//spec_const bool BLEND_MODE_LUMINOSITY 20 0
//spec_const bool BLEND_MODE_NEGATION 21 0
//spec_const bool BLEND_MODE_NOTBRIGHT 22 0
//spec_const bool BLEND_MODE_OVERLAY 23 0
//spec_const bool BLEND_MODE_PIN_LIGHT 24 0
//spec_const bool BLEND_MODE_REALISTIC 25 0
//spec_const bool BLEND_MODE_SATURATION 26 0
//spec_const bool BLEND_MODE_SOFT_LIGHT 27 0
//spec_const bool BLEND_MODE_SUBTRACT 28 0
//spec_const bool BLEND_MODE_VIVID_LIGHT 29 0
//spec_const bool ENABLE_STIPPLE_PATTERN_TEST 30 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_Tweak_N10 31 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_Tweak_N13 32 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_Tweak_N17 33 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_Tweak_N20 34 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_baseTex 35 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_intensityTexture 36 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_materialParamsTex 37 0
//spec_const bool SC_USE_CLAMP_TO_BORDER_normalTex 38 0
//spec_const bool SC_USE_UV_MIN_MAX_Tweak_N10 39 0
//spec_const bool SC_USE_UV_MIN_MAX_Tweak_N13 40 0
//spec_const bool SC_USE_UV_MIN_MAX_Tweak_N17 41 0
//spec_const bool SC_USE_UV_MIN_MAX_Tweak_N20 42 0
//spec_const bool SC_USE_UV_MIN_MAX_baseTex 43 0
//spec_const bool SC_USE_UV_MIN_MAX_intensityTexture 44 0
//spec_const bool SC_USE_UV_MIN_MAX_materialParamsTex 45 0
//spec_const bool SC_USE_UV_MIN_MAX_normalTex 46 0
//spec_const bool SC_USE_UV_TRANSFORM_Tweak_N10 47 0
//spec_const bool SC_USE_UV_TRANSFORM_Tweak_N13 48 0
//spec_const bool SC_USE_UV_TRANSFORM_Tweak_N17 49 0
//spec_const bool SC_USE_UV_TRANSFORM_Tweak_N20 50 0
//spec_const bool SC_USE_UV_TRANSFORM_baseTex 51 0
//spec_const bool SC_USE_UV_TRANSFORM_intensityTexture 52 0
//spec_const bool SC_USE_UV_TRANSFORM_materialParamsTex 53 0
//spec_const bool SC_USE_UV_TRANSFORM_normalTex 54 0
//spec_const bool Tweak_N10HasSwappedViews 55 0
//spec_const bool Tweak_N13HasSwappedViews 56 0
//spec_const bool Tweak_N17HasSwappedViews 57 0
//spec_const bool Tweak_N20HasSwappedViews 58 0
//spec_const bool UseViewSpaceDepthVariant 59 1
//spec_const bool baseTexHasSwappedViews 60 0
//spec_const bool intensityTextureHasSwappedViews 61 0
//spec_const bool materialParamsTexHasSwappedViews 62 0
//spec_const bool normalTexHasSwappedViews 63 0
//spec_const bool sc_BlendMode_Add 64 0
//spec_const bool sc_BlendMode_AddWithAlphaFactor 65 0
//spec_const bool sc_BlendMode_AlphaTest 66 0
//spec_const bool sc_BlendMode_AlphaToCoverage 67 0
//spec_const bool sc_BlendMode_ColoredGlass 68 0
//spec_const bool sc_BlendMode_Custom 69 0
//spec_const bool sc_BlendMode_Max 70 0
//spec_const bool sc_BlendMode_Min 71 0
//spec_const bool sc_BlendMode_Multiply 72 0
//spec_const bool sc_BlendMode_MultiplyOriginal 73 0
//spec_const bool sc_BlendMode_Normal 74 0
//spec_const bool sc_BlendMode_PremultipliedAlpha 75 0
//spec_const bool sc_BlendMode_PremultipliedAlphaAuto 76 0
//spec_const bool sc_BlendMode_PremultipliedAlphaHardware 77 0
//spec_const bool sc_BlendMode_Screen 78 0
//spec_const bool sc_DepthOnly 79 0
//spec_const bool sc_EnvmapDiffuseHasSwappedViews 80 0
//spec_const bool sc_EnvmapSpecularHasSwappedViews 81 0
//spec_const bool sc_FramebufferFetch 82 0
//spec_const bool sc_HasDiffuseEnvmap 83 0
//spec_const bool sc_IsEditor 84 0
//spec_const bool sc_LightEstimation 85 0
//spec_const bool sc_MotionVectorsPass 86 0
//spec_const bool sc_OITCompositingPass 87 0
//spec_const bool sc_OITDepthBoundsPass 88 0
//spec_const bool sc_OITDepthGatherPass 89 0
//spec_const bool sc_OITDepthPrepass 90 0
//spec_const bool sc_OITFrontLayerPass 91 0
//spec_const bool sc_OITMaxLayers4Plus1 92 0
//spec_const bool sc_OITMaxLayers8 93 0
//spec_const bool sc_OITMaxLayersVisualizeLayerCount 94 0
//spec_const bool sc_OutputBounds 95 0
//spec_const bool sc_ProjectiveShadowsCaster 96 0
//spec_const bool sc_ProjectiveShadowsReceiver 97 0
//spec_const bool sc_RayTracingCasterForceOpaque 98 0
//spec_const bool sc_RayTracingGlobalIlluminationHasSwappedViews 99 0
//spec_const bool sc_RayTracingReflectionsHasSwappedViews 100 0
//spec_const bool sc_RayTracingShadowsHasSwappedViews 101 0
//spec_const bool sc_RenderAlphaToColor 102 0
//spec_const bool sc_SSAOEnabled 103 0
//spec_const bool sc_ScreenTextureHasSwappedViews 104 0
//spec_const bool sc_TAAEnabled 105 0
//spec_const bool sc_VertexBlending 106 0
//spec_const bool sc_VertexBlendingUseNormals 107 0
//spec_const bool sc_Voxelization 108 0
//spec_const int SC_DEVICE_CLASS 109 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_Tweak_N10 110 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_Tweak_N13 111 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_Tweak_N17 112 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_Tweak_N20 113 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_baseTex 114 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_intensityTexture 115 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_materialParamsTex 116 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_U_normalTex 117 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_Tweak_N10 118 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_Tweak_N13 119 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_Tweak_N17 120 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_Tweak_N20 121 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_baseTex 122 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_intensityTexture 123 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_materialParamsTex 124 -1
//spec_const int SC_SOFTWARE_WRAP_MODE_V_normalTex 125 -1
//spec_const int Tweak_N10Layout 126 0
//spec_const int Tweak_N13Layout 127 0
//spec_const int Tweak_N17Layout 128 0
//spec_const int Tweak_N20Layout 129 0
//spec_const int baseTexLayout 130 0
//spec_const int intensityTextureLayout 131 0
//spec_const int materialParamsTexLayout 132 0
//spec_const int normalTexLayout 133 0
//spec_const int sc_AmbientLightMode0 134 0
//spec_const int sc_AmbientLightMode1 135 0
//spec_const int sc_AmbientLightMode2 136 0
//spec_const int sc_AmbientLightMode_Constant 137 0
//spec_const int sc_AmbientLightMode_EnvironmentMap 138 0
//spec_const int sc_AmbientLightMode_FromCamera 139 0
//spec_const int sc_AmbientLightMode_SphericalHarmonics 140 0
//spec_const int sc_AmbientLightsCount 141 0
//spec_const int sc_DepthBufferMode 142 0
//spec_const int sc_DirectionalLightsCount 143 0
//spec_const int sc_EnvLightMode 144 0
//spec_const int sc_EnvmapDiffuseLayout 145 0
//spec_const int sc_EnvmapSpecularLayout 146 0
//spec_const int sc_LightEstimationSGCount 147 0
//spec_const int sc_PointLightsCount 148 0
//spec_const int sc_RayTracingGlobalIlluminationLayout 149 0
//spec_const int sc_RayTracingReflectionsLayout 150 0
//spec_const int sc_RayTracingShadowsLayout 151 0
//spec_const int sc_RenderingSpace 152 -1
//spec_const int sc_ScreenTextureLayout 153 0
//spec_const int sc_ShaderCacheConstant 154 0
//spec_const int sc_SkinBonesCount 155 0
//spec_const int sc_StereoRenderingMode 156 0
//spec_const int sc_StereoRendering_IsClipDistanceEnabled 157 0
//spec_const int sc_StereoViewID 158 0
//SG_REFLECTION_END
#define sc_StereoRendering_Disabled 0
#define sc_StereoRendering_InstancedClipped 1
#define sc_StereoRendering_Multiview 2
#ifdef VERTEX_SHADER
#define scOutPos(clipPosition) gl_Position=clipPosition
#define MAIN main
#endif
#ifdef SC_ENABLE_INSTANCED_RENDERING
#ifndef sc_EnableInstancing
#define sc_EnableInstancing 1
#endif
#endif
#define mod(x,y) (x-y*floor((x+1e-6)/y))
#if __VERSION__<300
#define isinf(x) (x!=0.0&&x*2.0==x ? true : false)
#define isnan(x) (x>0.0||x<0.0||x==0.0 ? false : true)
#define inverse(M) M
#endif
#ifdef sc_EnableStereoClipDistance
#if defined(GL_APPLE_clip_distance)
#extension GL_APPLE_clip_distance : require
#elif defined(GL_EXT_clip_cull_distance)
#extension GL_EXT_clip_cull_distance : require
#else
#error Clip distance is requested but not supported by this device.
#endif
#endif
#ifdef sc_EnableMultiviewStereoRendering
#define sc_StereoRenderingMode sc_StereoRendering_Multiview
#extension GL_OVR_multiview2 : require
#ifdef VERTEX_SHADER
#ifdef sc_EnableInstancingFallback
#define sc_GlobalInstanceID (sc_FallbackInstanceID*2+gl_InstanceID)
#else
#define sc_GlobalInstanceID gl_InstanceID
#endif
#define sc_LocalInstanceID sc_GlobalInstanceID
#define sc_StereoViewID int(gl_ViewID_OVR)
#endif
#elif defined(sc_EnableInstancedClippedStereoRendering)
#ifndef sc_EnableInstancing
#error Instanced-clipped stereo rendering requires enabled instancing.
#endif
#ifndef sc_EnableStereoClipDistance
#define sc_StereoRendering_IsClipDistanceEnabled 0
#else
#define sc_StereoRendering_IsClipDistanceEnabled 1
#endif
#define sc_StereoRenderingMode sc_StereoRendering_InstancedClipped
#define sc_NumStereoClipPlanes 1
#ifdef VERTEX_SHADER
#ifdef sc_EnableInstancingFallback
#define sc_GlobalInstanceID (sc_FallbackInstanceID*2+gl_InstanceID)
#else
#define sc_GlobalInstanceID gl_InstanceID
#endif
#define sc_LocalInstanceID (sc_GlobalInstanceID/2)
#define sc_StereoViewID (sc_GlobalInstanceID%2)
#endif
#else
#define sc_StereoRenderingMode sc_StereoRendering_Disabled
#endif
#if defined(sc_EnableInstancing)&&defined(VERTEX_SHADER)
#ifdef GL_ARB_draw_instanced
#extension GL_ARB_draw_instanced : require
#define gl_InstanceID gl_InstanceIDARB
#endif
#ifdef GL_EXT_draw_instanced
#extension GL_EXT_draw_instanced : require
#define gl_InstanceID gl_InstanceIDEXT
#endif
#ifndef sc_InstanceID
#define sc_InstanceID gl_InstanceID
#endif
#ifndef sc_GlobalInstanceID
#ifdef sc_EnableInstancingFallback
#define sc_GlobalInstanceID (sc_FallbackInstanceID)
#define sc_LocalInstanceID (sc_FallbackInstanceID)
#else
#define sc_GlobalInstanceID gl_InstanceID
#define sc_LocalInstanceID gl_InstanceID
#endif
#endif
#endif
#ifndef GL_ES
#extension GL_EXT_gpu_shader4 : enable
#extension GL_ARB_shader_texture_lod : enable
#define precision
#define lowp
#define mediump
#define highp
#define sc_FragmentPrecision
#endif
#ifdef GL_ES
#ifdef sc_FramebufferFetch
#if defined(GL_EXT_shader_framebuffer_fetch)
#extension GL_EXT_shader_framebuffer_fetch : require
#elif defined(GL_ARM_shader_framebuffer_fetch)
#extension GL_ARM_shader_framebuffer_fetch : require
#else
#error Framebuffer fetch is requested but not supported by this device.
#endif
#endif
#ifdef GL_FRAGMENT_PRECISION_HIGH
#define sc_FragmentPrecision highp
#else
#define sc_FragmentPrecision mediump
#endif
#ifdef FRAGMENT_SHADER
precision highp int;
precision highp float;
#endif
#endif
#ifdef VERTEX_SHADER
#ifdef sc_EnableMultiviewStereoRendering
layout(num_views=sc_NumStereoViews) in;
#endif
#endif
#define SC_INT_FALLBACK_FLOAT int
#define SC_INTERPOLATION_FLAT flat
#define SC_INTERPOLATION_CENTROID centroid
#ifndef sc_NumStereoViews
#define sc_NumStereoViews 1
#endif
#ifndef sc_TextureRenderingLayout_Regular
#define sc_TextureRenderingLayout_Regular 0
#define sc_TextureRenderingLayout_StereoInstancedClipped 1
#define sc_TextureRenderingLayout_StereoMultiview 2
#endif
#if defined VERTEX_SHADER
struct sc_Vertex_t
{
vec4 position;
vec3 normal;
vec3 tangent;
vec2 texture0;
vec2 texture1;
};
#ifndef sc_StereoRenderingMode
#define sc_StereoRenderingMode 0
#endif
#ifndef sc_StereoViewID
#define sc_StereoViewID 0
#endif
#ifndef sc_RenderingSpace
#define sc_RenderingSpace -1
#endif
#ifndef sc_TAAEnabled
#define sc_TAAEnabled 0
#elif sc_TAAEnabled==1
#undef sc_TAAEnabled
#define sc_TAAEnabled 1
#endif
#ifndef sc_MotionVectorsPass
#define sc_MotionVectorsPass 0
#elif sc_MotionVectorsPass==1
#undef sc_MotionVectorsPass
#define sc_MotionVectorsPass 1
#endif
#ifndef sc_NumStereoViews
#define sc_NumStereoViews 1
#endif
#ifndef sc_StereoRendering_IsClipDistanceEnabled
#define sc_StereoRendering_IsClipDistanceEnabled 0
#endif
#ifndef sc_ShaderCacheConstant
#define sc_ShaderCacheConstant 0
#endif
#ifndef sc_SkinBonesCount
#define sc_SkinBonesCount 0
#endif
#ifndef sc_VertexBlending
#define sc_VertexBlending 0
#elif sc_VertexBlending==1
#undef sc_VertexBlending
#define sc_VertexBlending 1
#endif
#ifndef sc_VertexBlendingUseNormals
#define sc_VertexBlendingUseNormals 0
#elif sc_VertexBlendingUseNormals==1
#undef sc_VertexBlendingUseNormals
#define sc_VertexBlendingUseNormals 1
#endif
#ifndef sc_DepthBufferMode
#define sc_DepthBufferMode 0
#endif
struct sc_Camera_t
{
vec3 position;
float aspect;
vec2 clipPlanes;
};
#ifndef sc_Voxelization
#define sc_Voxelization 0
#elif sc_Voxelization==1
#undef sc_Voxelization
#define sc_Voxelization 1
#endif
#ifndef UseViewSpaceDepthVariant
#define UseViewSpaceDepthVariant 1
#elif UseViewSpaceDepthVariant==1
#undef UseViewSpaceDepthVariant
#define UseViewSpaceDepthVariant 1
#endif
#ifndef sc_OITDepthGatherPass
#define sc_OITDepthGatherPass 0
#elif sc_OITDepthGatherPass==1
#undef sc_OITDepthGatherPass
#define sc_OITDepthGatherPass 1
#endif
#ifndef sc_OITCompositingPass
#define sc_OITCompositingPass 0
#elif sc_OITCompositingPass==1
#undef sc_OITCompositingPass
#define sc_OITCompositingPass 1
#endif
#ifndef sc_OITDepthBoundsPass
#define sc_OITDepthBoundsPass 0
#elif sc_OITDepthBoundsPass==1
#undef sc_OITDepthBoundsPass
#define sc_OITDepthBoundsPass 1
#endif
#ifndef sc_ProjectiveShadowsReceiver
#define sc_ProjectiveShadowsReceiver 0
#elif sc_ProjectiveShadowsReceiver==1
#undef sc_ProjectiveShadowsReceiver
#define sc_ProjectiveShadowsReceiver 1
#endif
#ifndef sc_OutputBounds
#define sc_OutputBounds 0
#elif sc_OutputBounds==1
#undef sc_OutputBounds
#define sc_OutputBounds 1
#endif
layout(binding=0,std430) readonly buffer sc_RayTracingCasterIndexBuffer
{
uint sc_RayTracingCasterTriangles[1];
} sc_RayTracingCasterIndexBuffer_obj;
layout(binding=1,std430) readonly buffer sc_RayTracingCasterVertexBuffer
{
float sc_RayTracingCasterVertices[1];
} sc_RayTracingCasterVertexBuffer_obj;
layout(binding=2,std430) readonly buffer sc_RayTracingCasterNonAnimatedVertexBuffer
{
float sc_RayTracingCasterNonAnimatedVertices[1];
} sc_RayTracingCasterNonAnimatedVertexBuffer_obj;
uniform mat4 sc_ModelMatrix;
uniform mat4 sc_ProjectorMatrix;
uniform vec2 sc_TAAJitterOffset;
uniform mat4 sc_ViewProjectionMatrixArray[sc_NumStereoViews];
uniform mat4 sc_PrevFrameViewProjectionMatrixArray[sc_NumStereoViews];
uniform mat4 sc_PrevFrameModelMatrix;
uniform mat4 sc_ModelMatrixInverse;
uniform int sc_FallbackInstanceID;
uniform vec4 sc_StereoClipPlanes[sc_NumStereoViews];
uniform vec4 sc_UniformConstants;
uniform vec4 sc_BoneMatrices[(sc_SkinBonesCount*3)+1];
uniform mat3 sc_SkinBonesNormalMatrices[sc_SkinBonesCount+1];
uniform vec4 weights0;
uniform vec4 weights1;
uniform mat4 sc_ProjectionMatrixInverseArray[sc_NumStereoViews];
uniform mat4 sc_ViewMatrixArray[sc_NumStereoViews];
uniform mat4 sc_ModelViewMatrixArray[sc_NumStereoViews];
uniform mat4 sc_ProjectionMatrixArray[sc_NumStereoViews];
uniform sc_Camera_t sc_Camera;
uniform vec4 voxelization_params_0;
uniform vec4 voxelization_params_frustum_lrbt;
uniform vec4 voxelization_params_frustum_nf;
uniform vec3 voxelization_params_camera_pos;
uniform mat4 sc_ModelMatrixVoxelization;
uniform mat3 sc_NormalMatrix;
uniform int PreviewEnabled;
uniform uvec4 sc_RayTracingCasterConfiguration;
uniform float depthRef;
out vec4 varPosAndMotion;
out vec4 varNormalAndMotion;
out float varClipDistance;
flat out int varStereoViewID;
in vec4 boneData;
in vec3 blendShape0Pos;
in vec3 blendShape0Normal;
in vec3 blendShape1Pos;
in vec3 blendShape1Normal;
in vec3 blendShape2Pos;
in vec3 blendShape2Normal;
in vec3 blendShape3Pos;
in vec3 blendShape4Pos;
in vec3 blendShape5Pos;
in vec4 position;
in vec3 normal;
in vec4 tangent;
in vec2 texture0;
in vec2 texture1;
out vec4 varScreenPos;
out vec4 varTex01;
out vec4 varTangent;
out vec4 varColor;
in vec4 color;
out float varViewSpaceDepth;
out vec2 varShadowTex;
out vec4 PreviewVertexColor;
out float PreviewVertexSaved;
out vec2 varScreenTexturePos;
in vec3 positionNext;
in vec3 positionPrevious;
in vec4 strandProperties;
void sc_SetClipDistancePlatform(float dstClipDistance)
{
#if sc_StereoRenderingMode==sc_StereoRendering_InstancedClipped&&sc_StereoRendering_IsClipDistanceEnabled
gl_ClipDistance[0]=dstClipDistance;
#endif
}
void sc_SetClipDistance(float dstClipDistance)
{
#if (sc_StereoRendering_IsClipDistanceEnabled==1)
{
sc_SetClipDistancePlatform(dstClipDistance);
}
#else
{
varClipDistance=dstClipDistance;
}
#endif
}
void sc_SetClipDistance(vec4 clipPosition)
{
#if (sc_StereoRenderingMode==1)
{
sc_SetClipDistance(dot(clipPosition,sc_StereoClipPlanes[sc_StereoViewID]));
}
#endif
}
void sc_SetClipPosition(vec4 clipPosition)
{
#if (sc_ShaderCacheConstant!=0)
{
clipPosition.x+=(sc_UniformConstants.x*float(sc_ShaderCacheConstant));
}
#endif
#if (sc_StereoRenderingMode>0)
{
varStereoViewID=sc_StereoViewID;
}
#endif
sc_SetClipDistance(clipPosition);
gl_Position=clipPosition;
}
int sc_GetLocalInstanceIDInternal(int id)
{
#ifdef sc_LocalInstanceID
return sc_LocalInstanceID;
#else
return 0;
#endif
}
void blendTargetShapeWithNormal(inout sc_Vertex_t v,vec3 position_1,vec3 normal_1,float weight)
{
vec3 l9_0=v.position.xyz+(position_1*weight);
v=sc_Vertex_t(vec4(l9_0.x,l9_0.y,l9_0.z,v.position.w),v.normal,v.tangent,v.texture0,v.texture1);
v.normal+=(normal_1*weight);
}
void sc_BlendVertex(inout sc_Vertex_t v)
{
#if (sc_VertexBlending)
{
#if (sc_VertexBlendingUseNormals)
{
blendTargetShapeWithNormal(v,blendShape0Pos,blendShape0Normal,weights0.x);
blendTargetShapeWithNormal(v,blendShape1Pos,blendShape1Normal,weights0.y);
blendTargetShapeWithNormal(v,blendShape2Pos,blendShape2Normal,weights0.z);
}
#else
{
vec3 l9_0=v.position.xyz+(blendShape0Pos*weights0.x);
v=sc_Vertex_t(vec4(l9_0.x,l9_0.y,l9_0.z,v.position.w),v.normal,v.tangent,v.texture0,v.texture1);
vec3 l9_1=v.position.xyz+(blendShape1Pos*weights0.y);
v=sc_Vertex_t(vec4(l9_1.x,l9_1.y,l9_1.z,v.position.w),v.normal,v.tangent,v.texture0,v.texture1);
vec3 l9_2=v.position.xyz+(blendShape2Pos*weights0.z);
v=sc_Vertex_t(vec4(l9_2.x,l9_2.y,l9_2.z,v.position.w),v.normal,v.tangent,v.texture0,v.texture1);
vec3 l9_3=v.position.xyz+(blendShape3Pos*weights0.w);
v=sc_Vertex_t(vec4(l9_3.x,l9_3.y,l9_3.z,v.position.w),v.normal,v.tangent,v.texture0,v.texture1);
vec3 l9_4=v.position.xyz+(blendShape4Pos*weights1.x);
v=sc_Vertex_t(vec4(l9_4.x,l9_4.y,l9_4.z,v.position.w),v.normal,v.tangent,v.texture0,v.texture1);
vec3 l9_5=v.position.xyz+(blendShape5Pos*weights1.y);
v=sc_Vertex_t(vec4(l9_5.x,l9_5.y,l9_5.z,v.position.w),v.normal,v.tangent,v.texture0,v.texture1);
}
#endif
}
#endif
}
vec4 sc_GetBoneWeights()
{
vec4 l9_0;
#if (sc_SkinBonesCount>0)
{
vec4 l9_1=vec4(1.0,fract(boneData.yzw));
vec4 l9_2=l9_1;
l9_2.x=1.0-dot(l9_1.yzw,vec3(1.0));
l9_0=l9_2;
}
#else
{
l9_0=vec4(0.0);
}
#endif
return l9_0;
}
void sc_GetBoneMatrix(int index,out vec4 m0,out vec4 m1,out vec4 m2)
{
int l9_0=3*index;
m0=sc_BoneMatrices[l9_0];
m1=sc_BoneMatrices[l9_0+1];
m2=sc_BoneMatrices[l9_0+2];
}
vec3 skinVertexPosition(int i,vec4 v)
{
vec3 l9_0;
#if (sc_SkinBonesCount>0)
{
vec4 param_1;
vec4 param_2;
vec4 param_3;
sc_GetBoneMatrix(i,param_1,param_2,param_3);
l9_0=vec3(dot(v,param_1),dot(v,param_2),dot(v,param_3));
}
#else
{
l9_0=v.xyz;
}
#endif
return l9_0;
}
void sc_SkinVertex(inout sc_Vertex_t v)
{
#if (sc_SkinBonesCount>0)
{
vec4 l9_0=sc_GetBoneWeights();
int l9_1=int(boneData.x);
int l9_2=int(boneData.y);
int l9_3=int(boneData.z);
int l9_4=int(boneData.w);
float l9_5=l9_0.x;
float l9_6=l9_0.y;
float l9_7=l9_0.z;
float l9_8=l9_0.w;
vec3 l9_9=(((skinVertexPosition(l9_1,v.position)*l9_5)+(skinVertexPosition(l9_2,v.position)*l9_6))+(skinVertexPosition(l9_3,v.position)*l9_7))+(skinVertexPosition(l9_4,v.position)*l9_8);
v.position=vec4(l9_9.x,l9_9.y,l9_9.z,v.position.w);
v.normal=((((sc_SkinBonesNormalMatrices[l9_1]*v.normal)*l9_5)+((sc_SkinBonesNormalMatrices[l9_2]*v.normal)*l9_6))+((sc_SkinBonesNormalMatrices[l9_3]*v.normal)*l9_7))+((sc_SkinBonesNormalMatrices[l9_4]*v.normal)*l9_8);
v.tangent=((((sc_SkinBonesNormalMatrices[l9_1]*v.tangent)*l9_5)+((sc_SkinBonesNormalMatrices[l9_2]*v.tangent)*l9_6))+((sc_SkinBonesNormalMatrices[l9_3]*v.tangent)*l9_7))+((sc_SkinBonesNormalMatrices[l9_4]*v.tangent)*l9_8);
}
#endif
}
int sc_GetStereoViewIndex()
{
int l9_0;
#if (sc_StereoRenderingMode==0)
{
l9_0=0;
}
#else
{
l9_0=sc_StereoViewID;
}
#endif
return l9_0;
}
mat4 createVoxelOrthoMatrix(float left,float right,float bottom,float top,float near,float far)
{
return mat4(vec4(2.0/(right-left),0.0,0.0,(-(right+left))/(right-left)),vec4(0.0,2.0/(top-bottom),0.0,(-(top+bottom))/(top-bottom)),vec4(0.0,0.0,(-2.0)/(far-near),(-(far+near))/(far-near)),vec4(0.0,0.0,0.0,1.0));
}
void main()
{
if (sc_RayTracingCasterConfiguration.x!=0u)
{
sc_SetClipPosition(vec4(position.xy,depthRef+(1e-10*position.z),1.0+(1e-10*position.w)));
return;
}
PreviewVertexColor=vec4(0.5);
PreviewVertexSaved=0.0;
sc_Vertex_t l9_0=sc_Vertex_t(position,normal,tangent.xyz,texture0,texture1);
sc_BlendVertex(l9_0);
sc_SkinVertex(l9_0);
#if (sc_RenderingSpace==3)
{
varPosAndMotion=vec4(vec3(0.0).x,vec3(0.0).y,vec3(0.0).z,varPosAndMotion.w);
varNormalAndMotion=vec4(l9_0.normal.x,l9_0.normal.y,l9_0.normal.z,varNormalAndMotion.w);
varTangent=vec4(l9_0.tangent.x,l9_0.tangent.y,l9_0.tangent.z,varTangent.w);
}
#else
{
#if (sc_RenderingSpace==4)
{
varPosAndMotion=vec4(vec3(0.0).x,vec3(0.0).y,vec3(0.0).z,varPosAndMotion.w);
varNormalAndMotion=vec4(l9_0.normal.x,l9_0.normal.y,l9_0.normal.z,varNormalAndMotion.w);
varTangent=vec4(l9_0.tangent.x,l9_0.tangent.y,l9_0.tangent.z,varTangent.w);
}
#else
{
#if (sc_RenderingSpace==2)
{
varPosAndMotion=vec4(l9_0.position.x,l9_0.position.y,l9_0.position.z,varPosAndMotion.w);
varNormalAndMotion=vec4(l9_0.normal.x,l9_0.normal.y,l9_0.normal.z,varNormalAndMotion.w);
varTangent=vec4(l9_0.tangent.x,l9_0.tangent.y,l9_0.tangent.z,varTangent.w);
}
#else
{
#if (sc_RenderingSpace==1)
{
vec4 l9_1=sc_ModelMatrix*l9_0.position;
varPosAndMotion=vec4(l9_1.x,l9_1.y,l9_1.z,varPosAndMotion.w);
vec3 l9_2=sc_NormalMatrix*l9_0.normal;
varNormalAndMotion=vec4(l9_2.x,l9_2.y,l9_2.z,varNormalAndMotion.w);
vec3 l9_3=sc_NormalMatrix*l9_0.tangent;
varTangent=vec4(l9_3.x,l9_3.y,l9_3.z,varTangent.w);
}
#endif
}
#endif
}
#endif
}
#endif
bool l9_4=PreviewEnabled==1;
vec2 l9_5;
if (l9_4)
{
vec2 l9_6=l9_0.texture0;
l9_6.x=1.0-l9_0.texture0.x;
l9_5=l9_6;
}
else
{
l9_5=l9_0.texture0;
}
varColor=color;
vec3 l9_7;
vec3 l9_8;
vec3 l9_9;
if (l9_4)
{
l9_9=varTangent.xyz;
l9_8=varNormalAndMotion.xyz;
l9_7=varPosAndMotion.xyz;
}
else
{
l9_9=varTangent.xyz;
l9_8=varNormalAndMotion.xyz;
l9_7=varPosAndMotion.xyz;
}
varPosAndMotion=vec4(l9_7.x,l9_7.y,l9_7.z,varPosAndMotion.w);
vec3 l9_10=normalize(l9_8);
varNormalAndMotion=vec4(l9_10.x,l9_10.y,l9_10.z,varNormalAndMotion.w);
vec3 l9_11=normalize(l9_9);
varTangent=vec4(l9_11.x,l9_11.y,l9_11.z,varTangent.w);
varTangent.w=tangent.w;
#if (UseViewSpaceDepthVariant&&((sc_OITDepthGatherPass||sc_OITCompositingPass)||sc_OITDepthBoundsPass))
{
vec4 l9_12;
#if (sc_RenderingSpace==3)
{
l9_12=sc_ProjectionMatrixInverseArray[sc_GetStereoViewIndex()]*l9_0.position;
}
#else
{
vec4 l9_13;
#if (sc_RenderingSpace==2)
{
l9_13=sc_ViewMatrixArray[sc_GetStereoViewIndex()]*l9_0.position;
}
#else
{
vec4 l9_14;
#if (sc_RenderingSpace==1)
{
l9_14=sc_ModelViewMatrixArray[sc_GetStereoViewIndex()]*l9_0.position;
}
#else
{
l9_14=l9_0.position;
}
#endif
l9_13=l9_14;
}
#endif
l9_12=l9_13;
}
#endif
varViewSpaceDepth=-l9_12.z;
}
#endif
vec4 l9_15;
#if (sc_RenderingSpace==3)
{
l9_15=l9_0.position;
}
#else
{
vec4 l9_16;
#if (sc_RenderingSpace==4)
{
l9_16=(sc_ModelViewMatrixArray[sc_GetStereoViewIndex()]*l9_0.position)*vec4(1.0/sc_Camera.aspect,1.0,1.0,1.0);
}
#else
{
vec4 l9_17;
#if (sc_RenderingSpace==2)
{
l9_17=sc_ViewProjectionMatrixArray[sc_GetStereoViewIndex()]*vec4(varPosAndMotion.xyz,1.0);
}
#else
{
vec4 l9_18;
#if (sc_RenderingSpace==1)
{
l9_18=sc_ViewProjectionMatrixArray[sc_GetStereoViewIndex()]*vec4(varPosAndMotion.xyz,1.0);
}
#else
{
l9_18=vec4(0.0);
}
#endif
l9_17=l9_18;
}
#endif
l9_16=l9_17;
}
#endif
l9_15=l9_16;
}
#endif
varTex01=vec4(l9_5,l9_0.texture1);
#if (sc_ProjectiveShadowsReceiver)
{
vec4 l9_19;
#if (sc_RenderingSpace==1)
{
l9_19=sc_ModelMatrix*l9_0.position;
}
#else
{
l9_19=l9_0.position;
}
#endif
vec4 l9_20=sc_ProjectorMatrix*l9_19;
varShadowTex=((l9_20.xy/vec2(l9_20.w))*0.5)+vec2(0.5);
}
#endif
vec4 l9_21;
#if (sc_DepthBufferMode==1)
{
vec4 l9_22;
if (sc_ProjectionMatrixArray[sc_GetStereoViewIndex()][2].w!=0.0)
{
vec4 l9_23=l9_15;
l9_23.z=((log2(max(sc_Camera.clipPlanes.x,1.0+l9_15.w))*(2.0/log2(sc_Camera.clipPlanes.y+1.0)))-1.0)*l9_15.w;
l9_22=l9_23;
}
else
{
l9_22=l9_15;
}
l9_21=l9_22;
}
#else
{
l9_21=l9_15;
}
#endif
vec4 l9_24;
#if (sc_TAAEnabled)
{
vec2 l9_25=l9_21.xy+(sc_TAAJitterOffset*l9_21.w);
l9_24=vec4(l9_25.x,l9_25.y,l9_21.z,l9_21.w);
}
#else
{
l9_24=l9_21;
}
#endif
sc_SetClipPosition(l9_24);
#if (sc_Voxelization)
{
sc_Vertex_t l9_26=sc_Vertex_t(l9_0.position,l9_0.normal,l9_0.tangent,l9_5,l9_0.texture1);
sc_BlendVertex(l9_26);
sc_SkinVertex(l9_26);
int l9_27=sc_GetLocalInstanceIDInternal(sc_FallbackInstanceID);
int l9_28=int(voxelization_params_0.w);
vec4 l9_29=createVoxelOrthoMatrix(voxelization_params_frustum_lrbt.x,voxelization_params_frustum_lrbt.y,voxelization_params_frustum_lrbt.z,voxelization_params_frustum_lrbt.w,voxelization_params_frustum_nf.x,voxelization_params_frustum_nf.y)*vec4(((sc_ModelMatrixVoxelization*l9_26.position).xyz+vec3(float(l9_27%l9_28)*voxelization_params_0.y,float(l9_27/l9_28)*voxelization_params_0.y,(float(l9_27)*(voxelization_params_0.y/voxelization_params_0.z))+voxelization_params_frustum_nf.x))-voxelization_params_camera_pos,1.0);
l9_29.w=1.0;
varScreenPos=l9_29;
sc_SetClipPosition(l9_29*1.0);
}
#else
{
#if (sc_OutputBounds)
{
sc_Vertex_t l9_30=sc_Vertex_t(l9_0.position,l9_0.normal,l9_0.tangent,l9_5,l9_0.texture1);
sc_BlendVertex(l9_30);
sc_SkinVertex(l9_30);
vec2 l9_31=((l9_30.position.xy/vec2(l9_30.position.w))*0.5)+vec2(0.5);
varTex01=vec4(l9_31.x,l9_31.y,varTex01.z,varTex01.w);
vec4 l9_32=sc_ModelMatrixVoxelization*l9_30.position;
vec3 l9_33=l9_32.xyz-voxelization_params_camera_pos;
varPosAndMotion=vec4(l9_33.x,l9_33.y,l9_33.z,varPosAndMotion.w);
vec3 l9_34=normalize(l9_30.normal);
varNormalAndMotion=vec4(l9_34.x,l9_34.y,l9_34.z,varNormalAndMotion.w);
vec4 l9_35=createVoxelOrthoMatrix(voxelization_params_frustum_lrbt.x,voxelization_params_frustum_lrbt.y,voxelization_params_frustum_lrbt.z,voxelization_params_frustum_lrbt.w,voxelization_params_frustum_nf.x,voxelization_params_frustum_nf.y)*vec4(l9_33.x,l9_33.y,l9_33.z,l9_32.w);
vec4 l9_36=vec4(l9_35.x,l9_35.y,l9_35.z,vec4(0.0).w);
l9_36.w=1.0;
varScreenPos=l9_36;
sc_SetClipPosition(l9_36*1.0);
}
#endif
}
#endif
vec4 l9_37=varPosAndMotion;
#if (sc_MotionVectorsPass)
{
vec4 l9_38=vec4(l9_37.xyz,1.0);
#if (sc_MotionVectorsPass)
{
vec4 l9_39=sc_ViewProjectionMatrixArray[sc_GetStereoViewIndex()]*l9_38;
vec4 l9_40=sc_PrevFrameViewProjectionMatrixArray[sc_GetStereoViewIndex()]*vec4(((sc_PrevFrameModelMatrix*sc_ModelMatrixInverse)*l9_38).xyz,1.0);
vec2 l9_41=((l9_39.xy/vec2(l9_39.w)).xy-(l9_40.xy/vec2(l9_40.w)).xy)*0.5;
varPosAndMotion.w=l9_41.x;
varNormalAndMotion.w=l9_41.y;
}
#endif
}
#endif
}
#elif defined FRAGMENT_SHADER // #if defined VERTEX_SHADER
#if SC_RT_RECEIVER_MODE
#ifndef sc_StereoRenderingMode
#define sc_StereoRenderingMode 0
#endif
#ifndef sc_BlendMode_AlphaTest
#define sc_BlendMode_AlphaTest 0
#elif sc_BlendMode_AlphaTest==1
#undef sc_BlendMode_AlphaTest
#define sc_BlendMode_AlphaTest 1
#endif
#ifndef ENABLE_STIPPLE_PATTERN_TEST
#define ENABLE_STIPPLE_PATTERN_TEST 0
#elif ENABLE_STIPPLE_PATTERN_TEST==1
#undef ENABLE_STIPPLE_PATTERN_TEST
#define ENABLE_STIPPLE_PATTERN_TEST 1
#endif
#ifndef baseTexHasSwappedViews
#define baseTexHasSwappedViews 0
#elif baseTexHasSwappedViews==1
#undef baseTexHasSwappedViews
#define baseTexHasSwappedViews 1
#endif
#ifndef Tweak_N10HasSwappedViews
#define Tweak_N10HasSwappedViews 0
#elif Tweak_N10HasSwappedViews==1
#undef Tweak_N10HasSwappedViews
#define Tweak_N10HasSwappedViews 1
#endif
#ifndef normalTexHasSwappedViews
#define normalTexHasSwappedViews 0
#elif normalTexHasSwappedViews==1
#undef normalTexHasSwappedViews
#define normalTexHasSwappedViews 1
#endif
#ifndef Tweak_N13HasSwappedViews
#define Tweak_N13HasSwappedViews 0
#elif Tweak_N13HasSwappedViews==1
#undef Tweak_N13HasSwappedViews
#define Tweak_N13HasSwappedViews 1
#endif
#ifndef Tweak_N17HasSwappedViews
#define Tweak_N17HasSwappedViews 0
#elif Tweak_N17HasSwappedViews==1
#undef Tweak_N17HasSwappedViews
#define Tweak_N17HasSwappedViews 1
#endif
#ifndef Tweak_N20HasSwappedViews
#define Tweak_N20HasSwappedViews 0
#elif Tweak_N20HasSwappedViews==1
#undef Tweak_N20HasSwappedViews
#define Tweak_N20HasSwappedViews 1
#endif
#ifndef materialParamsTexHasSwappedViews
#define materialParamsTexHasSwappedViews 0
#elif materialParamsTexHasSwappedViews==1
#undef materialParamsTexHasSwappedViews
#define materialParamsTexHasSwappedViews 1
#endif
#ifndef normalTexLayout
#define normalTexLayout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_normalTex
#define SC_USE_UV_TRANSFORM_normalTex 0
#elif SC_USE_UV_TRANSFORM_normalTex==1
#undef SC_USE_UV_TRANSFORM_normalTex
#define SC_USE_UV_TRANSFORM_normalTex 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_normalTex
#define SC_SOFTWARE_WRAP_MODE_U_normalTex -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_normalTex
#define SC_SOFTWARE_WRAP_MODE_V_normalTex -1
#endif
#ifndef SC_USE_UV_MIN_MAX_normalTex
#define SC_USE_UV_MIN_MAX_normalTex 0
#elif SC_USE_UV_MIN_MAX_normalTex==1
#undef SC_USE_UV_MIN_MAX_normalTex
#define SC_USE_UV_MIN_MAX_normalTex 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_normalTex
#define SC_USE_CLAMP_TO_BORDER_normalTex 0
#elif SC_USE_CLAMP_TO_BORDER_normalTex==1
#undef SC_USE_CLAMP_TO_BORDER_normalTex
#define SC_USE_CLAMP_TO_BORDER_normalTex 1
#endif
#ifndef Tweak_N13Layout
#define Tweak_N13Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N13
#define SC_USE_UV_TRANSFORM_Tweak_N13 0
#elif SC_USE_UV_TRANSFORM_Tweak_N13==1
#undef SC_USE_UV_TRANSFORM_Tweak_N13
#define SC_USE_UV_TRANSFORM_Tweak_N13 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N13
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N13 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N13
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N13 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N13
#define SC_USE_UV_MIN_MAX_Tweak_N13 0
#elif SC_USE_UV_MIN_MAX_Tweak_N13==1
#undef SC_USE_UV_MIN_MAX_Tweak_N13
#define SC_USE_UV_MIN_MAX_Tweak_N13 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N13
#define SC_USE_CLAMP_TO_BORDER_Tweak_N13 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N13==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N13
#define SC_USE_CLAMP_TO_BORDER_Tweak_N13 1
#endif
#ifndef Tweak_N17Layout
#define Tweak_N17Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N17
#define SC_USE_UV_TRANSFORM_Tweak_N17 0
#elif SC_USE_UV_TRANSFORM_Tweak_N17==1
#undef SC_USE_UV_TRANSFORM_Tweak_N17
#define SC_USE_UV_TRANSFORM_Tweak_N17 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N17
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N17 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N17
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N17 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N17
#define SC_USE_UV_MIN_MAX_Tweak_N17 0
#elif SC_USE_UV_MIN_MAX_Tweak_N17==1
#undef SC_USE_UV_MIN_MAX_Tweak_N17
#define SC_USE_UV_MIN_MAX_Tweak_N17 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N17
#define SC_USE_CLAMP_TO_BORDER_Tweak_N17 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N17==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N17
#define SC_USE_CLAMP_TO_BORDER_Tweak_N17 1
#endif
#ifndef Tweak_N20Layout
#define Tweak_N20Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N20
#define SC_USE_UV_TRANSFORM_Tweak_N20 0
#elif SC_USE_UV_TRANSFORM_Tweak_N20==1
#undef SC_USE_UV_TRANSFORM_Tweak_N20
#define SC_USE_UV_TRANSFORM_Tweak_N20 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N20
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N20 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N20
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N20 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N20
#define SC_USE_UV_MIN_MAX_Tweak_N20 0
#elif SC_USE_UV_MIN_MAX_Tweak_N20==1
#undef SC_USE_UV_MIN_MAX_Tweak_N20
#define SC_USE_UV_MIN_MAX_Tweak_N20 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N20
#define SC_USE_CLAMP_TO_BORDER_Tweak_N20 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N20==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N20
#define SC_USE_CLAMP_TO_BORDER_Tweak_N20 1
#endif
#ifndef Tweak_N10Layout
#define Tweak_N10Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N10
#define SC_USE_UV_TRANSFORM_Tweak_N10 0
#elif SC_USE_UV_TRANSFORM_Tweak_N10==1
#undef SC_USE_UV_TRANSFORM_Tweak_N10
#define SC_USE_UV_TRANSFORM_Tweak_N10 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N10
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N10 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N10
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N10 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N10
#define SC_USE_UV_MIN_MAX_Tweak_N10 0
#elif SC_USE_UV_MIN_MAX_Tweak_N10==1
#undef SC_USE_UV_MIN_MAX_Tweak_N10
#define SC_USE_UV_MIN_MAX_Tweak_N10 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N10
#define SC_USE_CLAMP_TO_BORDER_Tweak_N10 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N10==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N10
#define SC_USE_CLAMP_TO_BORDER_Tweak_N10 1
#endif
#ifndef sc_ProjectiveShadowsCaster
#define sc_ProjectiveShadowsCaster 0
#elif sc_ProjectiveShadowsCaster==1
#undef sc_ProjectiveShadowsCaster
#define sc_ProjectiveShadowsCaster 1
#endif
#ifndef sc_DepthOnly
#define sc_DepthOnly 0
#elif sc_DepthOnly==1
#undef sc_DepthOnly
#define sc_DepthOnly 1
#endif
#ifndef baseTexLayout
#define baseTexLayout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_baseTex
#define SC_USE_UV_TRANSFORM_baseTex 0
#elif SC_USE_UV_TRANSFORM_baseTex==1
#undef SC_USE_UV_TRANSFORM_baseTex
#define SC_USE_UV_TRANSFORM_baseTex 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_baseTex
#define SC_SOFTWARE_WRAP_MODE_U_baseTex -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_baseTex
#define SC_SOFTWARE_WRAP_MODE_V_baseTex -1
#endif
#ifndef SC_USE_UV_MIN_MAX_baseTex
#define SC_USE_UV_MIN_MAX_baseTex 0
#elif SC_USE_UV_MIN_MAX_baseTex==1
#undef SC_USE_UV_MIN_MAX_baseTex
#define SC_USE_UV_MIN_MAX_baseTex 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_baseTex
#define SC_USE_CLAMP_TO_BORDER_baseTex 0
#elif SC_USE_CLAMP_TO_BORDER_baseTex==1
#undef SC_USE_CLAMP_TO_BORDER_baseTex
#define SC_USE_CLAMP_TO_BORDER_baseTex 1
#endif
#ifndef materialParamsTexLayout
#define materialParamsTexLayout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_materialParamsTex
#define SC_USE_UV_TRANSFORM_materialParamsTex 0
#elif SC_USE_UV_TRANSFORM_materialParamsTex==1
#undef SC_USE_UV_TRANSFORM_materialParamsTex
#define SC_USE_UV_TRANSFORM_materialParamsTex 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_materialParamsTex
#define SC_SOFTWARE_WRAP_MODE_U_materialParamsTex -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_materialParamsTex
#define SC_SOFTWARE_WRAP_MODE_V_materialParamsTex -1
#endif
#ifndef SC_USE_UV_MIN_MAX_materialParamsTex
#define SC_USE_UV_MIN_MAX_materialParamsTex 0
#elif SC_USE_UV_MIN_MAX_materialParamsTex==1
#undef SC_USE_UV_MIN_MAX_materialParamsTex
#define SC_USE_UV_MIN_MAX_materialParamsTex 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_materialParamsTex
#define SC_USE_CLAMP_TO_BORDER_materialParamsTex 0
#elif SC_USE_CLAMP_TO_BORDER_materialParamsTex==1
#undef SC_USE_CLAMP_TO_BORDER_materialParamsTex
#define SC_USE_CLAMP_TO_BORDER_materialParamsTex 1
#endif
layout(binding=0,std430) readonly buffer sc_RayTracingCasterIndexBuffer
{
uint sc_RayTracingCasterTriangles[1];
} sc_RayTracingCasterIndexBuffer_obj;
layout(binding=1,std430) readonly buffer sc_RayTracingCasterVertexBuffer
{
float sc_RayTracingCasterVertices[1];
} sc_RayTracingCasterVertexBuffer_obj;
layout(binding=2,std430) readonly buffer sc_RayTracingCasterNonAnimatedVertexBuffer
{
float sc_RayTracingCasterNonAnimatedVertices[1];
} sc_RayTracingCasterNonAnimatedVertexBuffer_obj;
uniform vec3 sc_RayTracingOriginOffset;
uniform vec3 sc_RayTracingOriginScale;
uniform uint sc_RayTracingReceiverMask;
uniform uint sc_RayTracingReceiverId;
uniform float alphaTestThreshold;
uniform mat3 normalTexTransform;
uniform vec4 normalTexUvMinMax;
uniform vec4 normalTexBorderColor;
uniform float Tweak_N0;
uniform mat3 Tweak_N13Transform;
uniform vec4 Tweak_N13UvMinMax;
uniform vec4 Tweak_N13BorderColor;
uniform float Tweak_N22;
uniform mat3 Tweak_N17Transform;
uniform vec4 Tweak_N17UvMinMax;
uniform vec4 Tweak_N17BorderColor;
uniform float Tweak_N21;
uniform mat3 Tweak_N20Transform;
uniform vec4 Tweak_N20UvMinMax;
uniform vec4 Tweak_N20BorderColor;
uniform mat3 Tweak_N10Transform;
uniform vec4 Tweak_N10UvMinMax;
uniform vec4 Tweak_N10BorderColor;
uniform float Port_Input1_N012;
uniform vec2 Port_Center_N014;
uniform vec2 Port_Center_N015;
uniform vec2 Port_Center_N019;
uniform mat3 baseTexTransform;
uniform vec4 baseTexUvMinMax;
uniform vec4 baseTexBorderColor;
uniform mat3 materialParamsTexTransform;
uniform vec4 materialParamsTexUvMinMax;
uniform vec4 materialParamsTexBorderColor;
uniform sampler2DArray baseTexArrSC;
uniform sampler2D baseTex;
uniform sampler2DArray Tweak_N10ArrSC;
uniform sampler2D Tweak_N10;
uniform sampler2DArray normalTexArrSC;
uniform sampler2D normalTex;
uniform sampler2DArray Tweak_N13ArrSC;
uniform sampler2D Tweak_N13;
uniform sampler2DArray Tweak_N17ArrSC;
uniform sampler2D Tweak_N17;
uniform sampler2DArray Tweak_N20ArrSC;
uniform sampler2D Tweak_N20;
uniform sampler2DArray materialParamsTexArrSC;
uniform sampler2D materialParamsTex;
flat in int varStereoViewID;
#if sc_FramebufferFetch&&defined(GL_EXT_shader_framebuffer_fetch)
#define out inout
#endif
layout(location=0) out uvec4 sc_RayTracingPositionAndMask;
#if sc_FramebufferFetch&&defined(GL_EXT_shader_framebuffer_fetch)
#undef out
#endif
#if sc_FramebufferFetch&&defined(GL_EXT_shader_framebuffer_fetch)
#define out inout
#endif
layout(location=1) out uvec4 sc_RayTracingNormalAndMore;
#if sc_FramebufferFetch&&defined(GL_EXT_shader_framebuffer_fetch)
#undef out
#endif
in vec4 varTex01;
in vec4 varPosAndMotion;
in vec4 varTangent;
in vec4 varNormalAndMotion;
in vec4 varScreenPos;
in vec2 varScreenTexturePos;
in float varViewSpaceDepth;
in vec2 varShadowTex;
in float varClipDistance;
in vec4 varColor;
in vec4 PreviewVertexColor;
in float PreviewVertexSaved;
int sc_GetStereoViewIndex()
{
int l9_0;
#if (sc_StereoRenderingMode==0)
{
l9_0=0;
}
#else
{
l9_0=varStereoViewID;
}
#endif
return l9_0;
}
int baseTexGetStereoViewIndex()
{
int l9_0;
#if (baseTexHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
void sc_SoftwareWrapEarly(inout float uv,int softwareWrapMode)
{
if (softwareWrapMode==1)
{
uv=fract(uv);
}
else
{
if (softwareWrapMode==2)
{
float l9_0=fract(uv);
uv=mix(l9_0,1.0-l9_0,clamp(step(0.25,fract((uv-l9_0)*0.5)),0.0,1.0));
}
}
}
void sc_ClampUV(inout float value,float minValue,float maxValue,bool useClampToBorder,inout float clampToBorderFactor)
{
float l9_0=clamp(value,minValue,maxValue);
float l9_1=step(abs(value-l9_0),9.9999997e-06);
clampToBorderFactor*=(l9_1+((1.0-float(useClampToBorder))*(1.0-l9_1)));
value=l9_0;
}
vec2 sc_TransformUV(vec2 uv,bool useUvTransform,mat3 uvTransform)
{
if (useUvTransform)
{
uv=vec2((uvTransform*vec3(uv,1.0)).xy);
}
return uv;
}
void sc_SoftwareWrapLate(inout float uv,int softwareWrapMode,bool useClampToBorder,inout float clampToBorderFactor)
{
if ((softwareWrapMode==0)||(softwareWrapMode==3))
{
sc_ClampUV(uv,0.0,1.0,useClampToBorder,clampToBorderFactor);
}
}
vec3 sc_SamplingCoordsViewToGlobal(vec2 uv,int renderingLayout,int viewIndex)
{
vec3 l9_0;
if (renderingLayout==0)
{
l9_0=vec3(uv,0.0);
}
else
{
vec3 l9_1;
if (renderingLayout==1)
{
l9_1=vec3(uv.x,(uv.y*0.5)+(0.5-(float(viewIndex)*0.5)),0.0);
}
else
{
l9_1=vec3(uv,float(viewIndex));
}
l9_0=l9_1;
}
return l9_0;
}
int Tweak_N10GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N10HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int normalTexGetStereoViewIndex()
{
int l9_0;
#if (normalTexHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int Tweak_N13GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N13HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int Tweak_N17GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N17HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int Tweak_N20GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N20HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int materialParamsTexGetStereoViewIndex()
{
int l9_0;
#if (materialParamsTexHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
void main()
{
#if (sc_DepthOnly)
{
return;
}
#endif
vec3 l9_0=normalize(varTangent.xyz);
vec3 l9_1=normalize(varNormalAndMotion.xyz);
vec4 l9_2;
#if (baseTexLayout==2)
{
bool l9_3=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_baseTex)!=0));
float l9_4=varTex01.x;
sc_SoftwareWrapEarly(l9_4,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x);
float l9_5=l9_4;
float l9_6=varTex01.y;
sc_SoftwareWrapEarly(l9_6,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y);
float l9_7=l9_6;
vec2 l9_8;
float l9_9;
#if (SC_USE_UV_MIN_MAX_baseTex)
{
bool l9_10;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_10=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x==3;
}
#else
{
l9_10=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_11=l9_5;
float l9_12=1.0;
sc_ClampUV(l9_11,baseTexUvMinMax.x,baseTexUvMinMax.z,l9_10,l9_12);
float l9_13=l9_11;
float l9_14=l9_12;
bool l9_15;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_15=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y==3;
}
#else
{
l9_15=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_16=l9_7;
float l9_17=l9_14;
sc_ClampUV(l9_16,baseTexUvMinMax.y,baseTexUvMinMax.w,l9_15,l9_17);
l9_9=l9_17;
l9_8=vec2(l9_13,l9_16);
}
#else
{
l9_9=1.0;
l9_8=vec2(l9_5,l9_7);
}
#endif
vec2 l9_18=sc_TransformUV(l9_8,(int(SC_USE_UV_TRANSFORM_baseTex)!=0),baseTexTransform);
float l9_19=l9_18.x;
float l9_20=l9_9;
sc_SoftwareWrapLate(l9_19,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x,l9_3,l9_20);
float l9_21=l9_18.y;
float l9_22=l9_20;
sc_SoftwareWrapLate(l9_21,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y,l9_3,l9_22);
float l9_23=l9_22;
vec3 l9_24=sc_SamplingCoordsViewToGlobal(vec2(l9_19,l9_21),baseTexLayout,baseTexGetStereoViewIndex());
vec4 l9_25=texture(baseTexArrSC,l9_24,0.0);
vec4 l9_26;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_26=mix(baseTexBorderColor,l9_25,vec4(l9_23));
}
#else
{
l9_26=l9_25;
}
#endif
l9_2=l9_26;
}
#else
{
bool l9_27=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_baseTex)!=0));
float l9_28=varTex01.x;
sc_SoftwareWrapEarly(l9_28,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x);
float l9_29=l9_28;
float l9_30=varTex01.y;
sc_SoftwareWrapEarly(l9_30,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y);
float l9_31=l9_30;
vec2 l9_32;
float l9_33;
#if (SC_USE_UV_MIN_MAX_baseTex)
{
bool l9_34;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_34=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x==3;
}
#else
{
l9_34=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_35=l9_29;
float l9_36=1.0;
sc_ClampUV(l9_35,baseTexUvMinMax.x,baseTexUvMinMax.z,l9_34,l9_36);
float l9_37=l9_35;
float l9_38=l9_36;
bool l9_39;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_39=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y==3;
}
#else
{
l9_39=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_40=l9_31;
float l9_41=l9_38;
sc_ClampUV(l9_40,baseTexUvMinMax.y,baseTexUvMinMax.w,l9_39,l9_41);
l9_33=l9_41;
l9_32=vec2(l9_37,l9_40);
}
#else
{
l9_33=1.0;
l9_32=vec2(l9_29,l9_31);
}
#endif
vec2 l9_42=sc_TransformUV(l9_32,(int(SC_USE_UV_TRANSFORM_baseTex)!=0),baseTexTransform);
float l9_43=l9_42.x;
float l9_44=l9_33;
sc_SoftwareWrapLate(l9_43,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x,l9_27,l9_44);
float l9_45=l9_42.y;
float l9_46=l9_44;
sc_SoftwareWrapLate(l9_45,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y,l9_27,l9_46);
float l9_47=l9_46;
vec3 l9_48=sc_SamplingCoordsViewToGlobal(vec2(l9_43,l9_45),baseTexLayout,baseTexGetStereoViewIndex());
vec4 l9_49=texture(baseTex,l9_48.xy,0.0);
vec4 l9_50;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_50=mix(baseTexBorderColor,l9_49,vec4(l9_47));
}
#else
{
l9_50=l9_49;
}
#endif
l9_2=l9_50;
}
#endif
vec4 l9_51;
#if (Tweak_N10Layout==2)
{
bool l9_52=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N10)!=0));
float l9_53=varTex01.x;
sc_SoftwareWrapEarly(l9_53,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x);
float l9_54=l9_53;
float l9_55=varTex01.y;
sc_SoftwareWrapEarly(l9_55,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y);
float l9_56=l9_55;
vec2 l9_57;
float l9_58;
#if (SC_USE_UV_MIN_MAX_Tweak_N10)
{
bool l9_59;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_59=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x==3;
}
#else
{
l9_59=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_60=l9_54;
float l9_61=1.0;
sc_ClampUV(l9_60,Tweak_N10UvMinMax.x,Tweak_N10UvMinMax.z,l9_59,l9_61);
float l9_62=l9_60;
float l9_63=l9_61;
bool l9_64;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_64=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y==3;
}
#else
{
l9_64=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_65=l9_56;
float l9_66=l9_63;
sc_ClampUV(l9_65,Tweak_N10UvMinMax.y,Tweak_N10UvMinMax.w,l9_64,l9_66);
l9_58=l9_66;
l9_57=vec2(l9_62,l9_65);
}
#else
{
l9_58=1.0;
l9_57=vec2(l9_54,l9_56);
}
#endif
vec2 l9_67=sc_TransformUV(l9_57,(int(SC_USE_UV_TRANSFORM_Tweak_N10)!=0),Tweak_N10Transform);
float l9_68=l9_67.x;
float l9_69=l9_58;
sc_SoftwareWrapLate(l9_68,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x,l9_52,l9_69);
float l9_70=l9_67.y;
float l9_71=l9_69;
sc_SoftwareWrapLate(l9_70,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y,l9_52,l9_71);
float l9_72=l9_71;
vec3 l9_73=sc_SamplingCoordsViewToGlobal(vec2(l9_68,l9_70),Tweak_N10Layout,Tweak_N10GetStereoViewIndex());
vec4 l9_74=texture(Tweak_N10ArrSC,l9_73,0.0);
vec4 l9_75;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_75=mix(Tweak_N10BorderColor,l9_74,vec4(l9_72));
}
#else
{
l9_75=l9_74;
}
#endif
l9_51=l9_75;
}
#else
{
bool l9_76=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N10)!=0));
float l9_77=varTex01.x;
sc_SoftwareWrapEarly(l9_77,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x);
float l9_78=l9_77;
float l9_79=varTex01.y;
sc_SoftwareWrapEarly(l9_79,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y);
float l9_80=l9_79;
vec2 l9_81;
float l9_82;
#if (SC_USE_UV_MIN_MAX_Tweak_N10)
{
bool l9_83;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_83=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x==3;
}
#else
{
l9_83=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_84=l9_78;
float l9_85=1.0;
sc_ClampUV(l9_84,Tweak_N10UvMinMax.x,Tweak_N10UvMinMax.z,l9_83,l9_85);
float l9_86=l9_84;
float l9_87=l9_85;
bool l9_88;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_88=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y==3;
}
#else
{
l9_88=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_89=l9_80;
float l9_90=l9_87;
sc_ClampUV(l9_89,Tweak_N10UvMinMax.y,Tweak_N10UvMinMax.w,l9_88,l9_90);
l9_82=l9_90;
l9_81=vec2(l9_86,l9_89);
}
#else
{
l9_82=1.0;
l9_81=vec2(l9_78,l9_80);
}
#endif
vec2 l9_91=sc_TransformUV(l9_81,(int(SC_USE_UV_TRANSFORM_Tweak_N10)!=0),Tweak_N10Transform);
float l9_92=l9_91.x;
float l9_93=l9_82;
sc_SoftwareWrapLate(l9_92,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x,l9_76,l9_93);
float l9_94=l9_91.y;
float l9_95=l9_93;
sc_SoftwareWrapLate(l9_94,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y,l9_76,l9_95);
float l9_96=l9_95;
vec3 l9_97=sc_SamplingCoordsViewToGlobal(vec2(l9_92,l9_94),Tweak_N10Layout,Tweak_N10GetStereoViewIndex());
vec4 l9_98=texture(Tweak_N10,l9_97.xy,0.0);
vec4 l9_99;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_99=mix(Tweak_N10BorderColor,l9_98,vec4(l9_96));
}
#else
{
l9_99=l9_98;
}
#endif
l9_51=l9_99;
}
#endif
vec4 l9_100=l9_51*vec4(Port_Input1_N012);
float l9_101=floor(l9_100.x);
vec4 l9_102;
if (l9_101==0.0)
{
vec4 l9_103;
#if (normalTexLayout==2)
{
bool l9_104=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_normalTex)!=0));
float l9_105=varTex01.x;
sc_SoftwareWrapEarly(l9_105,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x);
float l9_106=l9_105;
float l9_107=varTex01.y;
sc_SoftwareWrapEarly(l9_107,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y);
float l9_108=l9_107;
vec2 l9_109;
float l9_110;
#if (SC_USE_UV_MIN_MAX_normalTex)
{
bool l9_111;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_111=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x==3;
}
#else
{
l9_111=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_112=l9_106;
float l9_113=1.0;
sc_ClampUV(l9_112,normalTexUvMinMax.x,normalTexUvMinMax.z,l9_111,l9_113);
float l9_114=l9_112;
float l9_115=l9_113;
bool l9_116;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_116=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y==3;
}
#else
{
l9_116=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_117=l9_108;
float l9_118=l9_115;
sc_ClampUV(l9_117,normalTexUvMinMax.y,normalTexUvMinMax.w,l9_116,l9_118);
l9_110=l9_118;
l9_109=vec2(l9_114,l9_117);
}
#else
{
l9_110=1.0;
l9_109=vec2(l9_106,l9_108);
}
#endif
vec2 l9_119=sc_TransformUV(l9_109,(int(SC_USE_UV_TRANSFORM_normalTex)!=0),normalTexTransform);
float l9_120=l9_119.x;
float l9_121=l9_110;
sc_SoftwareWrapLate(l9_120,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x,l9_104,l9_121);
float l9_122=l9_119.y;
float l9_123=l9_121;
sc_SoftwareWrapLate(l9_122,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y,l9_104,l9_123);
float l9_124=l9_123;
vec3 l9_125=sc_SamplingCoordsViewToGlobal(vec2(l9_120,l9_122),normalTexLayout,normalTexGetStereoViewIndex());
vec4 l9_126=texture(normalTexArrSC,l9_125,0.0);
vec4 l9_127;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_127=mix(normalTexBorderColor,l9_126,vec4(l9_124));
}
#else
{
l9_127=l9_126;
}
#endif
l9_103=l9_127;
}
#else
{
bool l9_128=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_normalTex)!=0));
float l9_129=varTex01.x;
sc_SoftwareWrapEarly(l9_129,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x);
float l9_130=l9_129;
float l9_131=varTex01.y;
sc_SoftwareWrapEarly(l9_131,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y);
float l9_132=l9_131;
vec2 l9_133;
float l9_134;
#if (SC_USE_UV_MIN_MAX_normalTex)
{
bool l9_135;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_135=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x==3;
}
#else
{
l9_135=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_136=l9_130;
float l9_137=1.0;
sc_ClampUV(l9_136,normalTexUvMinMax.x,normalTexUvMinMax.z,l9_135,l9_137);
float l9_138=l9_136;
float l9_139=l9_137;
bool l9_140;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_140=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y==3;
}
#else
{
l9_140=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_141=l9_132;
float l9_142=l9_139;
sc_ClampUV(l9_141,normalTexUvMinMax.y,normalTexUvMinMax.w,l9_140,l9_142);
l9_134=l9_142;
l9_133=vec2(l9_138,l9_141);
}
#else
{
l9_134=1.0;
l9_133=vec2(l9_130,l9_132);
}
#endif
vec2 l9_143=sc_TransformUV(l9_133,(int(SC_USE_UV_TRANSFORM_normalTex)!=0),normalTexTransform);
float l9_144=l9_143.x;
float l9_145=l9_134;
sc_SoftwareWrapLate(l9_144,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x,l9_128,l9_145);
float l9_146=l9_143.y;
float l9_147=l9_145;
sc_SoftwareWrapLate(l9_146,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y,l9_128,l9_147);
float l9_148=l9_147;
vec3 l9_149=sc_SamplingCoordsViewToGlobal(vec2(l9_144,l9_146),normalTexLayout,normalTexGetStereoViewIndex());
vec4 l9_150=texture(normalTex,l9_149.xy,0.0);
vec4 l9_151;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_151=mix(normalTexBorderColor,l9_150,vec4(l9_148));
}
#else
{
l9_151=l9_150;
}
#endif
l9_103=l9_151;
}
#endif
vec3 l9_152=(l9_103.xyz*1.9921875)-vec3(1.0);
l9_102=vec4(l9_152.x,l9_152.y,l9_152.z,l9_103.w);
}
else
{
vec4 l9_153;
if (l9_101==1.0)
{
vec2 l9_154=((varTex01.xy-Port_Center_N014)*vec2(Tweak_N0))+Port_Center_N014;
vec4 l9_155;
#if (Tweak_N13Layout==2)
{
bool l9_156=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N13)!=0));
float l9_157=l9_154.x;
sc_SoftwareWrapEarly(l9_157,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x);
float l9_158=l9_157;
float l9_159=l9_154.y;
sc_SoftwareWrapEarly(l9_159,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y);
float l9_160=l9_159;
vec2 l9_161;
float l9_162;
#if (SC_USE_UV_MIN_MAX_Tweak_N13)
{
bool l9_163;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_163=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x==3;
}
#else
{
l9_163=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_164=l9_158;
float l9_165=1.0;
sc_ClampUV(l9_164,Tweak_N13UvMinMax.x,Tweak_N13UvMinMax.z,l9_163,l9_165);
float l9_166=l9_164;
float l9_167=l9_165;
bool l9_168;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_168=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y==3;
}
#else
{
l9_168=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_169=l9_160;
float l9_170=l9_167;
sc_ClampUV(l9_169,Tweak_N13UvMinMax.y,Tweak_N13UvMinMax.w,l9_168,l9_170);
l9_162=l9_170;
l9_161=vec2(l9_166,l9_169);
}
#else
{
l9_162=1.0;
l9_161=vec2(l9_158,l9_160);
}
#endif
vec2 l9_171=sc_TransformUV(l9_161,(int(SC_USE_UV_TRANSFORM_Tweak_N13)!=0),Tweak_N13Transform);
float l9_172=l9_171.x;
float l9_173=l9_162;
sc_SoftwareWrapLate(l9_172,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x,l9_156,l9_173);
float l9_174=l9_171.y;
float l9_175=l9_173;
sc_SoftwareWrapLate(l9_174,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y,l9_156,l9_175);
float l9_176=l9_175;
vec3 l9_177=sc_SamplingCoordsViewToGlobal(vec2(l9_172,l9_174),Tweak_N13Layout,Tweak_N13GetStereoViewIndex());
vec4 l9_178=texture(Tweak_N13ArrSC,l9_177,0.0);
vec4 l9_179;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_179=mix(Tweak_N13BorderColor,l9_178,vec4(l9_176));
}
#else
{
l9_179=l9_178;
}
#endif
l9_155=l9_179;
}
#else
{
bool l9_180=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N13)!=0));
float l9_181=l9_154.x;
sc_SoftwareWrapEarly(l9_181,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x);
float l9_182=l9_181;
float l9_183=l9_154.y;
sc_SoftwareWrapEarly(l9_183,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y);
float l9_184=l9_183;
vec2 l9_185;
float l9_186;
#if (SC_USE_UV_MIN_MAX_Tweak_N13)
{
bool l9_187;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_187=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x==3;
}
#else
{
l9_187=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_188=l9_182;
float l9_189=1.0;
sc_ClampUV(l9_188,Tweak_N13UvMinMax.x,Tweak_N13UvMinMax.z,l9_187,l9_189);
float l9_190=l9_188;
float l9_191=l9_189;
bool l9_192;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_192=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y==3;
}
#else
{
l9_192=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_193=l9_184;
float l9_194=l9_191;
sc_ClampUV(l9_193,Tweak_N13UvMinMax.y,Tweak_N13UvMinMax.w,l9_192,l9_194);
l9_186=l9_194;
l9_185=vec2(l9_190,l9_193);
}
#else
{
l9_186=1.0;
l9_185=vec2(l9_182,l9_184);
}
#endif
vec2 l9_195=sc_TransformUV(l9_185,(int(SC_USE_UV_TRANSFORM_Tweak_N13)!=0),Tweak_N13Transform);
float l9_196=l9_195.x;
float l9_197=l9_186;
sc_SoftwareWrapLate(l9_196,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x,l9_180,l9_197);
float l9_198=l9_195.y;
float l9_199=l9_197;
sc_SoftwareWrapLate(l9_198,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y,l9_180,l9_199);
float l9_200=l9_199;
vec3 l9_201=sc_SamplingCoordsViewToGlobal(vec2(l9_196,l9_198),Tweak_N13Layout,Tweak_N13GetStereoViewIndex());
vec4 l9_202=texture(Tweak_N13,l9_201.xy,0.0);
vec4 l9_203;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_203=mix(Tweak_N13BorderColor,l9_202,vec4(l9_200));
}
#else
{
l9_203=l9_202;
}
#endif
l9_155=l9_203;
}
#endif
vec3 l9_204=(l9_155.xyz*1.9921875)-vec3(1.0);
l9_153=vec4(l9_204.x,l9_204.y,l9_204.z,l9_155.w);
}
else
{
vec4 l9_205;
if (l9_101==2.0)
{
vec2 l9_206=((varTex01.xy-Port_Center_N015)*vec2(Tweak_N22))+Port_Center_N015;
vec4 l9_207;
#if (Tweak_N17Layout==2)
{
bool l9_208=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N17)!=0));
float l9_209=l9_206.x;
sc_SoftwareWrapEarly(l9_209,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x);
float l9_210=l9_209;
float l9_211=l9_206.y;
sc_SoftwareWrapEarly(l9_211,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y);
float l9_212=l9_211;
vec2 l9_213;
float l9_214;
#if (SC_USE_UV_MIN_MAX_Tweak_N17)
{
bool l9_215;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_215=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x==3;
}
#else
{
l9_215=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_216=l9_210;
float l9_217=1.0;
sc_ClampUV(l9_216,Tweak_N17UvMinMax.x,Tweak_N17UvMinMax.z,l9_215,l9_217);
float l9_218=l9_216;
float l9_219=l9_217;
bool l9_220;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_220=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y==3;
}
#else
{
l9_220=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_221=l9_212;
float l9_222=l9_219;
sc_ClampUV(l9_221,Tweak_N17UvMinMax.y,Tweak_N17UvMinMax.w,l9_220,l9_222);
l9_214=l9_222;
l9_213=vec2(l9_218,l9_221);
}
#else
{
l9_214=1.0;
l9_213=vec2(l9_210,l9_212);
}
#endif
vec2 l9_223=sc_TransformUV(l9_213,(int(SC_USE_UV_TRANSFORM_Tweak_N17)!=0),Tweak_N17Transform);
float l9_224=l9_223.x;
float l9_225=l9_214;
sc_SoftwareWrapLate(l9_224,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x,l9_208,l9_225);
float l9_226=l9_223.y;
float l9_227=l9_225;
sc_SoftwareWrapLate(l9_226,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y,l9_208,l9_227);
float l9_228=l9_227;
vec3 l9_229=sc_SamplingCoordsViewToGlobal(vec2(l9_224,l9_226),Tweak_N17Layout,Tweak_N17GetStereoViewIndex());
vec4 l9_230=texture(Tweak_N17ArrSC,l9_229,0.0);
vec4 l9_231;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_231=mix(Tweak_N17BorderColor,l9_230,vec4(l9_228));
}
#else
{
l9_231=l9_230;
}
#endif
l9_207=l9_231;
}
#else
{
bool l9_232=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N17)!=0));
float l9_233=l9_206.x;
sc_SoftwareWrapEarly(l9_233,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x);
float l9_234=l9_233;
float l9_235=l9_206.y;
sc_SoftwareWrapEarly(l9_235,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y);
float l9_236=l9_235;
vec2 l9_237;
float l9_238;
#if (SC_USE_UV_MIN_MAX_Tweak_N17)
{
bool l9_239;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_239=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x==3;
}
#else
{
l9_239=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_240=l9_234;
float l9_241=1.0;
sc_ClampUV(l9_240,Tweak_N17UvMinMax.x,Tweak_N17UvMinMax.z,l9_239,l9_241);
float l9_242=l9_240;
float l9_243=l9_241;
bool l9_244;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_244=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y==3;
}
#else
{
l9_244=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_245=l9_236;
float l9_246=l9_243;
sc_ClampUV(l9_245,Tweak_N17UvMinMax.y,Tweak_N17UvMinMax.w,l9_244,l9_246);
l9_238=l9_246;
l9_237=vec2(l9_242,l9_245);
}
#else
{
l9_238=1.0;
l9_237=vec2(l9_234,l9_236);
}
#endif
vec2 l9_247=sc_TransformUV(l9_237,(int(SC_USE_UV_TRANSFORM_Tweak_N17)!=0),Tweak_N17Transform);
float l9_248=l9_247.x;
float l9_249=l9_238;
sc_SoftwareWrapLate(l9_248,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x,l9_232,l9_249);
float l9_250=l9_247.y;
float l9_251=l9_249;
sc_SoftwareWrapLate(l9_250,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y,l9_232,l9_251);
float l9_252=l9_251;
vec3 l9_253=sc_SamplingCoordsViewToGlobal(vec2(l9_248,l9_250),Tweak_N17Layout,Tweak_N17GetStereoViewIndex());
vec4 l9_254=texture(Tweak_N17,l9_253.xy,0.0);
vec4 l9_255;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_255=mix(Tweak_N17BorderColor,l9_254,vec4(l9_252));
}
#else
{
l9_255=l9_254;
}
#endif
l9_207=l9_255;
}
#endif
vec3 l9_256=(l9_207.xyz*1.9921875)-vec3(1.0);
l9_205=vec4(l9_256.x,l9_256.y,l9_256.z,l9_207.w);
}
else
{
vec2 l9_257=((varTex01.xy-Port_Center_N019)*vec2(Tweak_N21))+Port_Center_N019;
vec4 l9_258;
#if (Tweak_N20Layout==2)
{
bool l9_259=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N20)!=0));
float l9_260=l9_257.x;
sc_SoftwareWrapEarly(l9_260,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x);
float l9_261=l9_260;
float l9_262=l9_257.y;
sc_SoftwareWrapEarly(l9_262,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y);
float l9_263=l9_262;
vec2 l9_264;
float l9_265;
#if (SC_USE_UV_MIN_MAX_Tweak_N20)
{
bool l9_266;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_266=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x==3;
}
#else
{
l9_266=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_267=l9_261;
float l9_268=1.0;
sc_ClampUV(l9_267,Tweak_N20UvMinMax.x,Tweak_N20UvMinMax.z,l9_266,l9_268);
float l9_269=l9_267;
float l9_270=l9_268;
bool l9_271;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_271=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y==3;
}
#else
{
l9_271=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_272=l9_263;
float l9_273=l9_270;
sc_ClampUV(l9_272,Tweak_N20UvMinMax.y,Tweak_N20UvMinMax.w,l9_271,l9_273);
l9_265=l9_273;
l9_264=vec2(l9_269,l9_272);
}
#else
{
l9_265=1.0;
l9_264=vec2(l9_261,l9_263);
}
#endif
vec2 l9_274=sc_TransformUV(l9_264,(int(SC_USE_UV_TRANSFORM_Tweak_N20)!=0),Tweak_N20Transform);
float l9_275=l9_274.x;
float l9_276=l9_265;
sc_SoftwareWrapLate(l9_275,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x,l9_259,l9_276);
float l9_277=l9_274.y;
float l9_278=l9_276;
sc_SoftwareWrapLate(l9_277,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y,l9_259,l9_278);
float l9_279=l9_278;
vec3 l9_280=sc_SamplingCoordsViewToGlobal(vec2(l9_275,l9_277),Tweak_N20Layout,Tweak_N20GetStereoViewIndex());
vec4 l9_281=texture(Tweak_N20ArrSC,l9_280,0.0);
vec4 l9_282;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_282=mix(Tweak_N20BorderColor,l9_281,vec4(l9_279));
}
#else
{
l9_282=l9_281;
}
#endif
l9_258=l9_282;
}
#else
{
bool l9_283=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N20)!=0));
float l9_284=l9_257.x;
sc_SoftwareWrapEarly(l9_284,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x);
float l9_285=l9_284;
float l9_286=l9_257.y;
sc_SoftwareWrapEarly(l9_286,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y);
float l9_287=l9_286;
vec2 l9_288;
float l9_289;
#if (SC_USE_UV_MIN_MAX_Tweak_N20)
{
bool l9_290;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_290=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x==3;
}
#else
{
l9_290=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_291=l9_285;
float l9_292=1.0;
sc_ClampUV(l9_291,Tweak_N20UvMinMax.x,Tweak_N20UvMinMax.z,l9_290,l9_292);
float l9_293=l9_291;
float l9_294=l9_292;
bool l9_295;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_295=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y==3;
}
#else
{
l9_295=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_296=l9_287;
float l9_297=l9_294;
sc_ClampUV(l9_296,Tweak_N20UvMinMax.y,Tweak_N20UvMinMax.w,l9_295,l9_297);
l9_289=l9_297;
l9_288=vec2(l9_293,l9_296);
}
#else
{
l9_289=1.0;
l9_288=vec2(l9_285,l9_287);
}
#endif
vec2 l9_298=sc_TransformUV(l9_288,(int(SC_USE_UV_TRANSFORM_Tweak_N20)!=0),Tweak_N20Transform);
float l9_299=l9_298.x;
float l9_300=l9_289;
sc_SoftwareWrapLate(l9_299,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x,l9_283,l9_300);
float l9_301=l9_298.y;
float l9_302=l9_300;
sc_SoftwareWrapLate(l9_301,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y,l9_283,l9_302);
float l9_303=l9_302;
vec3 l9_304=sc_SamplingCoordsViewToGlobal(vec2(l9_299,l9_301),Tweak_N20Layout,Tweak_N20GetStereoViewIndex());
vec4 l9_305=texture(Tweak_N20,l9_304.xy,0.0);
vec4 l9_306;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_306=mix(Tweak_N20BorderColor,l9_305,vec4(l9_303));
}
#else
{
l9_306=l9_305;
}
#endif
l9_258=l9_306;
}
#endif
vec3 l9_307=(l9_258.xyz*1.9921875)-vec3(1.0);
l9_205=vec4(l9_307.x,l9_307.y,l9_307.z,l9_258.w);
}
l9_153=l9_205;
}
l9_102=l9_153;
}
vec4 l9_308;
#if (materialParamsTexLayout==2)
{
bool l9_309=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_materialParamsTex)!=0));
float l9_310=varTex01.x;
sc_SoftwareWrapEarly(l9_310,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x);
float l9_311=l9_310;
float l9_312=varTex01.y;
sc_SoftwareWrapEarly(l9_312,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y);
float l9_313=l9_312;
vec2 l9_314;
float l9_315;
#if (SC_USE_UV_MIN_MAX_materialParamsTex)
{
bool l9_316;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_316=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x==3;
}
#else
{
l9_316=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_317=l9_311;
float l9_318=1.0;
sc_ClampUV(l9_317,materialParamsTexUvMinMax.x,materialParamsTexUvMinMax.z,l9_316,l9_318);
float l9_319=l9_317;
float l9_320=l9_318;
bool l9_321;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_321=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y==3;
}
#else
{
l9_321=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_322=l9_313;
float l9_323=l9_320;
sc_ClampUV(l9_322,materialParamsTexUvMinMax.y,materialParamsTexUvMinMax.w,l9_321,l9_323);
l9_315=l9_323;
l9_314=vec2(l9_319,l9_322);
}
#else
{
l9_315=1.0;
l9_314=vec2(l9_311,l9_313);
}
#endif
vec2 l9_324=sc_TransformUV(l9_314,(int(SC_USE_UV_TRANSFORM_materialParamsTex)!=0),materialParamsTexTransform);
float l9_325=l9_324.x;
float l9_326=l9_315;
sc_SoftwareWrapLate(l9_325,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x,l9_309,l9_326);
float l9_327=l9_324.y;
float l9_328=l9_326;
sc_SoftwareWrapLate(l9_327,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y,l9_309,l9_328);
float l9_329=l9_328;
vec3 l9_330=sc_SamplingCoordsViewToGlobal(vec2(l9_325,l9_327),materialParamsTexLayout,materialParamsTexGetStereoViewIndex());
vec4 l9_331=texture(materialParamsTexArrSC,l9_330,0.0);
vec4 l9_332;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_332=mix(materialParamsTexBorderColor,l9_331,vec4(l9_329));
}
#else
{
l9_332=l9_331;
}
#endif
l9_308=l9_332;
}
#else
{
bool l9_333=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_materialParamsTex)!=0));
float l9_334=varTex01.x;
sc_SoftwareWrapEarly(l9_334,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x);
float l9_335=l9_334;
float l9_336=varTex01.y;
sc_SoftwareWrapEarly(l9_336,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y);
float l9_337=l9_336;
vec2 l9_338;
float l9_339;
#if (SC_USE_UV_MIN_MAX_materialParamsTex)
{
bool l9_340;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_340=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x==3;
}
#else
{
l9_340=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_341=l9_335;
float l9_342=1.0;
sc_ClampUV(l9_341,materialParamsTexUvMinMax.x,materialParamsTexUvMinMax.z,l9_340,l9_342);
float l9_343=l9_341;
float l9_344=l9_342;
bool l9_345;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_345=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y==3;
}
#else
{
l9_345=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_346=l9_337;
float l9_347=l9_344;
sc_ClampUV(l9_346,materialParamsTexUvMinMax.y,materialParamsTexUvMinMax.w,l9_345,l9_347);
l9_339=l9_347;
l9_338=vec2(l9_343,l9_346);
}
#else
{
l9_339=1.0;
l9_338=vec2(l9_335,l9_337);
}
#endif
vec2 l9_348=sc_TransformUV(l9_338,(int(SC_USE_UV_TRANSFORM_materialParamsTex)!=0),materialParamsTexTransform);
float l9_349=l9_348.x;
float l9_350=l9_339;
sc_SoftwareWrapLate(l9_349,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x,l9_333,l9_350);
float l9_351=l9_348.y;
float l9_352=l9_350;
sc_SoftwareWrapLate(l9_351,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y,l9_333,l9_352);
float l9_353=l9_352;
vec3 l9_354=sc_SamplingCoordsViewToGlobal(vec2(l9_349,l9_351),materialParamsTexLayout,materialParamsTexGetStereoViewIndex());
vec4 l9_355=texture(materialParamsTex,l9_354.xy,0.0);
vec4 l9_356;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_356=mix(materialParamsTexBorderColor,l9_355,vec4(l9_353));
}
#else
{
l9_356=l9_355;
}
#endif
l9_308=l9_356;
}
#endif
vec3 l9_357;
#if (!sc_ProjectiveShadowsCaster)
{
l9_357=mat3(l9_0,cross(l9_1,l9_0)*varTangent.w,l9_1)*l9_102.xyz;
}
#else
{
l9_357=vec3(0.0);
}
#endif
float l9_358=clamp(l9_2.w,0.0,1.0);
#if (sc_BlendMode_AlphaTest)
{
if (l9_358<alphaTestThreshold)
{
discard;
}
}
#endif
#if (ENABLE_STIPPLE_PATTERN_TEST)
{
if (l9_358<((mod(dot(floor(mod(gl_FragCoord.xy,vec2(4.0))),vec2(4.0,1.0))*9.0,16.0)+1.0)/17.0))
{
discard;
}
}
#endif
uvec3 l9_359=uvec3(round((varPosAndMotion.xyz-sc_RayTracingOriginOffset)*sc_RayTracingOriginScale));
sc_RayTracingPositionAndMask=uvec4(l9_359.x,l9_359.y,l9_359.z,sc_RayTracingPositionAndMask.w);
sc_RayTracingPositionAndMask.w=sc_RayTracingReceiverMask;
vec3 l9_360=l9_357/vec3(dot(abs(l9_357),vec3(1.0)));
vec2 l9_361=vec2(clamp(-l9_360.z,0.0,1.0));
vec2 l9_362=l9_360.xy;
uint l9_363=packHalf2x16(l9_362+mix(-l9_361,l9_361,step(vec2(0.0),l9_362)));
uvec2 l9_364=uvec2(l9_363&65535u,l9_363>>16u);
sc_RayTracingNormalAndMore=uvec4(l9_364.x,l9_364.y,sc_RayTracingNormalAndMore.z,sc_RayTracingNormalAndMore.w);
sc_RayTracingNormalAndMore.z=0u;
sc_RayTracingNormalAndMore.w=uint(clamp(l9_308.y,0.0,1.0)*1000.0)|((sc_RayTracingReceiverId%32u)<<10u);
}
#else // #if SC_RT_RECEIVER_MODE
#ifndef sc_FramebufferFetch
#define sc_FramebufferFetch 0
#elif sc_FramebufferFetch==1
#undef sc_FramebufferFetch
#define sc_FramebufferFetch 1
#endif
struct sc_RayTracingHitPayload
{
vec3 viewDirWS;
vec3 positionWS;
vec3 normalWS;
vec4 tangentWS;
vec4 color;
vec2 uv0;
vec2 uv1;
vec2 uv2;
vec2 uv3;
uvec2 id;
};
struct SurfaceProperties
{
vec3 albedo;
float opacity;
vec3 normal;
vec3 positionWS;
vec3 viewDirWS;
float metallic;
float roughness;
vec3 emissive;
vec3 ao;
vec3 specularAo;
vec3 bakedShadows;
vec3 specColor;
};
struct LightingComponents
{
vec3 directDiffuse;
vec3 directSpecular;
vec3 indirectDiffuse;
vec3 indirectSpecular;
vec3 emitted;
vec3 transmitted;
};
struct LightProperties
{
vec3 direction;
vec3 color;
float attenuation;
};
struct sc_SphericalGaussianLight_t
{
vec3 color;
float sharpness;
vec3 axis;
};
#ifndef sc_StereoRenderingMode
#define sc_StereoRenderingMode 0
#endif
#ifndef sc_EnvmapDiffuseHasSwappedViews
#define sc_EnvmapDiffuseHasSwappedViews 0
#elif sc_EnvmapDiffuseHasSwappedViews==1
#undef sc_EnvmapDiffuseHasSwappedViews
#define sc_EnvmapDiffuseHasSwappedViews 1
#endif
#ifndef sc_EnvmapDiffuseLayout
#define sc_EnvmapDiffuseLayout 0
#endif
#ifndef sc_EnvmapSpecularHasSwappedViews
#define sc_EnvmapSpecularHasSwappedViews 0
#elif sc_EnvmapSpecularHasSwappedViews==1
#undef sc_EnvmapSpecularHasSwappedViews
#define sc_EnvmapSpecularHasSwappedViews 1
#endif
#ifndef sc_EnvmapSpecularLayout
#define sc_EnvmapSpecularLayout 0
#endif
#ifndef sc_ScreenTextureHasSwappedViews
#define sc_ScreenTextureHasSwappedViews 0
#elif sc_ScreenTextureHasSwappedViews==1
#undef sc_ScreenTextureHasSwappedViews
#define sc_ScreenTextureHasSwappedViews 1
#endif
#ifndef sc_ScreenTextureLayout
#define sc_ScreenTextureLayout 0
#endif
#ifndef sc_RayTracingReflectionsHasSwappedViews
#define sc_RayTracingReflectionsHasSwappedViews 0
#elif sc_RayTracingReflectionsHasSwappedViews==1
#undef sc_RayTracingReflectionsHasSwappedViews
#define sc_RayTracingReflectionsHasSwappedViews 1
#endif
#ifndef sc_RayTracingReflectionsLayout
#define sc_RayTracingReflectionsLayout 0
#endif
#ifndef sc_RayTracingGlobalIlluminationHasSwappedViews
#define sc_RayTracingGlobalIlluminationHasSwappedViews 0
#elif sc_RayTracingGlobalIlluminationHasSwappedViews==1
#undef sc_RayTracingGlobalIlluminationHasSwappedViews
#define sc_RayTracingGlobalIlluminationHasSwappedViews 1
#endif
#ifndef sc_RayTracingGlobalIlluminationLayout
#define sc_RayTracingGlobalIlluminationLayout 0
#endif
#ifndef sc_RayTracingShadowsHasSwappedViews
#define sc_RayTracingShadowsHasSwappedViews 0
#elif sc_RayTracingShadowsHasSwappedViews==1
#undef sc_RayTracingShadowsHasSwappedViews
#define sc_RayTracingShadowsHasSwappedViews 1
#endif
#ifndef sc_RayTracingShadowsLayout
#define sc_RayTracingShadowsLayout 0
#endif
#ifndef sc_BlendMode_Normal
#define sc_BlendMode_Normal 0
#elif sc_BlendMode_Normal==1
#undef sc_BlendMode_Normal
#define sc_BlendMode_Normal 1
#endif
#ifndef sc_BlendMode_AlphaToCoverage
#define sc_BlendMode_AlphaToCoverage 0
#elif sc_BlendMode_AlphaToCoverage==1
#undef sc_BlendMode_AlphaToCoverage
#define sc_BlendMode_AlphaToCoverage 1
#endif
#ifndef sc_BlendMode_PremultipliedAlphaHardware
#define sc_BlendMode_PremultipliedAlphaHardware 0
#elif sc_BlendMode_PremultipliedAlphaHardware==1
#undef sc_BlendMode_PremultipliedAlphaHardware
#define sc_BlendMode_PremultipliedAlphaHardware 1
#endif
#ifndef sc_BlendMode_PremultipliedAlphaAuto
#define sc_BlendMode_PremultipliedAlphaAuto 0
#elif sc_BlendMode_PremultipliedAlphaAuto==1
#undef sc_BlendMode_PremultipliedAlphaAuto
#define sc_BlendMode_PremultipliedAlphaAuto 1
#endif
#ifndef sc_BlendMode_PremultipliedAlpha
#define sc_BlendMode_PremultipliedAlpha 0
#elif sc_BlendMode_PremultipliedAlpha==1
#undef sc_BlendMode_PremultipliedAlpha
#define sc_BlendMode_PremultipliedAlpha 1
#endif
#ifndef sc_BlendMode_AddWithAlphaFactor
#define sc_BlendMode_AddWithAlphaFactor 0
#elif sc_BlendMode_AddWithAlphaFactor==1
#undef sc_BlendMode_AddWithAlphaFactor
#define sc_BlendMode_AddWithAlphaFactor 1
#endif
#ifndef sc_BlendMode_AlphaTest
#define sc_BlendMode_AlphaTest 0
#elif sc_BlendMode_AlphaTest==1
#undef sc_BlendMode_AlphaTest
#define sc_BlendMode_AlphaTest 1
#endif
#ifndef sc_BlendMode_Multiply
#define sc_BlendMode_Multiply 0
#elif sc_BlendMode_Multiply==1
#undef sc_BlendMode_Multiply
#define sc_BlendMode_Multiply 1
#endif
#ifndef sc_BlendMode_MultiplyOriginal
#define sc_BlendMode_MultiplyOriginal 0
#elif sc_BlendMode_MultiplyOriginal==1
#undef sc_BlendMode_MultiplyOriginal
#define sc_BlendMode_MultiplyOriginal 1
#endif
#ifndef sc_BlendMode_ColoredGlass
#define sc_BlendMode_ColoredGlass 0
#elif sc_BlendMode_ColoredGlass==1
#undef sc_BlendMode_ColoredGlass
#define sc_BlendMode_ColoredGlass 1
#endif
#ifndef sc_BlendMode_Add
#define sc_BlendMode_Add 0
#elif sc_BlendMode_Add==1
#undef sc_BlendMode_Add
#define sc_BlendMode_Add 1
#endif
#ifndef sc_BlendMode_Screen
#define sc_BlendMode_Screen 0
#elif sc_BlendMode_Screen==1
#undef sc_BlendMode_Screen
#define sc_BlendMode_Screen 1
#endif
#ifndef sc_BlendMode_Min
#define sc_BlendMode_Min 0
#elif sc_BlendMode_Min==1
#undef sc_BlendMode_Min
#define sc_BlendMode_Min 1
#endif
#ifndef sc_BlendMode_Max
#define sc_BlendMode_Max 0
#elif sc_BlendMode_Max==1
#undef sc_BlendMode_Max
#define sc_BlendMode_Max 1
#endif
#ifndef sc_ProjectiveShadowsReceiver
#define sc_ProjectiveShadowsReceiver 0
#elif sc_ProjectiveShadowsReceiver==1
#undef sc_ProjectiveShadowsReceiver
#define sc_ProjectiveShadowsReceiver 1
#endif
#ifndef sc_MotionVectorsPass
#define sc_MotionVectorsPass 0
#elif sc_MotionVectorsPass==1
#undef sc_MotionVectorsPass
#define sc_MotionVectorsPass 1
#endif
#ifndef sc_StereoRendering_IsClipDistanceEnabled
#define sc_StereoRendering_IsClipDistanceEnabled 0
#endif
#ifndef sc_ShaderCacheConstant
#define sc_ShaderCacheConstant 0
#endif
#ifndef sc_FramebufferFetch
#define sc_FramebufferFetch 0
#elif sc_FramebufferFetch==1
#undef sc_FramebufferFetch
#define sc_FramebufferFetch 1
#endif
#ifndef sc_SSAOEnabled
#define sc_SSAOEnabled 0
#elif sc_SSAOEnabled==1
#undef sc_SSAOEnabled
#define sc_SSAOEnabled 1
#endif
#ifndef sc_NumStereoViews
#define sc_NumStereoViews 1
#endif
#ifndef sc_RayTracingCasterForceOpaque
#define sc_RayTracingCasterForceOpaque 0
#elif sc_RayTracingCasterForceOpaque==1
#undef sc_RayTracingCasterForceOpaque
#define sc_RayTracingCasterForceOpaque 1
#endif
#ifndef SC_DEVICE_CLASS
#define SC_DEVICE_CLASS -1
#endif
#ifndef intensityTextureHasSwappedViews
#define intensityTextureHasSwappedViews 0
#elif intensityTextureHasSwappedViews==1
#undef intensityTextureHasSwappedViews
#define intensityTextureHasSwappedViews 1
#endif
#ifndef BLEND_MODE_REALISTIC
#define BLEND_MODE_REALISTIC 0
#elif BLEND_MODE_REALISTIC==1
#undef BLEND_MODE_REALISTIC
#define BLEND_MODE_REALISTIC 1
#endif
#ifndef BLEND_MODE_FORGRAY
#define BLEND_MODE_FORGRAY 0
#elif BLEND_MODE_FORGRAY==1
#undef BLEND_MODE_FORGRAY
#define BLEND_MODE_FORGRAY 1
#endif
#ifndef BLEND_MODE_NOTBRIGHT
#define BLEND_MODE_NOTBRIGHT 0
#elif BLEND_MODE_NOTBRIGHT==1
#undef BLEND_MODE_NOTBRIGHT
#define BLEND_MODE_NOTBRIGHT 1
#endif
#ifndef BLEND_MODE_DIVISION
#define BLEND_MODE_DIVISION 0
#elif BLEND_MODE_DIVISION==1
#undef BLEND_MODE_DIVISION
#define BLEND_MODE_DIVISION 1
#endif
#ifndef BLEND_MODE_BRIGHT
#define BLEND_MODE_BRIGHT 0
#elif BLEND_MODE_BRIGHT==1
#undef BLEND_MODE_BRIGHT
#define BLEND_MODE_BRIGHT 1
#endif
#ifndef BLEND_MODE_INTENSE
#define BLEND_MODE_INTENSE 0
#elif BLEND_MODE_INTENSE==1
#undef BLEND_MODE_INTENSE
#define BLEND_MODE_INTENSE 1
#endif
#ifndef intensityTextureLayout
#define intensityTextureLayout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_intensityTexture
#define SC_USE_UV_TRANSFORM_intensityTexture 0
#elif SC_USE_UV_TRANSFORM_intensityTexture==1
#undef SC_USE_UV_TRANSFORM_intensityTexture
#define SC_USE_UV_TRANSFORM_intensityTexture 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_intensityTexture
#define SC_SOFTWARE_WRAP_MODE_U_intensityTexture -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_intensityTexture
#define SC_SOFTWARE_WRAP_MODE_V_intensityTexture -1
#endif
#ifndef SC_USE_UV_MIN_MAX_intensityTexture
#define SC_USE_UV_MIN_MAX_intensityTexture 0
#elif SC_USE_UV_MIN_MAX_intensityTexture==1
#undef SC_USE_UV_MIN_MAX_intensityTexture
#define SC_USE_UV_MIN_MAX_intensityTexture 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_intensityTexture
#define SC_USE_CLAMP_TO_BORDER_intensityTexture 0
#elif SC_USE_CLAMP_TO_BORDER_intensityTexture==1
#undef SC_USE_CLAMP_TO_BORDER_intensityTexture
#define SC_USE_CLAMP_TO_BORDER_intensityTexture 1
#endif
#ifndef BLEND_MODE_LIGHTEN
#define BLEND_MODE_LIGHTEN 0
#elif BLEND_MODE_LIGHTEN==1
#undef BLEND_MODE_LIGHTEN
#define BLEND_MODE_LIGHTEN 1
#endif
#ifndef BLEND_MODE_DARKEN
#define BLEND_MODE_DARKEN 0
#elif BLEND_MODE_DARKEN==1
#undef BLEND_MODE_DARKEN
#define BLEND_MODE_DARKEN 1
#endif
#ifndef BLEND_MODE_DIVIDE
#define BLEND_MODE_DIVIDE 0
#elif BLEND_MODE_DIVIDE==1
#undef BLEND_MODE_DIVIDE
#define BLEND_MODE_DIVIDE 1
#endif
#ifndef BLEND_MODE_AVERAGE
#define BLEND_MODE_AVERAGE 0
#elif BLEND_MODE_AVERAGE==1
#undef BLEND_MODE_AVERAGE
#define BLEND_MODE_AVERAGE 1
#endif
#ifndef BLEND_MODE_SUBTRACT
#define BLEND_MODE_SUBTRACT 0
#elif BLEND_MODE_SUBTRACT==1
#undef BLEND_MODE_SUBTRACT
#define BLEND_MODE_SUBTRACT 1
#endif
#ifndef BLEND_MODE_DIFFERENCE
#define BLEND_MODE_DIFFERENCE 0
#elif BLEND_MODE_DIFFERENCE==1
#undef BLEND_MODE_DIFFERENCE
#define BLEND_MODE_DIFFERENCE 1
#endif
#ifndef BLEND_MODE_NEGATION
#define BLEND_MODE_NEGATION 0
#elif BLEND_MODE_NEGATION==1
#undef BLEND_MODE_NEGATION
#define BLEND_MODE_NEGATION 1
#endif
#ifndef BLEND_MODE_EXCLUSION
#define BLEND_MODE_EXCLUSION 0
#elif BLEND_MODE_EXCLUSION==1
#undef BLEND_MODE_EXCLUSION
#define BLEND_MODE_EXCLUSION 1
#endif
#ifndef BLEND_MODE_OVERLAY
#define BLEND_MODE_OVERLAY 0
#elif BLEND_MODE_OVERLAY==1
#undef BLEND_MODE_OVERLAY
#define BLEND_MODE_OVERLAY 1
#endif
#ifndef BLEND_MODE_SOFT_LIGHT
#define BLEND_MODE_SOFT_LIGHT 0
#elif BLEND_MODE_SOFT_LIGHT==1
#undef BLEND_MODE_SOFT_LIGHT
#define BLEND_MODE_SOFT_LIGHT 1
#endif
#ifndef BLEND_MODE_HARD_LIGHT
#define BLEND_MODE_HARD_LIGHT 0
#elif BLEND_MODE_HARD_LIGHT==1
#undef BLEND_MODE_HARD_LIGHT
#define BLEND_MODE_HARD_LIGHT 1
#endif
#ifndef BLEND_MODE_COLOR_DODGE
#define BLEND_MODE_COLOR_DODGE 0
#elif BLEND_MODE_COLOR_DODGE==1
#undef BLEND_MODE_COLOR_DODGE
#define BLEND_MODE_COLOR_DODGE 1
#endif
#ifndef BLEND_MODE_COLOR_BURN
#define BLEND_MODE_COLOR_BURN 0
#elif BLEND_MODE_COLOR_BURN==1
#undef BLEND_MODE_COLOR_BURN
#define BLEND_MODE_COLOR_BURN 1
#endif
#ifndef BLEND_MODE_LINEAR_LIGHT
#define BLEND_MODE_LINEAR_LIGHT 0
#elif BLEND_MODE_LINEAR_LIGHT==1
#undef BLEND_MODE_LINEAR_LIGHT
#define BLEND_MODE_LINEAR_LIGHT 1
#endif
#ifndef BLEND_MODE_VIVID_LIGHT
#define BLEND_MODE_VIVID_LIGHT 0
#elif BLEND_MODE_VIVID_LIGHT==1
#undef BLEND_MODE_VIVID_LIGHT
#define BLEND_MODE_VIVID_LIGHT 1
#endif
#ifndef BLEND_MODE_PIN_LIGHT
#define BLEND_MODE_PIN_LIGHT 0
#elif BLEND_MODE_PIN_LIGHT==1
#undef BLEND_MODE_PIN_LIGHT
#define BLEND_MODE_PIN_LIGHT 1
#endif
#ifndef BLEND_MODE_HARD_MIX
#define BLEND_MODE_HARD_MIX 0
#elif BLEND_MODE_HARD_MIX==1
#undef BLEND_MODE_HARD_MIX
#define BLEND_MODE_HARD_MIX 1
#endif
#ifndef BLEND_MODE_HARD_REFLECT
#define BLEND_MODE_HARD_REFLECT 0
#elif BLEND_MODE_HARD_REFLECT==1
#undef BLEND_MODE_HARD_REFLECT
#define BLEND_MODE_HARD_REFLECT 1
#endif
#ifndef BLEND_MODE_HARD_GLOW
#define BLEND_MODE_HARD_GLOW 0
#elif BLEND_MODE_HARD_GLOW==1
#undef BLEND_MODE_HARD_GLOW
#define BLEND_MODE_HARD_GLOW 1
#endif
#ifndef BLEND_MODE_HARD_PHOENIX
#define BLEND_MODE_HARD_PHOENIX 0
#elif BLEND_MODE_HARD_PHOENIX==1
#undef BLEND_MODE_HARD_PHOENIX
#define BLEND_MODE_HARD_PHOENIX 1
#endif
#ifndef BLEND_MODE_HUE
#define BLEND_MODE_HUE 0
#elif BLEND_MODE_HUE==1
#undef BLEND_MODE_HUE
#define BLEND_MODE_HUE 1
#endif
#ifndef BLEND_MODE_SATURATION
#define BLEND_MODE_SATURATION 0
#elif BLEND_MODE_SATURATION==1
#undef BLEND_MODE_SATURATION
#define BLEND_MODE_SATURATION 1
#endif
#ifndef BLEND_MODE_COLOR
#define BLEND_MODE_COLOR 0
#elif BLEND_MODE_COLOR==1
#undef BLEND_MODE_COLOR
#define BLEND_MODE_COLOR 1
#endif
#ifndef BLEND_MODE_LUMINOSITY
#define BLEND_MODE_LUMINOSITY 0
#elif BLEND_MODE_LUMINOSITY==1
#undef BLEND_MODE_LUMINOSITY
#define BLEND_MODE_LUMINOSITY 1
#endif
#ifndef sc_SkinBonesCount
#define sc_SkinBonesCount 0
#endif
#ifndef UseViewSpaceDepthVariant
#define UseViewSpaceDepthVariant 1
#elif UseViewSpaceDepthVariant==1
#undef UseViewSpaceDepthVariant
#define UseViewSpaceDepthVariant 1
#endif
#ifndef sc_OITDepthGatherPass
#define sc_OITDepthGatherPass 0
#elif sc_OITDepthGatherPass==1
#undef sc_OITDepthGatherPass
#define sc_OITDepthGatherPass 1
#endif
#ifndef sc_OITCompositingPass
#define sc_OITCompositingPass 0
#elif sc_OITCompositingPass==1
#undef sc_OITCompositingPass
#define sc_OITCompositingPass 1
#endif
#ifndef sc_OITDepthBoundsPass
#define sc_OITDepthBoundsPass 0
#elif sc_OITDepthBoundsPass==1
#undef sc_OITDepthBoundsPass
#define sc_OITDepthBoundsPass 1
#endif
#ifndef sc_OITMaxLayers4Plus1
#define sc_OITMaxLayers4Plus1 0
#elif sc_OITMaxLayers4Plus1==1
#undef sc_OITMaxLayers4Plus1
#define sc_OITMaxLayers4Plus1 1
#endif
#ifndef sc_OITMaxLayersVisualizeLayerCount
#define sc_OITMaxLayersVisualizeLayerCount 0
#elif sc_OITMaxLayersVisualizeLayerCount==1
#undef sc_OITMaxLayersVisualizeLayerCount
#define sc_OITMaxLayersVisualizeLayerCount 1
#endif
#ifndef sc_OITMaxLayers8
#define sc_OITMaxLayers8 0
#elif sc_OITMaxLayers8==1
#undef sc_OITMaxLayers8
#define sc_OITMaxLayers8 1
#endif
#ifndef sc_OITFrontLayerPass
#define sc_OITFrontLayerPass 0
#elif sc_OITFrontLayerPass==1
#undef sc_OITFrontLayerPass
#define sc_OITFrontLayerPass 1
#endif
#ifndef sc_OITDepthPrepass
#define sc_OITDepthPrepass 0
#elif sc_OITDepthPrepass==1
#undef sc_OITDepthPrepass
#define sc_OITDepthPrepass 1
#endif
#ifndef ENABLE_STIPPLE_PATTERN_TEST
#define ENABLE_STIPPLE_PATTERN_TEST 0
#elif ENABLE_STIPPLE_PATTERN_TEST==1
#undef ENABLE_STIPPLE_PATTERN_TEST
#define ENABLE_STIPPLE_PATTERN_TEST 1
#endif
#ifndef sc_ProjectiveShadowsCaster
#define sc_ProjectiveShadowsCaster 0
#elif sc_ProjectiveShadowsCaster==1
#undef sc_ProjectiveShadowsCaster
#define sc_ProjectiveShadowsCaster 1
#endif
#ifndef sc_RenderAlphaToColor
#define sc_RenderAlphaToColor 0
#elif sc_RenderAlphaToColor==1
#undef sc_RenderAlphaToColor
#define sc_RenderAlphaToColor 1
#endif
#ifndef sc_BlendMode_Custom
#define sc_BlendMode_Custom 0
#elif sc_BlendMode_Custom==1
#undef sc_BlendMode_Custom
#define sc_BlendMode_Custom 1
#endif
#ifndef sc_Voxelization
#define sc_Voxelization 0
#elif sc_Voxelization==1
#undef sc_Voxelization
#define sc_Voxelization 1
#endif
#ifndef sc_OutputBounds
#define sc_OutputBounds 0
#elif sc_OutputBounds==1
#undef sc_OutputBounds
#define sc_OutputBounds 1
#endif
#ifndef baseTexHasSwappedViews
#define baseTexHasSwappedViews 0
#elif baseTexHasSwappedViews==1
#undef baseTexHasSwappedViews
#define baseTexHasSwappedViews 1
#endif
#ifndef Tweak_N10HasSwappedViews
#define Tweak_N10HasSwappedViews 0
#elif Tweak_N10HasSwappedViews==1
#undef Tweak_N10HasSwappedViews
#define Tweak_N10HasSwappedViews 1
#endif
#ifndef normalTexHasSwappedViews
#define normalTexHasSwappedViews 0
#elif normalTexHasSwappedViews==1
#undef normalTexHasSwappedViews
#define normalTexHasSwappedViews 1
#endif
#ifndef Tweak_N13HasSwappedViews
#define Tweak_N13HasSwappedViews 0
#elif Tweak_N13HasSwappedViews==1
#undef Tweak_N13HasSwappedViews
#define Tweak_N13HasSwappedViews 1
#endif
#ifndef Tweak_N17HasSwappedViews
#define Tweak_N17HasSwappedViews 0
#elif Tweak_N17HasSwappedViews==1
#undef Tweak_N17HasSwappedViews
#define Tweak_N17HasSwappedViews 1
#endif
#ifndef Tweak_N20HasSwappedViews
#define Tweak_N20HasSwappedViews 0
#elif Tweak_N20HasSwappedViews==1
#undef Tweak_N20HasSwappedViews
#define Tweak_N20HasSwappedViews 1
#endif
#ifndef materialParamsTexHasSwappedViews
#define materialParamsTexHasSwappedViews 0
#elif materialParamsTexHasSwappedViews==1
#undef materialParamsTexHasSwappedViews
#define materialParamsTexHasSwappedViews 1
#endif
#ifndef sc_EnvLightMode
#define sc_EnvLightMode 0
#endif
#ifndef sc_AmbientLightMode_EnvironmentMap
#define sc_AmbientLightMode_EnvironmentMap 0
#endif
#ifndef sc_AmbientLightMode_FromCamera
#define sc_AmbientLightMode_FromCamera 0
#endif
#ifndef sc_LightEstimation
#define sc_LightEstimation 0
#elif sc_LightEstimation==1
#undef sc_LightEstimation
#define sc_LightEstimation 1
#endif
struct sc_LightEstimationData_t
{
sc_SphericalGaussianLight_t sg[12];
vec3 ambientLight;
};
#ifndef sc_LightEstimationSGCount
#define sc_LightEstimationSGCount 0
#endif
#ifndef sc_HasDiffuseEnvmap
#define sc_HasDiffuseEnvmap 0
#elif sc_HasDiffuseEnvmap==1
#undef sc_HasDiffuseEnvmap
#define sc_HasDiffuseEnvmap 1
#endif
#ifndef sc_AmbientLightMode_SphericalHarmonics
#define sc_AmbientLightMode_SphericalHarmonics 0
#endif
#ifndef sc_AmbientLightsCount
#define sc_AmbientLightsCount 0
#endif
#ifndef sc_AmbientLightMode0
#define sc_AmbientLightMode0 0
#endif
#ifndef sc_AmbientLightMode_Constant
#define sc_AmbientLightMode_Constant 0
#endif
struct sc_AmbientLight_t
{
vec3 color;
float intensity;
};
#ifndef sc_AmbientLightMode1
#define sc_AmbientLightMode1 0
#endif
#ifndef sc_AmbientLightMode2
#define sc_AmbientLightMode2 0
#endif
#ifndef sc_DirectionalLightsCount
#define sc_DirectionalLightsCount 0
#endif
struct sc_DirectionalLight_t
{
vec3 direction;
vec4 color;
};
#ifndef sc_PointLightsCount
#define sc_PointLightsCount 0
#endif
struct sc_PointLight_t
{
bool falloffEnabled;
float falloffEndDistance;
float negRcpFalloffEndDistance4;
float angleScale;
float angleOffset;
vec3 direction;
vec3 position;
vec4 color;
};
#ifndef sc_IsEditor
#define sc_IsEditor 0
#elif sc_IsEditor==1
#undef sc_IsEditor
#define sc_IsEditor 1
#endif
#ifndef normalTexLayout
#define normalTexLayout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_normalTex
#define SC_USE_UV_TRANSFORM_normalTex 0
#elif SC_USE_UV_TRANSFORM_normalTex==1
#undef SC_USE_UV_TRANSFORM_normalTex
#define SC_USE_UV_TRANSFORM_normalTex 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_normalTex
#define SC_SOFTWARE_WRAP_MODE_U_normalTex -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_normalTex
#define SC_SOFTWARE_WRAP_MODE_V_normalTex -1
#endif
#ifndef SC_USE_UV_MIN_MAX_normalTex
#define SC_USE_UV_MIN_MAX_normalTex 0
#elif SC_USE_UV_MIN_MAX_normalTex==1
#undef SC_USE_UV_MIN_MAX_normalTex
#define SC_USE_UV_MIN_MAX_normalTex 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_normalTex
#define SC_USE_CLAMP_TO_BORDER_normalTex 0
#elif SC_USE_CLAMP_TO_BORDER_normalTex==1
#undef SC_USE_CLAMP_TO_BORDER_normalTex
#define SC_USE_CLAMP_TO_BORDER_normalTex 1
#endif
#ifndef Tweak_N13Layout
#define Tweak_N13Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N13
#define SC_USE_UV_TRANSFORM_Tweak_N13 0
#elif SC_USE_UV_TRANSFORM_Tweak_N13==1
#undef SC_USE_UV_TRANSFORM_Tweak_N13
#define SC_USE_UV_TRANSFORM_Tweak_N13 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N13
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N13 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N13
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N13 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N13
#define SC_USE_UV_MIN_MAX_Tweak_N13 0
#elif SC_USE_UV_MIN_MAX_Tweak_N13==1
#undef SC_USE_UV_MIN_MAX_Tweak_N13
#define SC_USE_UV_MIN_MAX_Tweak_N13 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N13
#define SC_USE_CLAMP_TO_BORDER_Tweak_N13 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N13==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N13
#define SC_USE_CLAMP_TO_BORDER_Tweak_N13 1
#endif
#ifndef Tweak_N17Layout
#define Tweak_N17Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N17
#define SC_USE_UV_TRANSFORM_Tweak_N17 0
#elif SC_USE_UV_TRANSFORM_Tweak_N17==1
#undef SC_USE_UV_TRANSFORM_Tweak_N17
#define SC_USE_UV_TRANSFORM_Tweak_N17 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N17
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N17 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N17
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N17 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N17
#define SC_USE_UV_MIN_MAX_Tweak_N17 0
#elif SC_USE_UV_MIN_MAX_Tweak_N17==1
#undef SC_USE_UV_MIN_MAX_Tweak_N17
#define SC_USE_UV_MIN_MAX_Tweak_N17 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N17
#define SC_USE_CLAMP_TO_BORDER_Tweak_N17 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N17==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N17
#define SC_USE_CLAMP_TO_BORDER_Tweak_N17 1
#endif
#ifndef Tweak_N20Layout
#define Tweak_N20Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N20
#define SC_USE_UV_TRANSFORM_Tweak_N20 0
#elif SC_USE_UV_TRANSFORM_Tweak_N20==1
#undef SC_USE_UV_TRANSFORM_Tweak_N20
#define SC_USE_UV_TRANSFORM_Tweak_N20 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N20
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N20 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N20
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N20 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N20
#define SC_USE_UV_MIN_MAX_Tweak_N20 0
#elif SC_USE_UV_MIN_MAX_Tweak_N20==1
#undef SC_USE_UV_MIN_MAX_Tweak_N20
#define SC_USE_UV_MIN_MAX_Tweak_N20 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N20
#define SC_USE_CLAMP_TO_BORDER_Tweak_N20 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N20==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N20
#define SC_USE_CLAMP_TO_BORDER_Tweak_N20 1
#endif
#ifndef Tweak_N10Layout
#define Tweak_N10Layout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_Tweak_N10
#define SC_USE_UV_TRANSFORM_Tweak_N10 0
#elif SC_USE_UV_TRANSFORM_Tweak_N10==1
#undef SC_USE_UV_TRANSFORM_Tweak_N10
#define SC_USE_UV_TRANSFORM_Tweak_N10 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_Tweak_N10
#define SC_SOFTWARE_WRAP_MODE_U_Tweak_N10 -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_Tweak_N10
#define SC_SOFTWARE_WRAP_MODE_V_Tweak_N10 -1
#endif
#ifndef SC_USE_UV_MIN_MAX_Tweak_N10
#define SC_USE_UV_MIN_MAX_Tweak_N10 0
#elif SC_USE_UV_MIN_MAX_Tweak_N10==1
#undef SC_USE_UV_MIN_MAX_Tweak_N10
#define SC_USE_UV_MIN_MAX_Tweak_N10 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_Tweak_N10
#define SC_USE_CLAMP_TO_BORDER_Tweak_N10 0
#elif SC_USE_CLAMP_TO_BORDER_Tweak_N10==1
#undef SC_USE_CLAMP_TO_BORDER_Tweak_N10
#define SC_USE_CLAMP_TO_BORDER_Tweak_N10 1
#endif
#ifndef sc_DepthOnly
#define sc_DepthOnly 0
#elif sc_DepthOnly==1
#undef sc_DepthOnly
#define sc_DepthOnly 1
#endif
struct sc_Camera_t
{
vec3 position;
float aspect;
vec2 clipPlanes;
};
#ifndef baseTexLayout
#define baseTexLayout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_baseTex
#define SC_USE_UV_TRANSFORM_baseTex 0
#elif SC_USE_UV_TRANSFORM_baseTex==1
#undef SC_USE_UV_TRANSFORM_baseTex
#define SC_USE_UV_TRANSFORM_baseTex 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_baseTex
#define SC_SOFTWARE_WRAP_MODE_U_baseTex -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_baseTex
#define SC_SOFTWARE_WRAP_MODE_V_baseTex -1
#endif
#ifndef SC_USE_UV_MIN_MAX_baseTex
#define SC_USE_UV_MIN_MAX_baseTex 0
#elif SC_USE_UV_MIN_MAX_baseTex==1
#undef SC_USE_UV_MIN_MAX_baseTex
#define SC_USE_UV_MIN_MAX_baseTex 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_baseTex
#define SC_USE_CLAMP_TO_BORDER_baseTex 0
#elif SC_USE_CLAMP_TO_BORDER_baseTex==1
#undef SC_USE_CLAMP_TO_BORDER_baseTex
#define SC_USE_CLAMP_TO_BORDER_baseTex 1
#endif
#ifndef materialParamsTexLayout
#define materialParamsTexLayout 0
#endif
#ifndef SC_USE_UV_TRANSFORM_materialParamsTex
#define SC_USE_UV_TRANSFORM_materialParamsTex 0
#elif SC_USE_UV_TRANSFORM_materialParamsTex==1
#undef SC_USE_UV_TRANSFORM_materialParamsTex
#define SC_USE_UV_TRANSFORM_materialParamsTex 1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_U_materialParamsTex
#define SC_SOFTWARE_WRAP_MODE_U_materialParamsTex -1
#endif
#ifndef SC_SOFTWARE_WRAP_MODE_V_materialParamsTex
#define SC_SOFTWARE_WRAP_MODE_V_materialParamsTex -1
#endif
#ifndef SC_USE_UV_MIN_MAX_materialParamsTex
#define SC_USE_UV_MIN_MAX_materialParamsTex 0
#elif SC_USE_UV_MIN_MAX_materialParamsTex==1
#undef SC_USE_UV_MIN_MAX_materialParamsTex
#define SC_USE_UV_MIN_MAX_materialParamsTex 1
#endif
#ifndef SC_USE_CLAMP_TO_BORDER_materialParamsTex
#define SC_USE_CLAMP_TO_BORDER_materialParamsTex 0
#elif SC_USE_CLAMP_TO_BORDER_materialParamsTex==1
#undef SC_USE_CLAMP_TO_BORDER_materialParamsTex
#define SC_USE_CLAMP_TO_BORDER_materialParamsTex 1
#endif
layout(binding=1,std430) readonly buffer sc_RayTracingCasterVertexBuffer
{
float sc_RayTracingCasterVertices[1];
} sc_RayTracingCasterVertexBuffer_obj;
layout(binding=2,std430) readonly buffer sc_RayTracingCasterNonAnimatedVertexBuffer
{
float sc_RayTracingCasterNonAnimatedVertices[1];
} sc_RayTracingCasterNonAnimatedVertexBuffer_obj;
layout(binding=0,std430) readonly buffer sc_RayTracingCasterIndexBuffer
{
uint sc_RayTracingCasterTriangles[1];
} sc_RayTracingCasterIndexBuffer_obj;
uniform vec4 sc_CurrentRenderTargetDims;
uniform float sc_ShadowDensity;
uniform vec4 sc_ShadowColor;
uniform vec4 sc_UniformConstants;
uniform mat4 sc_ViewProjectionMatrixArray[sc_NumStereoViews];
uniform uvec4 sc_RayTracingCasterConfiguration;
uniform uvec4 sc_RayTracingCasterOffsetPNTC;
uniform uvec4 sc_RayTracingCasterFormatPNTC;
uniform uvec4 sc_RayTracingCasterOffsetTexture;
uniform uvec4 sc_RayTracingCasterFormatTexture;
uniform mat4 sc_ModelMatrix;
uniform mat3 sc_NormalMatrix;
uniform float correctedIntensity;
uniform mat3 intensityTextureTransform;
uniform vec4 intensityTextureUvMinMax;
uniform vec4 intensityTextureBorderColor;
uniform mat4 sc_ProjectionMatrixArray[sc_NumStereoViews];
uniform float alphaTestThreshold;
uniform int sc_RayTracingReceiverEffectsMask;
uniform sc_LightEstimationData_t sc_LightEstimationData;
uniform vec3 sc_EnvmapRotation;
uniform vec4 sc_EnvmapSpecularSize;
uniform vec4 sc_EnvmapDiffuseSize;
uniform float sc_EnvmapExposure;
uniform vec3 sc_Sh[9];
uniform float sc_ShIntensity;
uniform sc_AmbientLight_t sc_AmbientLights[sc_AmbientLightsCount+1];
uniform sc_DirectionalLight_t sc_DirectionalLights[sc_DirectionalLightsCount+1];
uniform sc_PointLight_t sc_PointLights[sc_PointLightsCount+1];
uniform mat3 normalTexTransform;
uniform vec4 normalTexUvMinMax;
uniform vec4 normalTexBorderColor;
uniform float Tweak_N0;
uniform mat3 Tweak_N13Transform;
uniform vec4 Tweak_N13UvMinMax;
uniform vec4 Tweak_N13BorderColor;
uniform float Tweak_N22;
uniform mat3 Tweak_N17Transform;
uniform vec4 Tweak_N17UvMinMax;
uniform vec4 Tweak_N17BorderColor;
uniform float Tweak_N21;
uniform mat3 Tweak_N20Transform;
uniform vec4 Tweak_N20UvMinMax;
uniform vec4 Tweak_N20BorderColor;
uniform mat3 Tweak_N10Transform;
uniform vec4 Tweak_N10UvMinMax;
uniform vec4 Tweak_N10BorderColor;
uniform float Port_Input1_N012;
uniform vec2 Port_Center_N014;
uniform vec2 Port_Center_N015;
uniform vec2 Port_Center_N019;
uniform sc_Camera_t sc_Camera;
uniform mat3 baseTexTransform;
uniform vec4 baseTexUvMinMax;
uniform vec4 baseTexBorderColor;
uniform mat3 materialParamsTexTransform;
uniform vec4 materialParamsTexUvMinMax;
uniform vec4 materialParamsTexBorderColor;
uniform vec3 Port_Emissive_N006;
uniform vec3 Port_SpecularAO_N006;
uniform int PreviewEnabled;
uniform usampler2D sc_RayTracingHitCasterIdAndBarycentric;
uniform sampler2D sc_RayTracingRayDirection;
uniform sampler2D baseTex;
uniform sampler2DArray baseTexArrSC;
uniform sampler2D Tweak_N10;
uniform sampler2DArray Tweak_N10ArrSC;
uniform sampler2D Tweak_N20;
uniform sampler2DArray Tweak_N20ArrSC;
uniform sampler2D Tweak_N17;
uniform sampler2DArray Tweak_N17ArrSC;
uniform sampler2D Tweak_N13;
uniform sampler2DArray Tweak_N13ArrSC;
uniform sampler2D normalTex;
uniform sampler2DArray normalTexArrSC;
uniform sampler2D materialParamsTex;
uniform sampler2DArray materialParamsTexArrSC;
uniform sampler2D sc_SSAOTexture;
uniform sampler2D sc_ShadowTexture;
uniform sampler2D sc_RayTracingShadows;
uniform sampler2DArray sc_RayTracingShadowsArrSC;
uniform sampler2D sc_EnvmapSpecular;
uniform sampler2DArray sc_EnvmapSpecularArrSC;
uniform sampler2D sc_EnvmapDiffuse;
uniform sampler2DArray sc_EnvmapDiffuseArrSC;
uniform sampler2D sc_RayTracingGlobalIllumination;
uniform sampler2DArray sc_RayTracingGlobalIlluminationArrSC;
uniform sampler2D sc_RayTracingReflections;
uniform sampler2DArray sc_RayTracingReflectionsArrSC;
uniform sampler2D sc_ScreenTexture;
uniform sampler2DArray sc_ScreenTextureArrSC;
uniform sampler2D intensityTexture;
uniform sampler2DArray intensityTextureArrSC;
uniform sampler2D sc_OITFrontDepthTexture;
uniform sampler2D sc_OITDepthHigh0;
uniform sampler2D sc_OITDepthLow0;
uniform sampler2D sc_OITAlpha0;
uniform sampler2D sc_OITDepthHigh1;
uniform sampler2D sc_OITDepthLow1;
uniform sampler2D sc_OITAlpha1;
uniform sampler2D sc_OITFilteredDepthBoundsTexture;
flat in int varStereoViewID;
in vec2 varShadowTex;
in vec4 varPosAndMotion;
in vec4 varNormalAndMotion;
in float varClipDistance;
#if sc_FramebufferFetch&&defined(GL_EXT_shader_framebuffer_fetch)
#define out inout
#endif
layout(location=0) out vec4 sc_FragData0;
#if sc_FramebufferFetch&&defined(GL_EXT_shader_framebuffer_fetch)
#undef out
#endif
in vec4 varScreenPos;
in float varViewSpaceDepth;
in vec4 PreviewVertexColor;
in float PreviewVertexSaved;
in vec4 varTex01;
in vec4 varTangent;
in vec2 varScreenTexturePos;
in vec4 varColor;
vec3 sc_RayTracingInterpolateAnimatedFloat3(vec3 brc,uvec3 indices,uint offset)
{
uvec3 l9_0=(indices*uvec3(6u))+uvec3(offset);
uint l9_1=l9_0.x;
uint l9_2=l9_0.y;
uint l9_3=l9_0.z;
return ((vec3(sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_1],sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_1+1u],sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_1+2u])*brc.x)+(vec3(sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_2],sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_2+1u],sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_2+2u])*brc.y))+(vec3(sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_3],sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_3+1u],sc_RayTracingCasterNonAnimatedVertexBuffer_obj.sc_RayTracingCasterNonAnimatedVertices[l9_3+2u])*brc.z);
}
vec4 sc_RayTracingFetchUnorm4(uint offset)
{
uint l9_0=floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[offset]);
return vec4(float(l9_0&255u),float((l9_0>>uint(8))&255u),float((l9_0>>uint(16))&255u),float((l9_0>>uint(24))&255u))/vec4(255.0);
}
sc_RayTracingHitPayload sc_RayTracingEvaluateHitPayload(ivec2 screenPos)
{
ivec2 l9_0=screenPos;
uvec4 l9_1=texelFetch(sc_RayTracingHitCasterIdAndBarycentric,l9_0,0);
uvec2 l9_2=l9_1.xy;
if (l9_1.x!=(sc_RayTracingCasterConfiguration.y&65535u))
{
return sc_RayTracingHitPayload(vec3(0.0),vec3(0.0),vec3(0.0),vec4(0.0),vec4(0.0),vec2(0.0),vec2(0.0),vec2(0.0),vec2(0.0),l9_2);
}
vec2 l9_3=unpackHalf2x16(l9_1.z|(l9_1.w<<uint(16)));
float l9_4=l9_3.x;
float l9_5=l9_3.y;
float l9_6=(1.0-l9_4)-l9_5;
vec3 l9_7=vec3(l9_6,l9_4,l9_5);
ivec2 l9_8=screenPos;
vec4 l9_9=texelFetch(sc_RayTracingRayDirection,l9_8,0);
float l9_10=l9_9.x;
float l9_11=l9_9.y;
float l9_12=(1.0-abs(l9_10))-abs(l9_11);
vec3 l9_13=vec3(l9_10,l9_11,l9_12);
float l9_14=clamp(-l9_12,0.0,1.0);
float l9_15;
if (l9_10>=0.0)
{
l9_15=-l9_14;
}
else
{
l9_15=l9_14;
}
float l9_16;
if (l9_11>=0.0)
{
l9_16=-l9_14;
}
else
{
l9_16=l9_14;
}
vec2 l9_17=vec2(l9_15,l9_16);
vec2 l9_18=l9_13.xy+l9_17;
uint l9_19=min(l9_1.y,sc_RayTracingCasterConfiguration.z)*6u;
uint l9_20=l9_19&4294967292u;
uint l9_21=l9_20/4u;
uint l9_22=sc_RayTracingCasterIndexBuffer_obj.sc_RayTracingCasterTriangles[l9_21];
uint l9_23=l9_21+1u;
uint l9_24=sc_RayTracingCasterIndexBuffer_obj.sc_RayTracingCasterTriangles[l9_23];
uvec4 l9_25=(uvec4(l9_22,l9_22,l9_24,l9_24)&uvec4(65535u,4294967295u,65535u,4294967295u))>>uvec4(0u,16u,0u,16u);
uvec3 l9_26;
if (l9_19==l9_20)
{
l9_26=l9_25.xyz;
}
else
{
l9_26=l9_25.yzw;
}
bool l9_27=sc_RayTracingCasterConfiguration.x==2u;
vec3 l9_28;
if (l9_27)
{
l9_28=sc_RayTracingInterpolateAnimatedFloat3(l9_7,l9_26,0u);
}
else
{
uint l9_29=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_30=(l9_26.x*l9_29)+sc_RayTracingCasterOffsetPNTC.x;
uint l9_31=(l9_26.y*l9_29)+sc_RayTracingCasterOffsetPNTC.x;
uint l9_32=(l9_26.z*l9_29)+sc_RayTracingCasterOffsetPNTC.x;
vec3 l9_33;
if (sc_RayTracingCasterFormatPNTC.x==5u)
{
l9_33=((vec3(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_30],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_30+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_30+2u])*l9_6)+(vec3(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_31],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_31+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_31+2u])*l9_4))+(vec3(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_32],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_32+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_32+2u])*l9_5);
}
else
{
vec3 l9_34;
if (sc_RayTracingCasterFormatPNTC.x==6u)
{
l9_34=((vec3(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_30])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_30+1u])).x)*l9_6)+(vec3(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_31])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_31+1u])).x)*l9_4))+(vec3(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_32])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_32+1u])).x)*l9_5);
}
else
{
l9_34=vec3(1.0,0.0,0.0);
}
l9_33=l9_34;
}
l9_28=(sc_ModelMatrix*vec4(l9_33,1.0)).xyz;
}
vec3 l9_35;
if (sc_RayTracingCasterOffsetPNTC.y>0u)
{
vec3 l9_36;
if (l9_27)
{
l9_36=sc_RayTracingInterpolateAnimatedFloat3(l9_7,l9_26,3u);
}
else
{
uint l9_37=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_38=(l9_26.x*l9_37)+sc_RayTracingCasterOffsetPNTC.y;
uint l9_39=(l9_26.y*l9_37)+sc_RayTracingCasterOffsetPNTC.y;
uint l9_40=(l9_26.z*l9_37)+sc_RayTracingCasterOffsetPNTC.y;
vec3 l9_41;
if (sc_RayTracingCasterFormatPNTC.y==5u)
{
l9_41=((vec3(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_38],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_38+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_38+2u])*l9_6)+(vec3(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_39],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_39+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_39+2u])*l9_4))+(vec3(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_40],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_40+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_40+2u])*l9_5);
}
else
{
vec3 l9_42;
if (sc_RayTracingCasterFormatPNTC.y==6u)
{
l9_42=((vec3(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_38])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_38+1u])).x)*l9_6)+(vec3(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_39])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_39+1u])).x)*l9_4))+(vec3(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_40])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_40+1u])).x)*l9_5);
}
else
{
l9_42=vec3(1.0,0.0,0.0);
}
l9_41=l9_42;
}
l9_36=normalize(sc_NormalMatrix*l9_41);
}
l9_35=l9_36;
}
else
{
l9_35=vec3(1.0,0.0,0.0);
}
bool l9_43=!l9_27;
bool l9_44;
if (l9_43)
{
l9_44=sc_RayTracingCasterOffsetPNTC.z>0u;
}
else
{
l9_44=l9_43;
}
vec4 l9_45;
if (l9_44)
{
uint l9_46=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_47=(l9_26.x*l9_46)+sc_RayTracingCasterOffsetPNTC.z;
uint l9_48=(l9_26.y*l9_46)+sc_RayTracingCasterOffsetPNTC.z;
uint l9_49=(l9_26.z*l9_46)+sc_RayTracingCasterOffsetPNTC.z;
vec4 l9_50;
if (sc_RayTracingCasterFormatPNTC.z==5u)
{
l9_50=((vec4(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_47],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_47+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_47+2u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_47+3u])*l9_6)+(vec4(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_48],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_48+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_48+2u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_48+3u])*l9_4))+(vec4(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_49],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_49+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_49+2u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_49+3u])*l9_5);
}
else
{
vec4 l9_51;
if (sc_RayTracingCasterFormatPNTC.z==6u)
{
l9_51=((vec4(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_47])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_47+1u])))*l9_6)+(vec4(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_48])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_48+1u])))*l9_4))+(vec4(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_49])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_49+1u])))*l9_5);
}
else
{
vec4 l9_52;
if (sc_RayTracingCasterFormatPNTC.z==2u)
{
l9_52=((sc_RayTracingFetchUnorm4(l9_47)*l9_6)+(sc_RayTracingFetchUnorm4(l9_48)*l9_4))+(sc_RayTracingFetchUnorm4(l9_49)*l9_5);
}
else
{
l9_52=vec4(1.0,0.0,0.0,0.0);
}
l9_51=l9_52;
}
l9_50=l9_51;
}
l9_45=vec4(normalize(sc_NormalMatrix*l9_50.xyz),l9_50.w);
}
else
{
l9_45=vec4(1.0,0.0,0.0,1.0);
}
vec4 l9_53;
if (sc_RayTracingCasterFormatPNTC.w>0u)
{
uint l9_54=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_55=(l9_26.x*l9_54)+sc_RayTracingCasterOffsetPNTC.w;
uint l9_56=(l9_26.y*l9_54)+sc_RayTracingCasterOffsetPNTC.w;
uint l9_57=(l9_26.z*l9_54)+sc_RayTracingCasterOffsetPNTC.w;
vec4 l9_58;
if (sc_RayTracingCasterFormatPNTC.w==5u)
{
l9_58=((vec4(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_55],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_55+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_55+2u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_55+3u])*l9_6)+(vec4(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_56],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_56+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_56+2u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_56+3u])*l9_4))+(vec4(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_57],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_57+1u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_57+2u],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_57+3u])*l9_5);
}
else
{
vec4 l9_59;
if (sc_RayTracingCasterFormatPNTC.w==6u)
{
l9_59=((vec4(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_55])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_55+1u])))*l9_6)+(vec4(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_56])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_56+1u])))*l9_4))+(vec4(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_57])),unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_57+1u])))*l9_5);
}
else
{
vec4 l9_60;
if (sc_RayTracingCasterFormatPNTC.w==2u)
{
l9_60=((sc_RayTracingFetchUnorm4(l9_55)*l9_6)+(sc_RayTracingFetchUnorm4(l9_56)*l9_4))+(sc_RayTracingFetchUnorm4(l9_57)*l9_5);
}
else
{
l9_60=vec4(1.0,0.0,0.0,0.0);
}
l9_59=l9_60;
}
l9_58=l9_59;
}
l9_53=l9_58;
}
else
{
l9_53=vec4(0.0);
}
uvec3 l9_61=l9_26%uvec3(2u);
vec2 l9_62=vec2(dot(l9_7,vec3(uvec3(1u)-l9_61)),0.0);
vec2 l9_63;
if (sc_RayTracingCasterFormatTexture.x>0u)
{
uint l9_64=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_65=(l9_26.x*l9_64)+sc_RayTracingCasterOffsetTexture.x;
uint l9_66=(l9_26.y*l9_64)+sc_RayTracingCasterOffsetTexture.x;
uint l9_67=(l9_26.z*l9_64)+sc_RayTracingCasterOffsetTexture.x;
vec2 l9_68;
if (sc_RayTracingCasterFormatTexture.x==5u)
{
l9_68=((vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_65],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_65+1u])*l9_6)+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_66],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_66+1u])*l9_4))+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_67],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_67+1u])*l9_5);
}
else
{
vec2 l9_69;
if (sc_RayTracingCasterFormatTexture.x==6u)
{
l9_69=((unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_65]))*l9_6)+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_66]))*l9_4))+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_67]))*l9_5);
}
else
{
l9_69=vec2(1.0,0.0);
}
l9_68=l9_69;
}
l9_63=l9_68;
}
else
{
l9_63=l9_62;
}
vec2 l9_70;
if (sc_RayTracingCasterFormatTexture.y>0u)
{
uint l9_71=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_72=(l9_26.x*l9_71)+sc_RayTracingCasterOffsetTexture.y;
uint l9_73=(l9_26.y*l9_71)+sc_RayTracingCasterOffsetTexture.y;
uint l9_74=(l9_26.z*l9_71)+sc_RayTracingCasterOffsetTexture.y;
vec2 l9_75;
if (sc_RayTracingCasterFormatTexture.y==5u)
{
l9_75=((vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_72],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_72+1u])*l9_6)+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_73],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_73+1u])*l9_4))+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_74],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_74+1u])*l9_5);
}
else
{
vec2 l9_76;
if (sc_RayTracingCasterFormatTexture.y==6u)
{
l9_76=((unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_72]))*l9_6)+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_73]))*l9_4))+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_74]))*l9_5);
}
else
{
l9_76=vec2(1.0,0.0);
}
l9_75=l9_76;
}
l9_70=l9_75;
}
else
{
l9_70=l9_62;
}
vec2 l9_77;
if (sc_RayTracingCasterFormatTexture.z>0u)
{
uint l9_78=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_79=(l9_26.x*l9_78)+sc_RayTracingCasterOffsetTexture.z;
uint l9_80=(l9_26.y*l9_78)+sc_RayTracingCasterOffsetTexture.z;
uint l9_81=(l9_26.z*l9_78)+sc_RayTracingCasterOffsetTexture.z;
vec2 l9_82;
if (sc_RayTracingCasterFormatTexture.z==5u)
{
l9_82=((vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_79],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_79+1u])*l9_6)+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_80],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_80+1u])*l9_4))+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_81],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_81+1u])*l9_5);
}
else
{
vec2 l9_83;
if (sc_RayTracingCasterFormatTexture.z==6u)
{
l9_83=((unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_79]))*l9_6)+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_80]))*l9_4))+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_81]))*l9_5);
}
else
{
l9_83=vec2(1.0,0.0);
}
l9_82=l9_83;
}
l9_77=l9_82;
}
else
{
l9_77=l9_62;
}
vec2 l9_84;
if (sc_RayTracingCasterFormatTexture.w>0u)
{
uint l9_85=sc_RayTracingCasterConfiguration.y>>16u;
uint l9_86=(l9_26.x*l9_85)+sc_RayTracingCasterOffsetTexture.w;
uint l9_87=(l9_26.y*l9_85)+sc_RayTracingCasterOffsetTexture.w;
uint l9_88=(l9_26.z*l9_85)+sc_RayTracingCasterOffsetTexture.w;
vec2 l9_89;
if (sc_RayTracingCasterFormatTexture.w==5u)
{
l9_89=((vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_86],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_86+1u])*l9_6)+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_87],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_87+1u])*l9_4))+(vec2(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_88],sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_88+1u])*l9_5);
}
else
{
vec2 l9_90;
if (sc_RayTracingCasterFormatTexture.w==6u)
{
l9_90=((unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_86]))*l9_6)+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_87]))*l9_4))+(unpackHalf2x16(floatBitsToUint(sc_RayTracingCasterVertexBuffer_obj.sc_RayTracingCasterVertices[l9_88]))*l9_5);
}
else
{
l9_90=vec2(1.0,0.0);
}
l9_89=l9_90;
}
l9_84=l9_89;
}
else
{
l9_84=l9_62;
}
return sc_RayTracingHitPayload(-normalize(vec3(l9_18.x,l9_18.y,l9_13.z)),l9_28,l9_35,l9_45,l9_53,l9_63,l9_70,l9_77,l9_84,l9_2);
}
int sc_GetStereoViewIndex()
{
int l9_0;
#if (sc_StereoRenderingMode==0)
{
l9_0=0;
}
#else
{
l9_0=varStereoViewID;
}
#endif
return l9_0;
}
int baseTexGetStereoViewIndex()
{
int l9_0;
#if (baseTexHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
void sc_SoftwareWrapEarly(inout float uv,int softwareWrapMode)
{
if (softwareWrapMode==1)
{
uv=fract(uv);
}
else
{
if (softwareWrapMode==2)
{
float l9_0=fract(uv);
uv=mix(l9_0,1.0-l9_0,clamp(step(0.25,fract((uv-l9_0)*0.5)),0.0,1.0));
}
}
}
void sc_ClampUV(inout float value,float minValue,float maxValue,bool useClampToBorder,inout float clampToBorderFactor)
{
float l9_0=clamp(value,minValue,maxValue);
float l9_1=step(abs(value-l9_0),9.9999997e-06);
clampToBorderFactor*=(l9_1+((1.0-float(useClampToBorder))*(1.0-l9_1)));
value=l9_0;
}
vec2 sc_TransformUV(vec2 uv,bool useUvTransform,mat3 uvTransform)
{
if (useUvTransform)
{
uv=vec2((uvTransform*vec3(uv,1.0)).xy);
}
return uv;
}
void sc_SoftwareWrapLate(inout float uv,int softwareWrapMode,bool useClampToBorder,inout float clampToBorderFactor)
{
if ((softwareWrapMode==0)||(softwareWrapMode==3))
{
sc_ClampUV(uv,0.0,1.0,useClampToBorder,clampToBorderFactor);
}
}
vec3 sc_SamplingCoordsViewToGlobal(vec2 uv,int renderingLayout,int viewIndex)
{
vec3 l9_0;
if (renderingLayout==0)
{
l9_0=vec3(uv,0.0);
}
else
{
vec3 l9_1;
if (renderingLayout==1)
{
l9_1=vec3(uv.x,(uv.y*0.5)+(0.5-(float(viewIndex)*0.5)),0.0);
}
else
{
l9_1=vec3(uv,float(viewIndex));
}
l9_0=l9_1;
}
return l9_0;
}
int Tweak_N10GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N10HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int Tweak_N20GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N20HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int Tweak_N17GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N17HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int Tweak_N13GetStereoViewIndex()
{
int l9_0;
#if (Tweak_N13HasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int normalTexGetStereoViewIndex()
{
int l9_0;
#if (normalTexHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int materialParamsTexGetStereoViewIndex()
{
int l9_0;
#if (materialParamsTexHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
vec3 ssSRGB_to_Linear(vec3 value)
{
vec3 l9_0;
#if (SC_DEVICE_CLASS>=2)
{
l9_0=vec3(pow(value.x,2.2),pow(value.y,2.2),pow(value.z,2.2));
}
#else
{
l9_0=value*value;
}
#endif
return l9_0;
}
vec3 evaluateSSAO(vec3 positionWS)
{
#if (sc_SSAOEnabled)
{
vec4 l9_0=sc_ViewProjectionMatrixArray[sc_GetStereoViewIndex()]*vec4(positionWS,1.0);
return vec3(texture(sc_SSAOTexture,((l9_0.xyz/vec3(l9_0.w)).xy*0.5)+vec2(0.5)).x);
}
#else
{
return vec3(1.0);
}
#endif
}
vec3 fresnelSchlickSub(float cosTheta,vec3 F0,vec3 fresnelMax)
{
float l9_0=1.0-cosTheta;
float l9_1=l9_0*l9_0;
return F0+((fresnelMax-F0)*((l9_1*l9_1)*l9_0));
}
float Dggx(float NdotH,float roughness)
{
float l9_0=roughness;
float l9_1=roughness;
float l9_2=l9_0*l9_1;
float l9_3=l9_2*l9_2;
float l9_4=NdotH;
float l9_5=NdotH;
float l9_6=((l9_4*l9_5)*(l9_3-1.0))+1.0;
float l9_7;
if (sc_RayTracingCasterConfiguration.x!=0u)
{
l9_7=1e-07;
}
else
{
l9_7=9.9999999e-09;
}
return l9_3/((l9_6*l9_6)+l9_7);
}
vec3 calculateDirectSpecular(SurfaceProperties surfaceProperties,vec3 L,vec3 V)
{
float l9_0=surfaceProperties.roughness;
float l9_1=max(l9_0,0.029999999);
vec3 l9_2=surfaceProperties.specColor;
vec3 l9_3=surfaceProperties.normal;
vec3 l9_4=L;
vec3 l9_5=V;
vec3 l9_6=normalize(l9_4+l9_5);
vec3 l9_7=L;
float l9_8=clamp(dot(l9_3,l9_7),0.0,1.0);
vec3 l9_9=V;
float l9_10=clamp(dot(l9_3,l9_6),0.0,1.0);
vec3 l9_11=V;
float l9_12=clamp(dot(l9_11,l9_6),0.0,1.0);
#if (SC_DEVICE_CLASS>=2)
{
float l9_13=l9_1+1.0;
float l9_14=(l9_13*l9_13)*0.125;
float l9_15=1.0-l9_14;
return fresnelSchlickSub(l9_12,l9_2,vec3(1.0))*(((Dggx(l9_10,l9_1)*(1.0/(((l9_8*l9_15)+l9_14)*((clamp(dot(l9_3,l9_9),0.0,1.0)*l9_15)+l9_14))))*0.25)*l9_8);
}
#else
{
float l9_16=exp2(11.0-(10.0*l9_1));
return ((fresnelSchlickSub(l9_12,l9_2,vec3(1.0))*((l9_16*0.125)+0.25))*pow(l9_10,l9_16))*l9_8;
}
#endif
}
LightingComponents accumulateLight(LightingComponents lighting,LightProperties light,SurfaceProperties surfaceProperties,vec3 V)
{
lighting.directDiffuse+=((vec3(clamp(dot(surfaceProperties.normal,light.direction),0.0,1.0))*light.color)*light.attenuation);
lighting.directSpecular+=((calculateDirectSpecular(surfaceProperties,light.direction,V)*light.color)*light.attenuation);
return lighting;
}
float computeDistanceAttenuation(float distanceToLight,float falloffEndDistance)
{
float l9_0=distanceToLight;
float l9_1=distanceToLight;
float l9_2=l9_0*l9_1;
if (falloffEndDistance==0.0)
{
return 1.0/l9_2;
}
return max(min(1.0-((l9_2*l9_2)/pow(falloffEndDistance,4.0)),1.0),0.0)/l9_2;
}
int sc_RayTracingShadowsGetStereoViewIndex()
{
int l9_0;
#if (sc_RayTracingShadowsHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
vec2 calcPanoramicTexCoordsFromDir(vec3 reflDir,float rotationDegrees)
{
float l9_0=-reflDir.z;
vec2 l9_1=vec2((((reflDir.x<0.0) ? (-1.0) : 1.0)*acos(clamp(l9_0/length(vec2(reflDir.x,l9_0)),-1.0,1.0)))-1.5707964,acos(reflDir.y))/vec2(6.2831855,3.1415927);
float l9_2=l9_1.x+(rotationDegrees/360.0);
vec2 l9_3=vec2(l9_2,1.0-l9_1.y);
l9_3.x=fract((l9_2+floor(l9_2))+1.0);
return l9_3;
}
int sc_EnvmapSpecularGetStereoViewIndex()
{
int l9_0;
#if (sc_EnvmapSpecularHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
vec4 sc_EnvmapSpecularSampleViewBias(vec2 uv,float bias)
{
vec4 l9_0;
#if (sc_EnvmapSpecularLayout==2)
{
l9_0=texture(sc_EnvmapSpecularArrSC,sc_SamplingCoordsViewToGlobal(uv,sc_EnvmapSpecularLayout,sc_EnvmapSpecularGetStereoViewIndex()),bias);
}
#else
{
l9_0=texture(sc_EnvmapSpecular,sc_SamplingCoordsViewToGlobal(uv,sc_EnvmapSpecularLayout,sc_EnvmapSpecularGetStereoViewIndex()).xy,bias);
}
#endif
return l9_0;
}
vec2 calcSeamlessPanoramicUvsForSampling(vec2 uv,vec2 topMipRes,float lod)
{
#if (SC_DEVICE_CLASS>=2)
{
vec2 l9_0=max(vec2(1.0),topMipRes/vec2(exp2(lod)));
return ((uv*(l9_0-vec2(1.0)))/l9_0)+(vec2(0.5)/l9_0);
}
#else
{
return uv;
}
#endif
}
int sc_EnvmapDiffuseGetStereoViewIndex()
{
int l9_0;
#if (sc_EnvmapDiffuseHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
int sc_RayTracingGlobalIlluminationGetStereoViewIndex()
{
int l9_0;
#if (sc_RayTracingGlobalIlluminationHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
vec3 getSpecularDominantDir(vec3 N,vec3 R,float roughness)
{
#if (SC_DEVICE_CLASS>=2)
{
return normalize(mix(R,N,vec3((roughness*roughness)*roughness)));
}
#else
{
return R;
}
#endif
}
vec4 sc_EnvmapSpecularSampleViewLevel(vec2 uv,float level_)
{
vec4 l9_0;
#if (sc_EnvmapSpecularLayout==2)
{
l9_0=textureLod(sc_EnvmapSpecularArrSC,sc_SamplingCoordsViewToGlobal(uv,sc_EnvmapSpecularLayout,sc_EnvmapSpecularGetStereoViewIndex()),level_);
}
#else
{
l9_0=textureLod(sc_EnvmapSpecular,sc_SamplingCoordsViewToGlobal(uv,sc_EnvmapSpecularLayout,sc_EnvmapSpecularGetStereoViewIndex()).xy,level_);
}
#endif
return l9_0;
}
int sc_RayTracingReflectionsGetStereoViewIndex()
{
int l9_0;
#if (sc_RayTracingReflectionsHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
vec3 envBRDFApprox(SurfaceProperties surfaceProperties,float NdotV)
{
#if (SC_DEVICE_CLASS>=2)
{
vec4 l9_0=(vec4(-1.0,-0.0275,-0.57200003,0.022)*surfaceProperties.roughness)+vec4(1.0,0.0425,1.04,-0.039999999);
float l9_1=l9_0.x;
vec2 l9_2=(vec2(-1.04,1.04)*((min(l9_1*l9_1,exp2((-9.2799997)*NdotV))*l9_1)+l9_0.y))+l9_0.zw;
return max((surfaceProperties.specColor*l9_2.x)+vec3(l9_2.y),vec3(0.0));
}
#else
{
return fresnelSchlickSub(NdotV,surfaceProperties.specColor,max(vec3(1.0-surfaceProperties.roughness),surfaceProperties.specColor));
}
#endif
}
vec2 sc_SamplingCoordsGlobalToView(vec3 uvi,int renderingLayout,int viewIndex)
{
if (renderingLayout==1)
{
uvi.y=((2.0*uvi.y)+float(viewIndex))-1.0;
}
return uvi.xy;
}
vec2 sc_ScreenCoordsGlobalToView(vec2 uv)
{
vec2 l9_0;
#if (sc_StereoRenderingMode==1)
{
l9_0=sc_SamplingCoordsGlobalToView(vec3(uv,0.0),1,sc_GetStereoViewIndex());
}
#else
{
l9_0=uv;
}
#endif
return l9_0;
}
int sc_ScreenTextureGetStereoViewIndex()
{
int l9_0;
#if (sc_ScreenTextureHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
vec4 sc_ScreenTextureSampleViewBias(vec2 uv,float bias)
{
vec4 l9_0;
#if (sc_ScreenTextureLayout==2)
{
l9_0=texture(sc_ScreenTextureArrSC,sc_SamplingCoordsViewToGlobal(uv,sc_ScreenTextureLayout,sc_ScreenTextureGetStereoViewIndex()),bias);
}
#else
{
l9_0=texture(sc_ScreenTexture,sc_SamplingCoordsViewToGlobal(uv,sc_ScreenTextureLayout,sc_ScreenTextureGetStereoViewIndex()).xy,bias);
}
#endif
return l9_0;
}
vec4 sc_readFragData0()
{
#if sc_FramebufferFetch
#ifdef GL_EXT_shader_framebuffer_fetch
return sc_FragData0;
#elif defined(GL_ARM_shader_framebuffer_fetch)
return gl_LastFragColorARM;
#endif
#else
return vec4(0.0);
#endif
}
vec4 sc_GetFramebufferColor()
{
vec4 l9_0;
#if (sc_FramebufferFetch)
{
l9_0=sc_readFragData0();
}
#else
{
l9_0=sc_ScreenTextureSampleViewBias(sc_ScreenCoordsGlobalToView(gl_FragCoord.xy*sc_CurrentRenderTargetDims.zw),0.0);
}
#endif
return l9_0;
}
float srgbToLinear(float x)
{
#if (SC_DEVICE_CLASS>=2)
{
return pow(x,2.2);
}
#else
{
return x*x;
}
#endif
}
float linearToSrgb(float x)
{
#if (SC_DEVICE_CLASS>=2)
{
return pow(x,0.45454547);
}
#else
{
return sqrt(x);
}
#endif
}
vec4 ngsCalculateLighting(vec3 albedo,float opacity,vec3 normal,vec3 position,vec3 viewDir,vec3 emissive,float metallic,float roughness,vec3 ao,vec3 specularAO)
{
float l9_0=opacity;
vec3 l9_1=ssSRGB_to_Linear(albedo);
vec3 l9_2=normal;
vec3 l9_3=normalize(l9_2);
vec3 l9_4=position;
vec3 l9_5=viewDir;
vec3 l9_6=ssSRGB_to_Linear(emissive);
float l9_7=metallic;
float l9_8=roughness;
vec3 l9_9=ao;
vec3 l9_10=specularAO;
vec3 l9_11;
#if (sc_SSAOEnabled)
{
l9_11=evaluateSSAO(l9_4);
}
#else
{
l9_11=l9_9;
}
#endif
vec3 l9_12=vec3(l9_7);
vec3 l9_13=mix(vec3(0.039999999),l9_1*l9_7,l9_12);
vec3 l9_14=mix(l9_1*(1.0-l9_7),vec3(0.0),l9_12);
SurfaceProperties l9_15=SurfaceProperties(l9_14,l9_0,l9_3,l9_4,l9_5,l9_7,l9_8,l9_6,l9_11,l9_10,vec3(1.0),l9_13);
vec4 l9_16=vec4(1.0);
vec3 l9_17;
vec3 l9_18;
vec3 l9_19;
vec3 l9_20;
int l9_21;
vec3 l9_22;
vec3 l9_23;
#if (sc_DirectionalLightsCount>0)
{
vec3 l9_24;
vec3 l9_25;
vec3 l9_26;
vec3 l9_27;
int l9_28;
vec3 l9_29;
vec3 l9_30;
l9_30=vec3(1.0);
l9_29=vec3(0.0);
l9_28=0;
l9_27=vec3(0.0);
l9_26=vec3(0.0);
l9_25=vec3(0.0);
l9_24=vec3(0.0);
LightingComponents l9_31;
LightProperties l9_32;
SurfaceProperties l9_33;
vec3 l9_34;
int l9_35=0;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_35<sc_DirectionalLightsCount)
{
LightingComponents l9_36=accumulateLight(LightingComponents(l9_24,l9_25,l9_30,l9_29,l9_27,l9_26),LightProperties(sc_DirectionalLights[l9_35].direction,sc_DirectionalLights[l9_35].color.xyz,sc_DirectionalLights[l9_35].color.w*l9_16[(l9_28<3) ? l9_28 : 3]),l9_15,l9_5);
l9_30=l9_36.indirectDiffuse;
l9_29=l9_36.indirectSpecular;
l9_28++;
l9_27=l9_36.emitted;
l9_26=l9_36.transmitted;
l9_25=l9_36.directSpecular;
l9_24=l9_36.directDiffuse;
l9_35++;
continue;
}
else
{
break;
}
}
l9_23=l9_30;
l9_22=l9_29;
l9_21=l9_28;
l9_20=l9_27;
l9_19=l9_26;
l9_18=l9_25;
l9_17=l9_24;
}
#else
{
l9_23=vec3(1.0);
l9_22=vec3(0.0);
l9_21=0;
l9_20=vec3(0.0);
l9_19=vec3(0.0);
l9_18=vec3(0.0);
l9_17=vec3(0.0);
}
#endif
vec3 l9_37;
vec3 l9_38;
vec3 l9_39;
#if (sc_PointLightsCount>0)
{
vec3 l9_40;
vec3 l9_41;
vec3 l9_42;
vec3 l9_43;
vec3 l9_44;
vec3 l9_45;
l9_45=l9_23;
l9_44=l9_22;
l9_43=l9_20;
l9_42=l9_19;
l9_41=l9_18;
l9_40=l9_17;
int l9_46;
vec3 l9_47;
vec3 l9_48;
vec3 l9_49;
vec3 l9_50;
vec3 l9_51;
vec3 l9_52;
int l9_53=0;
int l9_54=l9_21;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_53<sc_PointLightsCount)
{
vec3 l9_55=sc_PointLights[l9_53].position-l9_4;
vec3 l9_56=normalize(l9_55);
float l9_57=l9_16[(l9_54<3) ? l9_54 : 3];
float l9_58=clamp((dot(l9_56,sc_PointLights[l9_53].direction)*sc_PointLights[l9_53].angleScale)+sc_PointLights[l9_53].angleOffset,0.0,1.0);
float l9_59=(sc_PointLights[l9_53].color.w*l9_57)*(l9_58*l9_58);
float l9_60;
if (sc_PointLights[l9_53].falloffEnabled)
{
l9_60=l9_59*computeDistanceAttenuation(length(l9_55),sc_PointLights[l9_53].falloffEndDistance);
}
else
{
l9_60=l9_59;
}
l9_46=l9_54+1;
LightingComponents l9_61=accumulateLight(LightingComponents(l9_40,l9_41,l9_45,l9_44,l9_43,l9_42),LightProperties(l9_56,sc_PointLights[l9_53].color.xyz,l9_60),l9_15,l9_5);
l9_47=l9_61.directDiffuse;
l9_48=l9_61.directSpecular;
l9_49=l9_61.indirectDiffuse;
l9_50=l9_61.indirectSpecular;
l9_51=l9_61.emitted;
l9_52=l9_61.transmitted;
l9_45=l9_49;
l9_44=l9_50;
l9_54=l9_46;
l9_43=l9_51;
l9_42=l9_52;
l9_41=l9_48;
l9_40=l9_47;
l9_53++;
continue;
}
else
{
break;
}
}
l9_39=l9_42;
l9_38=l9_41;
l9_37=l9_40;
}
#else
{
l9_39=l9_19;
l9_38=l9_18;
l9_37=l9_17;
}
#endif
vec3 l9_62;
vec3 l9_63;
#if (sc_ProjectiveShadowsReceiver)
{
vec3 l9_64;
#if (sc_ProjectiveShadowsReceiver)
{
vec2 l9_65=abs(varShadowTex-vec2(0.5));
vec4 l9_66=texture(sc_ShadowTexture,varShadowTex)*step(max(l9_65.x,l9_65.y),0.5);
l9_64=mix(vec3(1.0),mix(sc_ShadowColor.xyz,sc_ShadowColor.xyz*l9_66.xyz,vec3(sc_ShadowColor.w)),vec3(l9_66.w*sc_ShadowDensity));
}
#else
{
l9_64=vec3(1.0);
}
#endif
l9_63=l9_38*l9_64;
l9_62=l9_37*l9_64;
}
#else
{
l9_63=l9_38;
l9_62=l9_37;
}
#endif
vec3 l9_67;
vec3 l9_68;
if ((sc_RayTracingReceiverEffectsMask&4)!=0)
{
vec2 l9_69=gl_FragCoord.xy*sc_CurrentRenderTargetDims.zw;
vec4 l9_70;
#if (sc_RayTracingShadowsLayout==2)
{
l9_70=texture(sc_RayTracingShadowsArrSC,sc_SamplingCoordsViewToGlobal(l9_69,sc_RayTracingShadowsLayout,sc_RayTracingShadowsGetStereoViewIndex()),0.0);
}
#else
{
l9_70=texture(sc_RayTracingShadows,sc_SamplingCoordsViewToGlobal(l9_69,sc_RayTracingShadowsLayout,sc_RayTracingShadowsGetStereoViewIndex()).xy,0.0);
}
#endif
float l9_71=1.0-l9_70.x;
l9_68=l9_62*l9_71;
l9_67=l9_63*l9_71;
}
else
{
l9_68=l9_62;
l9_67=l9_63;
}
vec3 l9_72;
#if ((sc_EnvLightMode==sc_AmbientLightMode_EnvironmentMap)||(sc_EnvLightMode==sc_AmbientLightMode_FromCamera))
{
vec4 l9_73;
#if (sc_EnvLightMode==sc_AmbientLightMode_FromCamera)
{
vec2 l9_74=calcPanoramicTexCoordsFromDir(l9_3,sc_EnvmapRotation.y);
vec2 l9_75;
#if (SC_DEVICE_CLASS>=2)
{
l9_75=calcSeamlessPanoramicUvsForSampling(l9_74,sc_EnvmapSpecularSize.xy,5.0);
}
#else
{
l9_75=l9_74;
}
#endif
l9_73=sc_EnvmapSpecularSampleViewBias(l9_75,13.0);
}
#else
{
vec2 l9_76=calcPanoramicTexCoordsFromDir(l9_3,sc_EnvmapRotation.y);
vec4 l9_77;
#if (sc_HasDiffuseEnvmap)
{
vec2 l9_78=calcSeamlessPanoramicUvsForSampling(l9_76,sc_EnvmapDiffuseSize.xy,0.0);
vec4 l9_79;
if (sc_RayTracingCasterConfiguration.x!=0u)
{
vec4 l9_80;
#if (sc_EnvmapDiffuseLayout==2)
{
l9_80=textureLod(sc_EnvmapDiffuseArrSC,sc_SamplingCoordsViewToGlobal(l9_78,sc_EnvmapDiffuseLayout,sc_EnvmapDiffuseGetStereoViewIndex()),0.0);
}
#else
{
l9_80=textureLod(sc_EnvmapDiffuse,sc_SamplingCoordsViewToGlobal(l9_78,sc_EnvmapDiffuseLayout,sc_EnvmapDiffuseGetStereoViewIndex()).xy,0.0);
}
#endif
l9_79=l9_80;
}
else
{
vec4 l9_81;
#if (sc_EnvmapDiffuseLayout==2)
{
l9_81=texture(sc_EnvmapDiffuseArrSC,sc_SamplingCoordsViewToGlobal(l9_78,sc_EnvmapDiffuseLayout,sc_EnvmapDiffuseGetStereoViewIndex()),-13.0);
}
#else
{
l9_81=texture(sc_EnvmapDiffuse,sc_SamplingCoordsViewToGlobal(l9_78,sc_EnvmapDiffuseLayout,sc_EnvmapDiffuseGetStereoViewIndex()).xy,-13.0);
}
#endif
l9_79=l9_81;
}
l9_77=l9_79;
}
#else
{
l9_77=sc_EnvmapSpecularSampleViewBias(l9_76,13.0);
}
#endif
l9_73=l9_77;
}
#endif
l9_72=(l9_73.xyz*(1.0/max(l9_73.w,0.0039215689)))*sc_EnvmapExposure;
}
#else
{
vec3 l9_82;
#if (sc_EnvLightMode==sc_AmbientLightMode_SphericalHarmonics)
{
vec3 l9_83=-l9_3;
float l9_84=l9_83.x;
float l9_85=l9_83.y;
float l9_86=l9_83.z;
l9_82=(((((((sc_Sh[8]*0.42904299)*((l9_84*l9_84)-(l9_85*l9_85)))+((sc_Sh[6]*0.74312502)*(l9_86*l9_86)))+(sc_Sh[0]*0.88622701))-(sc_Sh[6]*0.24770799))+((((sc_Sh[4]*(l9_84*l9_85))+(sc_Sh[7]*(l9_84*l9_86)))+(sc_Sh[5]*(l9_85*l9_86)))*0.85808599))+((((sc_Sh[3]*l9_84)+(sc_Sh[1]*l9_85))+(sc_Sh[2]*l9_86))*1.0233279))*sc_ShIntensity;
}
#else
{
l9_82=vec3(0.0);
}
#endif
l9_72=l9_82;
}
#endif
vec3 l9_87;
if ((sc_RayTracingReceiverEffectsMask&2)!=0)
{
vec2 l9_88=gl_FragCoord.xy*sc_CurrentRenderTargetDims.zw;
vec4 l9_89;
#if (sc_RayTracingGlobalIlluminationLayout==2)
{
l9_89=texture(sc_RayTracingGlobalIlluminationArrSC,sc_SamplingCoordsViewToGlobal(l9_88,sc_RayTracingGlobalIlluminationLayout,sc_RayTracingGlobalIlluminationGetStereoViewIndex()),0.0);
}
#else
{
l9_89=texture(sc_RayTracingGlobalIllumination,sc_SamplingCoordsViewToGlobal(l9_88,sc_RayTracingGlobalIlluminationLayout,sc_RayTracingGlobalIlluminationGetStereoViewIndex()).xy,0.0);
}
#endif
l9_87=mix(l9_72,l9_89.xyz,vec3(l9_89.w));
}
else
{
l9_87=l9_72;
}
vec3 l9_90;
#if (sc_AmbientLightsCount>0)
{
vec3 l9_91;
#if (sc_AmbientLightMode0==sc_AmbientLightMode_Constant)
{
l9_91=l9_87+(sc_AmbientLights[0].color*sc_AmbientLights[0].intensity);
}
#else
{
vec3 l9_92=l9_87;
l9_92.x=l9_87.x+(1e-06*sc_AmbientLights[0].color.x);
l9_91=l9_92;
}
#endif
l9_90=l9_91;
}
#else
{
l9_90=l9_87;
}
#endif
vec3 l9_93;
#if (sc_AmbientLightsCount>1)
{
vec3 l9_94;
#if (sc_AmbientLightMode1==sc_AmbientLightMode_Constant)
{
l9_94=l9_90+(sc_AmbientLights[1].color*sc_AmbientLights[1].intensity);
}
#else
{
vec3 l9_95=l9_90;
l9_95.x=l9_90.x+(1e-06*sc_AmbientLights[1].color.x);
l9_94=l9_95;
}
#endif
l9_93=l9_94;
}
#else
{
l9_93=l9_90;
}
#endif
vec3 l9_96;
#if (sc_AmbientLightsCount>2)
{
vec3 l9_97;
#if (sc_AmbientLightMode2==sc_AmbientLightMode_Constant)
{
l9_97=l9_93+(sc_AmbientLights[2].color*sc_AmbientLights[2].intensity);
}
#else
{
vec3 l9_98=l9_93;
l9_98.x=l9_93.x+(1e-06*sc_AmbientLights[2].color.x);
l9_97=l9_98;
}
#endif
l9_96=l9_97;
}
#else
{
l9_96=l9_93;
}
#endif
vec3 l9_99;
#if (sc_LightEstimation)
{
vec3 l9_100;
l9_100=sc_LightEstimationData.ambientLight;
vec3 l9_101;
int l9_102=0;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_102<sc_LightEstimationSGCount)
{
float l9_103=dot(sc_LightEstimationData.sg[l9_102].axis,l9_3);
float l9_104=exp(-sc_LightEstimationData.sg[l9_102].sharpness);
float l9_105=l9_104*l9_104;
float l9_106=1.0/sc_LightEstimationData.sg[l9_102].sharpness;
float l9_107=(1.0+(2.0*l9_105))-l9_106;
float l9_108=sqrt(1.0-l9_107);
float l9_109=0.36000001*l9_103;
float l9_110=(1.0/(4.0*0.36000001))*l9_108;
float l9_111=l9_109+l9_110;
float l9_112;
if (step(abs(l9_109),l9_110)>0.5)
{
l9_112=(l9_111*l9_111)/l9_108;
}
else
{
l9_112=clamp(l9_103,0.0,1.0);
}
l9_101=l9_100+((((sc_LightEstimationData.sg[l9_102].color/vec3(sc_LightEstimationData.sg[l9_102].sharpness))*6.2831855)*((l9_107*l9_112)+(((l9_104-l9_105)*l9_106)-l9_105)))/vec3(3.1415927));
l9_100=l9_101;
l9_102++;
continue;
}
else
{
break;
}
}
l9_99=l9_96+l9_100;
}
#else
{
l9_99=l9_96;
}
#endif
vec3 l9_113;
#if ((sc_EnvLightMode==sc_AmbientLightMode_EnvironmentMap)||(sc_EnvLightMode==sc_AmbientLightMode_FromCamera))
{
float l9_114=clamp(pow(l9_8,0.66666669),0.0,1.0)*5.0;
vec2 l9_115=calcPanoramicTexCoordsFromDir(getSpecularDominantDir(l9_3,reflect(-l9_5,l9_3),l9_8),sc_EnvmapRotation.y);
vec4 l9_116;
#if (SC_DEVICE_CLASS>=2)
{
float l9_117=floor(l9_114);
float l9_118=ceil(l9_114);
l9_116=mix(sc_EnvmapSpecularSampleViewLevel(calcSeamlessPanoramicUvsForSampling(l9_115,sc_EnvmapSpecularSize.xy,l9_117),l9_117),sc_EnvmapSpecularSampleViewLevel(calcSeamlessPanoramicUvsForSampling(l9_115,sc_EnvmapSpecularSize.xy,l9_118),l9_118),vec4(l9_114-l9_117));
}
#else
{
l9_116=sc_EnvmapSpecularSampleViewLevel(l9_115,l9_114);
}
#endif
vec3 l9_119=(l9_116.xyz*(1.0/max(l9_116.w,0.0039215689)))*sc_EnvmapExposure;
vec3 l9_120=l9_119;
l9_120.x=l9_119.x+sc_UniformConstants.x;
vec3 l9_121;
if ((sc_RayTracingReceiverEffectsMask&1)!=0)
{
vec2 l9_122=gl_FragCoord.xy*sc_CurrentRenderTargetDims.zw;
vec4 l9_123;
#if (sc_RayTracingReflectionsLayout==2)
{
l9_123=texture(sc_RayTracingReflectionsArrSC,sc_SamplingCoordsViewToGlobal(l9_122,sc_RayTracingReflectionsLayout,sc_RayTracingReflectionsGetStereoViewIndex()),0.0);
}
#else
{
l9_123=texture(sc_RayTracingReflections,sc_SamplingCoordsViewToGlobal(l9_122,sc_RayTracingReflectionsLayout,sc_RayTracingReflectionsGetStereoViewIndex()).xy,0.0);
}
#endif
l9_121=mix(l9_120,l9_123.xyz,vec3(l9_123.w));
}
else
{
l9_121=l9_120;
}
l9_113=vec3(0.0)+(l9_121*envBRDFApprox(l9_15,abs(dot(l9_3,l9_5))));
}
#else
{
l9_113=vec3(0.0);
}
#endif
vec3 l9_124;
#if (sc_LightEstimation)
{
float l9_125=clamp(l9_8*l9_8,0.0099999998,1.0);
vec3 l9_126;
l9_126=sc_LightEstimationData.ambientLight*l9_13;
int l9_127=0;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_127<sc_LightEstimationSGCount)
{
float l9_128=l9_125*l9_125;
vec3 l9_129=reflect(-l9_5,l9_3);
float l9_130=dot(l9_3,l9_5);
float l9_131=(2.0/l9_128)/(4.0*max(l9_130,9.9999997e-05));
float l9_132=length((l9_129*l9_131)+(sc_LightEstimationData.sg[l9_127].axis*sc_LightEstimationData.sg[l9_127].sharpness));
float l9_133=clamp(dot(l9_3,l9_129),0.0,1.0);
float l9_134=clamp(l9_130,0.0,1.0);
float l9_135=1.0-l9_128;
l9_126+=((((((((vec3(1.0/(3.1415927*l9_128))*exp((l9_132-l9_131)-sc_LightEstimationData.sg[l9_127].sharpness))*sc_LightEstimationData.sg[l9_127].color)*6.2831855)*(1.0-exp((-2.0)*l9_132)))/vec3(l9_132))*((1.0/(l9_133+sqrt(l9_128+((l9_135*l9_133)*l9_133))))*(1.0/(l9_134+sqrt(l9_128+((l9_135*l9_134)*l9_134))))))*(l9_13+((vec3(1.0)-l9_13)*pow(1.0-clamp(dot(l9_129,normalize(l9_129+l9_5)),0.0,1.0),5.0))))*l9_133);
l9_127++;
continue;
}
else
{
break;
}
}
l9_124=l9_113+l9_126;
}
#else
{
l9_124=l9_113;
}
#endif
float l9_136;
vec3 l9_137;
vec3 l9_138;
vec3 l9_139;
#if (sc_BlendMode_ColoredGlass)
{
l9_139=vec3(0.0);
l9_138=vec3(0.0);
l9_137=ssSRGB_to_Linear(sc_GetFramebufferColor().xyz)*mix(vec3(1.0),l9_14,vec3(l9_0));
l9_136=1.0;
}
#else
{
l9_139=l9_68;
l9_138=l9_99;
l9_137=l9_39;
l9_136=l9_0;
}
#endif
bool l9_140;
#if (sc_BlendMode_PremultipliedAlpha)
{
l9_140=true;
}
#else
{
l9_140=false;
}
#endif
vec3 l9_141=l9_138*l9_11;
vec3 l9_142=l9_139+l9_141;
vec3 l9_143=l9_14*l9_142;
vec3 l9_144=l9_124*l9_10;
vec3 l9_145=l9_67+l9_144;
vec3 l9_146;
if (l9_140)
{
l9_146=l9_143*srgbToLinear(l9_136);
}
else
{
l9_146=l9_143;
}
vec3 l9_147=l9_146+l9_145;
vec3 l9_148=(l9_147+l9_6)+l9_137;
float l9_149=l9_148.x;
vec4 l9_150=vec4(l9_149,l9_148.yz,l9_136);
vec4 l9_151;
#if (sc_IsEditor)
{
vec4 l9_152=l9_150;
l9_152.x=l9_149+((l9_11.x*l9_10.x)*9.9999997e-06);
l9_151=l9_152;
}
#else
{
l9_151=l9_150;
}
#endif
if (sc_RayTracingCasterConfiguration.x!=0u)
{
return l9_151;
}
vec4 l9_153;
#if (!sc_BlendMode_Multiply)
{
vec3 l9_154=l9_151.xyz*1.8;
vec3 l9_155=(l9_151.xyz*(l9_154+vec3(1.4)))/((l9_151.xyz*(l9_154+vec3(0.5)))+vec3(1.5));
l9_153=vec4(l9_155.x,l9_155.y,l9_155.z,l9_151.w);
}
#else
{
l9_153=l9_151;
}
#endif
vec3 l9_156=vec3(linearToSrgb(l9_153.x),linearToSrgb(l9_153.y),linearToSrgb(l9_153.z));
return vec4(l9_156.x,l9_156.y,l9_156.z,l9_153.w);
}
void sc_writeFragData0(vec4 col)
{
#if (sc_ShaderCacheConstant!=0)
{
col.x+=(sc_UniformConstants.x*float(sc_ShaderCacheConstant));
}
#endif
sc_FragData0=col;
}
int intensityTextureGetStereoViewIndex()
{
int l9_0;
#if (intensityTextureHasSwappedViews)
{
l9_0=1-sc_GetStereoViewIndex();
}
#else
{
l9_0=sc_GetStereoViewIndex();
}
#endif
return l9_0;
}
float transformSingleColor(float original,float intMap,float target)
{
#if ((BLEND_MODE_REALISTIC||BLEND_MODE_FORGRAY)||BLEND_MODE_NOTBRIGHT)
{
return original/pow(1.0-target,intMap);
}
#else
{
#if (BLEND_MODE_DIVISION)
{
return original/(1.0-target);
}
#else
{
#if (BLEND_MODE_BRIGHT)
{
return original/pow(1.0-target,2.0-(2.0*original));
}
#endif
}
#endif
}
#endif
return 0.0;
}
vec3 RGBtoHCV(vec3 rgb)
{
vec4 l9_0;
if (rgb.y<rgb.z)
{
l9_0=vec4(rgb.zy,-1.0,0.66666669);
}
else
{
l9_0=vec4(rgb.yz,0.0,-0.33333334);
}
vec4 l9_1;
if (rgb.x<l9_0.x)
{
l9_1=vec4(l9_0.xyw,rgb.x);
}
else
{
l9_1=vec4(rgb.x,l9_0.yzx);
}
float l9_2=l9_1.x-min(l9_1.w,l9_1.y);
return vec3(abs(((l9_1.w-l9_1.y)/((6.0*l9_2)+1e-07))+l9_1.z),l9_2,l9_1.x);
}
vec3 RGBToHSL(vec3 rgb)
{
vec3 l9_0=RGBtoHCV(rgb);
float l9_1=l9_0.y;
float l9_2=l9_0.z-(l9_1*0.5);
return vec3(l9_0.x,l9_1/((1.0-abs((2.0*l9_2)-1.0))+1e-07),l9_2);
}
vec3 HUEtoRGB(float hue)
{
return clamp(vec3(abs((6.0*hue)-3.0)-1.0,2.0-abs((6.0*hue)-2.0),2.0-abs((6.0*hue)-4.0)),vec3(0.0),vec3(1.0));
}
vec3 HSLToRGB(vec3 hsl)
{
return ((HUEtoRGB(hsl.x)-vec3(0.5))*((1.0-abs((2.0*hsl.z)-1.0))*hsl.y))+vec3(hsl.z);
}
vec3 transformColor(float yValue,vec3 original,vec3 target,float weight,float intMap)
{
#if (BLEND_MODE_INTENSE)
{
return mix(original,HSLToRGB(vec3(target.x,target.y,RGBToHSL(original).z)),vec3(weight));
}
#else
{
return mix(original,clamp(vec3(transformSingleColor(yValue,intMap,target.x),transformSingleColor(yValue,intMap,target.y),transformSingleColor(yValue,intMap,target.z)),vec3(0.0),vec3(1.0)),vec3(weight));
}
#endif
}
vec3 definedBlend(vec3 a,vec3 b)
{
#if (BLEND_MODE_LIGHTEN)
{
return max(a,b);
}
#else
{
#if (BLEND_MODE_DARKEN)
{
return min(a,b);
}
#else
{
#if (BLEND_MODE_DIVIDE)
{
return b/a;
}
#else
{
#if (BLEND_MODE_AVERAGE)
{
return (a+b)*0.5;
}
#else
{
#if (BLEND_MODE_SUBTRACT)
{
return max((a+b)-vec3(1.0),vec3(0.0));
}
#else
{
#if (BLEND_MODE_DIFFERENCE)
{
return abs(a-b);
}
#else
{
#if (BLEND_MODE_NEGATION)
{
return vec3(1.0)-abs((vec3(1.0)-a)-b);
}
#else
{
#if (BLEND_MODE_EXCLUSION)
{
return (a+b)-((a*2.0)*b);
}
#else
{
#if (BLEND_MODE_OVERLAY)
{
float l9_0;
if (a.x<0.5)
{
l9_0=(2.0*a.x)*b.x;
}
else
{
l9_0=1.0-((2.0*(1.0-a.x))*(1.0-b.x));
}
float l9_1;
if (a.y<0.5)
{
l9_1=(2.0*a.y)*b.y;
}
else
{
l9_1=1.0-((2.0*(1.0-a.y))*(1.0-b.y));
}
float l9_2;
if (a.z<0.5)
{
l9_2=(2.0*a.z)*b.z;
}
else
{
l9_2=1.0-((2.0*(1.0-a.z))*(1.0-b.z));
}
return vec3(l9_0,l9_1,l9_2);
}
#else
{
#if (BLEND_MODE_SOFT_LIGHT)
{
return (((vec3(1.0)-(b*2.0))*a)*a)+((a*2.0)*b);
}
#else
{
#if (BLEND_MODE_HARD_LIGHT)
{
float l9_3;
if (b.x<0.5)
{
l9_3=(2.0*b.x)*a.x;
}
else
{
l9_3=1.0-((2.0*(1.0-b.x))*(1.0-a.x));
}
float l9_4;
if (b.y<0.5)
{
l9_4=(2.0*b.y)*a.y;
}
else
{
l9_4=1.0-((2.0*(1.0-b.y))*(1.0-a.y));
}
float l9_5;
if (b.z<0.5)
{
l9_5=(2.0*b.z)*a.z;
}
else
{
l9_5=1.0-((2.0*(1.0-b.z))*(1.0-a.z));
}
return vec3(l9_3,l9_4,l9_5);
}
#else
{
#if (BLEND_MODE_COLOR_DODGE)
{
float l9_6;
if (b.x==1.0)
{
l9_6=b.x;
}
else
{
l9_6=min(a.x/(1.0-b.x),1.0);
}
float l9_7;
if (b.y==1.0)
{
l9_7=b.y;
}
else
{
l9_7=min(a.y/(1.0-b.y),1.0);
}
float l9_8;
if (b.z==1.0)
{
l9_8=b.z;
}
else
{
l9_8=min(a.z/(1.0-b.z),1.0);
}
return vec3(l9_6,l9_7,l9_8);
}
#else
{
#if (BLEND_MODE_COLOR_BURN)
{
float l9_9;
if (b.x==0.0)
{
l9_9=b.x;
}
else
{
l9_9=max(1.0-((1.0-a.x)/b.x),0.0);
}
float l9_10;
if (b.y==0.0)
{
l9_10=b.y;
}
else
{
l9_10=max(1.0-((1.0-a.y)/b.y),0.0);
}
float l9_11;
if (b.z==0.0)
{
l9_11=b.z;
}
else
{
l9_11=max(1.0-((1.0-a.z)/b.z),0.0);
}
return vec3(l9_9,l9_10,l9_11);
}
#else
{
#if (BLEND_MODE_LINEAR_LIGHT)
{
float l9_12;
if (b.x<0.5)
{
l9_12=max((a.x+(2.0*b.x))-1.0,0.0);
}
else
{
l9_12=min(a.x+(2.0*(b.x-0.5)),1.0);
}
float l9_13;
if (b.y<0.5)
{
l9_13=max((a.y+(2.0*b.y))-1.0,0.0);
}
else
{
l9_13=min(a.y+(2.0*(b.y-0.5)),1.0);
}
float l9_14;
if (b.z<0.5)
{
l9_14=max((a.z+(2.0*b.z))-1.0,0.0);
}
else
{
l9_14=min(a.z+(2.0*(b.z-0.5)),1.0);
}
return vec3(l9_12,l9_13,l9_14);
}
#else
{
#if (BLEND_MODE_VIVID_LIGHT)
{
float l9_15;
if (b.x<0.5)
{
float l9_16;
if ((2.0*b.x)==0.0)
{
l9_16=2.0*b.x;
}
else
{
l9_16=max(1.0-((1.0-a.x)/(2.0*b.x)),0.0);
}
l9_15=l9_16;
}
else
{
float l9_17;
if ((2.0*(b.x-0.5))==1.0)
{
l9_17=2.0*(b.x-0.5);
}
else
{
l9_17=min(a.x/(1.0-(2.0*(b.x-0.5))),1.0);
}
l9_15=l9_17;
}
float l9_18;
if (b.y<0.5)
{
float l9_19;
if ((2.0*b.y)==0.0)
{
l9_19=2.0*b.y;
}
else
{
l9_19=max(1.0-((1.0-a.y)/(2.0*b.y)),0.0);
}
l9_18=l9_19;
}
else
{
float l9_20;
if ((2.0*(b.y-0.5))==1.0)
{
l9_20=2.0*(b.y-0.5);
}
else
{
l9_20=min(a.y/(1.0-(2.0*(b.y-0.5))),1.0);
}
l9_18=l9_20;
}
float l9_21;
if (b.z<0.5)
{
float l9_22;
if ((2.0*b.z)==0.0)
{
l9_22=2.0*b.z;
}
else
{
l9_22=max(1.0-((1.0-a.z)/(2.0*b.z)),0.0);
}
l9_21=l9_22;
}
else
{
float l9_23;
if ((2.0*(b.z-0.5))==1.0)
{
l9_23=2.0*(b.z-0.5);
}
else
{
l9_23=min(a.z/(1.0-(2.0*(b.z-0.5))),1.0);
}
l9_21=l9_23;
}
return vec3(l9_15,l9_18,l9_21);
}
#else
{
#if (BLEND_MODE_PIN_LIGHT)
{
float l9_24;
if (b.x<0.5)
{
l9_24=min(a.x,2.0*b.x);
}
else
{
l9_24=max(a.x,2.0*(b.x-0.5));
}
float l9_25;
if (b.y<0.5)
{
l9_25=min(a.y,2.0*b.y);
}
else
{
l9_25=max(a.y,2.0*(b.y-0.5));
}
float l9_26;
if (b.z<0.5)
{
l9_26=min(a.z,2.0*b.z);
}
else
{
l9_26=max(a.z,2.0*(b.z-0.5));
}
return vec3(l9_24,l9_25,l9_26);
}
#else
{
#if (BLEND_MODE_HARD_MIX)
{
float l9_27;
if (b.x<0.5)
{
float l9_28;
if ((2.0*b.x)==0.0)
{
l9_28=2.0*b.x;
}
else
{
l9_28=max(1.0-((1.0-a.x)/(2.0*b.x)),0.0);
}
l9_27=l9_28;
}
else
{
float l9_29;
if ((2.0*(b.x-0.5))==1.0)
{
l9_29=2.0*(b.x-0.5);
}
else
{
l9_29=min(a.x/(1.0-(2.0*(b.x-0.5))),1.0);
}
l9_27=l9_29;
}
bool l9_30=l9_27<0.5;
float l9_31;
if (b.y<0.5)
{
float l9_32;
if ((2.0*b.y)==0.0)
{
l9_32=2.0*b.y;
}
else
{
l9_32=max(1.0-((1.0-a.y)/(2.0*b.y)),0.0);
}
l9_31=l9_32;
}
else
{
float l9_33;
if ((2.0*(b.y-0.5))==1.0)
{
l9_33=2.0*(b.y-0.5);
}
else
{
l9_33=min(a.y/(1.0-(2.0*(b.y-0.5))),1.0);
}
l9_31=l9_33;
}
bool l9_34=l9_31<0.5;
float l9_35;
if (b.z<0.5)
{
float l9_36;
if ((2.0*b.z)==0.0)
{
l9_36=2.0*b.z;
}
else
{
l9_36=max(1.0-((1.0-a.z)/(2.0*b.z)),0.0);
}
l9_35=l9_36;
}
else
{
float l9_37;
if ((2.0*(b.z-0.5))==1.0)
{
l9_37=2.0*(b.z-0.5);
}
else
{
l9_37=min(a.z/(1.0-(2.0*(b.z-0.5))),1.0);
}
l9_35=l9_37;
}
return vec3(l9_30 ? 0.0 : 1.0,l9_34 ? 0.0 : 1.0,(l9_35<0.5) ? 0.0 : 1.0);
}
#else
{
#if (BLEND_MODE_HARD_REFLECT)
{
float l9_38;
if (b.x==1.0)
{
l9_38=b.x;
}
else
{
l9_38=min((a.x*a.x)/(1.0-b.x),1.0);
}
float l9_39;
if (b.y==1.0)
{
l9_39=b.y;
}
else
{
l9_39=min((a.y*a.y)/(1.0-b.y),1.0);
}
float l9_40;
if (b.z==1.0)
{
l9_40=b.z;
}
else
{
l9_40=min((a.z*a.z)/(1.0-b.z),1.0);
}
return vec3(l9_38,l9_39,l9_40);
}
#else
{
#if (BLEND_MODE_HARD_GLOW)
{
float l9_41;
if (a.x==1.0)
{
l9_41=a.x;
}
else
{
l9_41=min((b.x*b.x)/(1.0-a.x),1.0);
}
float l9_42;
if (a.y==1.0)
{
l9_42=a.y;
}
else
{
l9_42=min((b.y*b.y)/(1.0-a.y),1.0);
}
float l9_43;
if (a.z==1.0)
{
l9_43=a.z;
}
else
{
l9_43=min((b.z*b.z)/(1.0-a.z),1.0);
}
return vec3(l9_41,l9_42,l9_43);
}
#else
{
#if (BLEND_MODE_HARD_PHOENIX)
{
return (min(a,b)-max(a,b))+vec3(1.0);
}
#else
{
#if (BLEND_MODE_HUE)
{
return HSLToRGB(vec3(RGBToHSL(b).x,RGBToHSL(a).yz));
}
#else
{
#if (BLEND_MODE_SATURATION)
{
vec3 l9_44=RGBToHSL(a);
return HSLToRGB(vec3(l9_44.x,RGBToHSL(b).y,l9_44.z));
}
#else
{
#if (BLEND_MODE_COLOR)
{
return HSLToRGB(vec3(RGBToHSL(b).xy,RGBToHSL(a).z));
}
#else
{
#if (BLEND_MODE_LUMINOSITY)
{
return HSLToRGB(vec3(RGBToHSL(a).xy,RGBToHSL(b).z));
}
#else
{
vec3 l9_45=a;
vec3 l9_46=b;
float l9_47=((0.29899999*l9_45.x)+(0.58700001*l9_45.y))+(0.114*l9_45.z);
float l9_48=pow(l9_47,1.0/correctedIntensity);
vec4 l9_49;
#if (intensityTextureLayout==2)
{
bool l9_50=(int(SC_USE_CLAMP_TO_BORDER_intensityTexture)!=0)&&(!(int(SC_USE_UV_MIN_MAX_intensityTexture)!=0));
float l9_51=l9_48;
sc_SoftwareWrapEarly(l9_51,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).x);
float l9_52=l9_51;
float l9_53=0.5;
sc_SoftwareWrapEarly(l9_53,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).y);
float l9_54=l9_53;
vec2 l9_55;
float l9_56;
#if (SC_USE_UV_MIN_MAX_intensityTexture)
{
bool l9_57;
#if (SC_USE_CLAMP_TO_BORDER_intensityTexture)
{
l9_57=ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).x==3;
}
#else
{
l9_57=(int(SC_USE_CLAMP_TO_BORDER_intensityTexture)!=0);
}
#endif
float l9_58=l9_52;
float l9_59=1.0;
sc_ClampUV(l9_58,intensityTextureUvMinMax.x,intensityTextureUvMinMax.z,l9_57,l9_59);
float l9_60=l9_58;
float l9_61=l9_59;
bool l9_62;
#if (SC_USE_CLAMP_TO_BORDER_intensityTexture)
{
l9_62=ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).y==3;
}
#else
{
l9_62=(int(SC_USE_CLAMP_TO_BORDER_intensityTexture)!=0);
}
#endif
float l9_63=l9_54;
float l9_64=l9_61;
sc_ClampUV(l9_63,intensityTextureUvMinMax.y,intensityTextureUvMinMax.w,l9_62,l9_64);
l9_56=l9_64;
l9_55=vec2(l9_60,l9_63);
}
#else
{
l9_56=1.0;
l9_55=vec2(l9_52,l9_54);
}
#endif
vec2 l9_65=sc_TransformUV(l9_55,(int(SC_USE_UV_TRANSFORM_intensityTexture)!=0),intensityTextureTransform);
float l9_66=l9_65.x;
float l9_67=l9_56;
sc_SoftwareWrapLate(l9_66,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).x,l9_50,l9_67);
float l9_68=l9_65.y;
float l9_69=l9_67;
sc_SoftwareWrapLate(l9_68,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).y,l9_50,l9_69);
float l9_70=l9_69;
vec3 l9_71=sc_SamplingCoordsViewToGlobal(vec2(l9_66,l9_68),intensityTextureLayout,intensityTextureGetStereoViewIndex());
vec4 l9_72=texture(intensityTextureArrSC,l9_71,0.0);
vec4 l9_73;
#if (SC_USE_CLAMP_TO_BORDER_intensityTexture)
{
l9_73=mix(intensityTextureBorderColor,l9_72,vec4(l9_70));
}
#else
{
l9_73=l9_72;
}
#endif
l9_49=l9_73;
}
#else
{
bool l9_74=(int(SC_USE_CLAMP_TO_BORDER_intensityTexture)!=0)&&(!(int(SC_USE_UV_MIN_MAX_intensityTexture)!=0));
float l9_75=l9_48;
sc_SoftwareWrapEarly(l9_75,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).x);
float l9_76=l9_75;
float l9_77=0.5;
sc_SoftwareWrapEarly(l9_77,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).y);
float l9_78=l9_77;
vec2 l9_79;
float l9_80;
#if (SC_USE_UV_MIN_MAX_intensityTexture)
{
bool l9_81;
#if (SC_USE_CLAMP_TO_BORDER_intensityTexture)
{
l9_81=ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).x==3;
}
#else
{
l9_81=(int(SC_USE_CLAMP_TO_BORDER_intensityTexture)!=0);
}
#endif
float l9_82=l9_76;
float l9_83=1.0;
sc_ClampUV(l9_82,intensityTextureUvMinMax.x,intensityTextureUvMinMax.z,l9_81,l9_83);
float l9_84=l9_82;
float l9_85=l9_83;
bool l9_86;
#if (SC_USE_CLAMP_TO_BORDER_intensityTexture)
{
l9_86=ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).y==3;
}
#else
{
l9_86=(int(SC_USE_CLAMP_TO_BORDER_intensityTexture)!=0);
}
#endif
float l9_87=l9_78;
float l9_88=l9_85;
sc_ClampUV(l9_87,intensityTextureUvMinMax.y,intensityTextureUvMinMax.w,l9_86,l9_88);
l9_80=l9_88;
l9_79=vec2(l9_84,l9_87);
}
#else
{
l9_80=1.0;
l9_79=vec2(l9_76,l9_78);
}
#endif
vec2 l9_89=sc_TransformUV(l9_79,(int(SC_USE_UV_TRANSFORM_intensityTexture)!=0),intensityTextureTransform);
float l9_90=l9_89.x;
float l9_91=l9_80;
sc_SoftwareWrapLate(l9_90,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).x,l9_74,l9_91);
float l9_92=l9_89.y;
float l9_93=l9_91;
sc_SoftwareWrapLate(l9_92,ivec2(SC_SOFTWARE_WRAP_MODE_U_intensityTexture,SC_SOFTWARE_WRAP_MODE_V_intensityTexture).y,l9_74,l9_93);
float l9_94=l9_93;
vec3 l9_95=sc_SamplingCoordsViewToGlobal(vec2(l9_90,l9_92),intensityTextureLayout,intensityTextureGetStereoViewIndex());
vec4 l9_96=texture(intensityTexture,l9_95.xy,0.0);
vec4 l9_97;
#if (SC_USE_CLAMP_TO_BORDER_intensityTexture)
{
l9_97=mix(intensityTextureBorderColor,l9_96,vec4(l9_94));
}
#else
{
l9_97=l9_96;
}
#endif
l9_49=l9_97;
}
#endif
float l9_98=((((l9_49.x*256.0)+l9_49.y)+(l9_49.z/256.0))/257.00391)*16.0;
float l9_99;
#if (BLEND_MODE_FORGRAY)
{
l9_99=max(l9_98,1.0);
}
#else
{
l9_99=l9_98;
}
#endif
float l9_100;
#if (BLEND_MODE_NOTBRIGHT)
{
l9_100=min(l9_99,1.0);
}
#else
{
l9_100=l9_99;
}
#endif
return transformColor(l9_47,l9_45,l9_46,1.0,l9_100);
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
vec4 sc_OutputMotionVectorIfNeeded(vec4 finalColor)
{
#if (sc_MotionVectorsPass)
{
float l9_0=floor(((varPosAndMotion.w*5.0)+0.5)*65535.0);
float l9_1=floor(l9_0*0.00390625);
float l9_2=floor(((varNormalAndMotion.w*5.0)+0.5)*65535.0);
float l9_3=floor(l9_2*0.00390625);
return vec4(l9_1/255.0,(l9_0-(l9_1*256.0))/255.0,l9_3/255.0,(l9_2-(l9_3*256.0))/255.0);
}
#else
{
return finalColor;
}
#endif
}
float getFrontLayerZTestEpsilon()
{
#if (sc_SkinBonesCount>0)
{
return 5e-07;
}
#else
{
return 5.0000001e-08;
}
#endif
}
void unpackValues(float channel,int passIndex,inout int values[8])
{
#if (sc_OITCompositingPass)
{
channel=floor((channel*255.0)+0.5);
int l9_0=((passIndex+1)*4)-1;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_0>=(passIndex*4))
{
values[l9_0]=(values[l9_0]*4)+int(floor(mod(channel,4.0)));
channel=floor(channel/4.0);
l9_0--;
continue;
}
else
{
break;
}
}
}
#endif
}
float getDepthOrderingEpsilon()
{
#if (sc_SkinBonesCount>0)
{
return 0.001;
}
#else
{
return 0.0;
}
#endif
}
int encodeDepth(float depth,vec2 depthBounds)
{
float l9_0=(1.0-depthBounds.x)*1000.0;
return int(clamp((depth-l9_0)/((depthBounds.y*1000.0)-l9_0),0.0,1.0)*65535.0);
}
float viewSpaceDepth()
{
#if (UseViewSpaceDepthVariant&&((sc_OITDepthGatherPass||sc_OITCompositingPass)||sc_OITDepthBoundsPass))
{
return varViewSpaceDepth;
}
#else
{
return sc_ProjectionMatrixArray[sc_GetStereoViewIndex()][3].z/(sc_ProjectionMatrixArray[sc_GetStereoViewIndex()][2].z+((gl_FragCoord.z*2.0)-1.0));
}
#endif
}
float packValue(inout int value)
{
#if (sc_OITDepthGatherPass)
{
int l9_0=value;
value/=4;
return floor(floor(mod(float(l9_0),4.0))*64.0)/255.0;
}
#else
{
return 0.0;
}
#endif
}
void main()
{
#if (sc_DepthOnly)
{
return;
}
#endif
#if ((sc_StereoRenderingMode==1)&&(sc_StereoRendering_IsClipDistanceEnabled==0))
{
if (varClipDistance<0.0)
{
discard;
}
}
#endif
bool l9_0=sc_RayTracingCasterConfiguration.x!=0u;
vec2 l9_1;
vec3 l9_2;
vec3 l9_3;
vec3 l9_4;
vec3 l9_5;
vec3 l9_6;
if (l9_0)
{
sc_RayTracingHitPayload l9_7=sc_RayTracingEvaluateHitPayload(ivec2(gl_FragCoord.xy));
vec3 l9_8=l9_7.normalWS;
vec4 l9_9=l9_7.tangentWS;
if (l9_7.id.x!=(sc_RayTracingCasterConfiguration.y&65535u))
{
return;
}
vec3 l9_10=l9_9.xyz;
l9_6=l9_7.viewDirWS;
l9_5=l9_7.positionWS;
l9_4=l9_10;
l9_3=l9_8;
l9_2=cross(l9_8,l9_10)*l9_9.w;
l9_1=l9_7.uv0;
}
else
{
vec3 l9_11=normalize(varTangent.xyz);
vec3 l9_12=normalize(varNormalAndMotion.xyz);
l9_6=normalize(sc_Camera.position-varPosAndMotion.xyz);
l9_5=varPosAndMotion.xyz;
l9_4=l9_11;
l9_3=l9_12;
l9_2=cross(l9_12,l9_11)*varTangent.w;
l9_1=varTex01.xy;
}
vec4 l9_13;
#if (baseTexLayout==2)
{
bool l9_14=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_baseTex)!=0));
float l9_15=l9_1.x;
sc_SoftwareWrapEarly(l9_15,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x);
float l9_16=l9_15;
float l9_17=l9_1.y;
sc_SoftwareWrapEarly(l9_17,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y);
float l9_18=l9_17;
vec2 l9_19;
float l9_20;
#if (SC_USE_UV_MIN_MAX_baseTex)
{
bool l9_21;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_21=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x==3;
}
#else
{
l9_21=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_22=l9_16;
float l9_23=1.0;
sc_ClampUV(l9_22,baseTexUvMinMax.x,baseTexUvMinMax.z,l9_21,l9_23);
float l9_24=l9_22;
float l9_25=l9_23;
bool l9_26;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_26=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y==3;
}
#else
{
l9_26=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_27=l9_18;
float l9_28=l9_25;
sc_ClampUV(l9_27,baseTexUvMinMax.y,baseTexUvMinMax.w,l9_26,l9_28);
l9_20=l9_28;
l9_19=vec2(l9_24,l9_27);
}
#else
{
l9_20=1.0;
l9_19=vec2(l9_16,l9_18);
}
#endif
vec2 l9_29=sc_TransformUV(l9_19,(int(SC_USE_UV_TRANSFORM_baseTex)!=0),baseTexTransform);
float l9_30=l9_29.x;
float l9_31=l9_20;
sc_SoftwareWrapLate(l9_30,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x,l9_14,l9_31);
float l9_32=l9_29.y;
float l9_33=l9_31;
sc_SoftwareWrapLate(l9_32,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y,l9_14,l9_33);
float l9_34=l9_33;
vec3 l9_35=sc_SamplingCoordsViewToGlobal(vec2(l9_30,l9_32),baseTexLayout,baseTexGetStereoViewIndex());
vec4 l9_36=texture(baseTexArrSC,l9_35,0.0);
vec4 l9_37;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_37=mix(baseTexBorderColor,l9_36,vec4(l9_34));
}
#else
{
l9_37=l9_36;
}
#endif
l9_13=l9_37;
}
#else
{
bool l9_38=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_baseTex)!=0));
float l9_39=l9_1.x;
sc_SoftwareWrapEarly(l9_39,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x);
float l9_40=l9_39;
float l9_41=l9_1.y;
sc_SoftwareWrapEarly(l9_41,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y);
float l9_42=l9_41;
vec2 l9_43;
float l9_44;
#if (SC_USE_UV_MIN_MAX_baseTex)
{
bool l9_45;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_45=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x==3;
}
#else
{
l9_45=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_46=l9_40;
float l9_47=1.0;
sc_ClampUV(l9_46,baseTexUvMinMax.x,baseTexUvMinMax.z,l9_45,l9_47);
float l9_48=l9_46;
float l9_49=l9_47;
bool l9_50;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_50=ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y==3;
}
#else
{
l9_50=(int(SC_USE_CLAMP_TO_BORDER_baseTex)!=0);
}
#endif
float l9_51=l9_42;
float l9_52=l9_49;
sc_ClampUV(l9_51,baseTexUvMinMax.y,baseTexUvMinMax.w,l9_50,l9_52);
l9_44=l9_52;
l9_43=vec2(l9_48,l9_51);
}
#else
{
l9_44=1.0;
l9_43=vec2(l9_40,l9_42);
}
#endif
vec2 l9_53=sc_TransformUV(l9_43,(int(SC_USE_UV_TRANSFORM_baseTex)!=0),baseTexTransform);
float l9_54=l9_53.x;
float l9_55=l9_44;
sc_SoftwareWrapLate(l9_54,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).x,l9_38,l9_55);
float l9_56=l9_53.y;
float l9_57=l9_55;
sc_SoftwareWrapLate(l9_56,ivec2(SC_SOFTWARE_WRAP_MODE_U_baseTex,SC_SOFTWARE_WRAP_MODE_V_baseTex).y,l9_38,l9_57);
float l9_58=l9_57;
vec3 l9_59=sc_SamplingCoordsViewToGlobal(vec2(l9_54,l9_56),baseTexLayout,baseTexGetStereoViewIndex());
vec4 l9_60=texture(baseTex,l9_59.xy,0.0);
vec4 l9_61;
#if (SC_USE_CLAMP_TO_BORDER_baseTex)
{
l9_61=mix(baseTexBorderColor,l9_60,vec4(l9_58));
}
#else
{
l9_61=l9_60;
}
#endif
l9_13=l9_61;
}
#endif
vec4 l9_62;
#if (Tweak_N10Layout==2)
{
bool l9_63=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N10)!=0));
float l9_64=l9_1.x;
sc_SoftwareWrapEarly(l9_64,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x);
float l9_65=l9_64;
float l9_66=l9_1.y;
sc_SoftwareWrapEarly(l9_66,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y);
float l9_67=l9_66;
vec2 l9_68;
float l9_69;
#if (SC_USE_UV_MIN_MAX_Tweak_N10)
{
bool l9_70;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_70=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x==3;
}
#else
{
l9_70=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_71=l9_65;
float l9_72=1.0;
sc_ClampUV(l9_71,Tweak_N10UvMinMax.x,Tweak_N10UvMinMax.z,l9_70,l9_72);
float l9_73=l9_71;
float l9_74=l9_72;
bool l9_75;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_75=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y==3;
}
#else
{
l9_75=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_76=l9_67;
float l9_77=l9_74;
sc_ClampUV(l9_76,Tweak_N10UvMinMax.y,Tweak_N10UvMinMax.w,l9_75,l9_77);
l9_69=l9_77;
l9_68=vec2(l9_73,l9_76);
}
#else
{
l9_69=1.0;
l9_68=vec2(l9_65,l9_67);
}
#endif
vec2 l9_78=sc_TransformUV(l9_68,(int(SC_USE_UV_TRANSFORM_Tweak_N10)!=0),Tweak_N10Transform);
float l9_79=l9_78.x;
float l9_80=l9_69;
sc_SoftwareWrapLate(l9_79,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x,l9_63,l9_80);
float l9_81=l9_78.y;
float l9_82=l9_80;
sc_SoftwareWrapLate(l9_81,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y,l9_63,l9_82);
float l9_83=l9_82;
vec3 l9_84=sc_SamplingCoordsViewToGlobal(vec2(l9_79,l9_81),Tweak_N10Layout,Tweak_N10GetStereoViewIndex());
vec4 l9_85=texture(Tweak_N10ArrSC,l9_84,0.0);
vec4 l9_86;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_86=mix(Tweak_N10BorderColor,l9_85,vec4(l9_83));
}
#else
{
l9_86=l9_85;
}
#endif
l9_62=l9_86;
}
#else
{
bool l9_87=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N10)!=0));
float l9_88=l9_1.x;
sc_SoftwareWrapEarly(l9_88,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x);
float l9_89=l9_88;
float l9_90=l9_1.y;
sc_SoftwareWrapEarly(l9_90,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y);
float l9_91=l9_90;
vec2 l9_92;
float l9_93;
#if (SC_USE_UV_MIN_MAX_Tweak_N10)
{
bool l9_94;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_94=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x==3;
}
#else
{
l9_94=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_95=l9_89;
float l9_96=1.0;
sc_ClampUV(l9_95,Tweak_N10UvMinMax.x,Tweak_N10UvMinMax.z,l9_94,l9_96);
float l9_97=l9_95;
float l9_98=l9_96;
bool l9_99;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_99=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y==3;
}
#else
{
l9_99=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N10)!=0);
}
#endif
float l9_100=l9_91;
float l9_101=l9_98;
sc_ClampUV(l9_100,Tweak_N10UvMinMax.y,Tweak_N10UvMinMax.w,l9_99,l9_101);
l9_93=l9_101;
l9_92=vec2(l9_97,l9_100);
}
#else
{
l9_93=1.0;
l9_92=vec2(l9_89,l9_91);
}
#endif
vec2 l9_102=sc_TransformUV(l9_92,(int(SC_USE_UV_TRANSFORM_Tweak_N10)!=0),Tweak_N10Transform);
float l9_103=l9_102.x;
float l9_104=l9_93;
sc_SoftwareWrapLate(l9_103,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).x,l9_87,l9_104);
float l9_105=l9_102.y;
float l9_106=l9_104;
sc_SoftwareWrapLate(l9_105,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N10,SC_SOFTWARE_WRAP_MODE_V_Tweak_N10).y,l9_87,l9_106);
float l9_107=l9_106;
vec3 l9_108=sc_SamplingCoordsViewToGlobal(vec2(l9_103,l9_105),Tweak_N10Layout,Tweak_N10GetStereoViewIndex());
vec4 l9_109=texture(Tweak_N10,l9_108.xy,0.0);
vec4 l9_110;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N10)
{
l9_110=mix(Tweak_N10BorderColor,l9_109,vec4(l9_107));
}
#else
{
l9_110=l9_109;
}
#endif
l9_62=l9_110;
}
#endif
vec4 l9_111=l9_62*vec4(Port_Input1_N012);
float l9_112=floor(l9_111.x);
vec4 l9_113;
if (l9_112==0.0)
{
vec4 l9_114;
#if (normalTexLayout==2)
{
bool l9_115=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_normalTex)!=0));
float l9_116=l9_1.x;
sc_SoftwareWrapEarly(l9_116,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x);
float l9_117=l9_116;
float l9_118=l9_1.y;
sc_SoftwareWrapEarly(l9_118,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y);
float l9_119=l9_118;
vec2 l9_120;
float l9_121;
#if (SC_USE_UV_MIN_MAX_normalTex)
{
bool l9_122;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_122=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x==3;
}
#else
{
l9_122=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_123=l9_117;
float l9_124=1.0;
sc_ClampUV(l9_123,normalTexUvMinMax.x,normalTexUvMinMax.z,l9_122,l9_124);
float l9_125=l9_123;
float l9_126=l9_124;
bool l9_127;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_127=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y==3;
}
#else
{
l9_127=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_128=l9_119;
float l9_129=l9_126;
sc_ClampUV(l9_128,normalTexUvMinMax.y,normalTexUvMinMax.w,l9_127,l9_129);
l9_121=l9_129;
l9_120=vec2(l9_125,l9_128);
}
#else
{
l9_121=1.0;
l9_120=vec2(l9_117,l9_119);
}
#endif
vec2 l9_130=sc_TransformUV(l9_120,(int(SC_USE_UV_TRANSFORM_normalTex)!=0),normalTexTransform);
float l9_131=l9_130.x;
float l9_132=l9_121;
sc_SoftwareWrapLate(l9_131,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x,l9_115,l9_132);
float l9_133=l9_130.y;
float l9_134=l9_132;
sc_SoftwareWrapLate(l9_133,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y,l9_115,l9_134);
float l9_135=l9_134;
vec3 l9_136=sc_SamplingCoordsViewToGlobal(vec2(l9_131,l9_133),normalTexLayout,normalTexGetStereoViewIndex());
vec4 l9_137=texture(normalTexArrSC,l9_136,0.0);
vec4 l9_138;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_138=mix(normalTexBorderColor,l9_137,vec4(l9_135));
}
#else
{
l9_138=l9_137;
}
#endif
l9_114=l9_138;
}
#else
{
bool l9_139=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_normalTex)!=0));
float l9_140=l9_1.x;
sc_SoftwareWrapEarly(l9_140,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x);
float l9_141=l9_140;
float l9_142=l9_1.y;
sc_SoftwareWrapEarly(l9_142,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y);
float l9_143=l9_142;
vec2 l9_144;
float l9_145;
#if (SC_USE_UV_MIN_MAX_normalTex)
{
bool l9_146;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_146=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x==3;
}
#else
{
l9_146=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_147=l9_141;
float l9_148=1.0;
sc_ClampUV(l9_147,normalTexUvMinMax.x,normalTexUvMinMax.z,l9_146,l9_148);
float l9_149=l9_147;
float l9_150=l9_148;
bool l9_151;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_151=ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y==3;
}
#else
{
l9_151=(int(SC_USE_CLAMP_TO_BORDER_normalTex)!=0);
}
#endif
float l9_152=l9_143;
float l9_153=l9_150;
sc_ClampUV(l9_152,normalTexUvMinMax.y,normalTexUvMinMax.w,l9_151,l9_153);
l9_145=l9_153;
l9_144=vec2(l9_149,l9_152);
}
#else
{
l9_145=1.0;
l9_144=vec2(l9_141,l9_143);
}
#endif
vec2 l9_154=sc_TransformUV(l9_144,(int(SC_USE_UV_TRANSFORM_normalTex)!=0),normalTexTransform);
float l9_155=l9_154.x;
float l9_156=l9_145;
sc_SoftwareWrapLate(l9_155,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).x,l9_139,l9_156);
float l9_157=l9_154.y;
float l9_158=l9_156;
sc_SoftwareWrapLate(l9_157,ivec2(SC_SOFTWARE_WRAP_MODE_U_normalTex,SC_SOFTWARE_WRAP_MODE_V_normalTex).y,l9_139,l9_158);
float l9_159=l9_158;
vec3 l9_160=sc_SamplingCoordsViewToGlobal(vec2(l9_155,l9_157),normalTexLayout,normalTexGetStereoViewIndex());
vec4 l9_161=texture(normalTex,l9_160.xy,0.0);
vec4 l9_162;
#if (SC_USE_CLAMP_TO_BORDER_normalTex)
{
l9_162=mix(normalTexBorderColor,l9_161,vec4(l9_159));
}
#else
{
l9_162=l9_161;
}
#endif
l9_114=l9_162;
}
#endif
vec3 l9_163=(l9_114.xyz*1.9921875)-vec3(1.0);
l9_113=vec4(l9_163.x,l9_163.y,l9_163.z,l9_114.w);
}
else
{
vec4 l9_164;
if (l9_112==1.0)
{
vec2 l9_165=l9_1-Port_Center_N014;
vec2 l9_166=(l9_165*vec2(Tweak_N0))+Port_Center_N014;
vec4 l9_167;
#if (Tweak_N13Layout==2)
{
bool l9_168=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N13)!=0));
float l9_169=l9_166.x;
sc_SoftwareWrapEarly(l9_169,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x);
float l9_170=l9_169;
float l9_171=l9_166.y;
sc_SoftwareWrapEarly(l9_171,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y);
float l9_172=l9_171;
vec2 l9_173;
float l9_174;
#if (SC_USE_UV_MIN_MAX_Tweak_N13)
{
bool l9_175;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_175=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x==3;
}
#else
{
l9_175=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_176=l9_170;
float l9_177=1.0;
sc_ClampUV(l9_176,Tweak_N13UvMinMax.x,Tweak_N13UvMinMax.z,l9_175,l9_177);
float l9_178=l9_176;
float l9_179=l9_177;
bool l9_180;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_180=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y==3;
}
#else
{
l9_180=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_181=l9_172;
float l9_182=l9_179;
sc_ClampUV(l9_181,Tweak_N13UvMinMax.y,Tweak_N13UvMinMax.w,l9_180,l9_182);
l9_174=l9_182;
l9_173=vec2(l9_178,l9_181);
}
#else
{
l9_174=1.0;
l9_173=vec2(l9_170,l9_172);
}
#endif
vec2 l9_183=sc_TransformUV(l9_173,(int(SC_USE_UV_TRANSFORM_Tweak_N13)!=0),Tweak_N13Transform);
float l9_184=l9_183.x;
float l9_185=l9_174;
sc_SoftwareWrapLate(l9_184,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x,l9_168,l9_185);
float l9_186=l9_183.y;
float l9_187=l9_185;
sc_SoftwareWrapLate(l9_186,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y,l9_168,l9_187);
float l9_188=l9_187;
vec3 l9_189=sc_SamplingCoordsViewToGlobal(vec2(l9_184,l9_186),Tweak_N13Layout,Tweak_N13GetStereoViewIndex());
vec4 l9_190=texture(Tweak_N13ArrSC,l9_189,0.0);
vec4 l9_191;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_191=mix(Tweak_N13BorderColor,l9_190,vec4(l9_188));
}
#else
{
l9_191=l9_190;
}
#endif
l9_167=l9_191;
}
#else
{
bool l9_192=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N13)!=0));
float l9_193=l9_166.x;
sc_SoftwareWrapEarly(l9_193,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x);
float l9_194=l9_193;
float l9_195=l9_166.y;
sc_SoftwareWrapEarly(l9_195,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y);
float l9_196=l9_195;
vec2 l9_197;
float l9_198;
#if (SC_USE_UV_MIN_MAX_Tweak_N13)
{
bool l9_199;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_199=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x==3;
}
#else
{
l9_199=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_200=l9_194;
float l9_201=1.0;
sc_ClampUV(l9_200,Tweak_N13UvMinMax.x,Tweak_N13UvMinMax.z,l9_199,l9_201);
float l9_202=l9_200;
float l9_203=l9_201;
bool l9_204;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_204=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y==3;
}
#else
{
l9_204=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N13)!=0);
}
#endif
float l9_205=l9_196;
float l9_206=l9_203;
sc_ClampUV(l9_205,Tweak_N13UvMinMax.y,Tweak_N13UvMinMax.w,l9_204,l9_206);
l9_198=l9_206;
l9_197=vec2(l9_202,l9_205);
}
#else
{
l9_198=1.0;
l9_197=vec2(l9_194,l9_196);
}
#endif
vec2 l9_207=sc_TransformUV(l9_197,(int(SC_USE_UV_TRANSFORM_Tweak_N13)!=0),Tweak_N13Transform);
float l9_208=l9_207.x;
float l9_209=l9_198;
sc_SoftwareWrapLate(l9_208,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).x,l9_192,l9_209);
float l9_210=l9_207.y;
float l9_211=l9_209;
sc_SoftwareWrapLate(l9_210,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N13,SC_SOFTWARE_WRAP_MODE_V_Tweak_N13).y,l9_192,l9_211);
float l9_212=l9_211;
vec3 l9_213=sc_SamplingCoordsViewToGlobal(vec2(l9_208,l9_210),Tweak_N13Layout,Tweak_N13GetStereoViewIndex());
vec4 l9_214=texture(Tweak_N13,l9_213.xy,0.0);
vec4 l9_215;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N13)
{
l9_215=mix(Tweak_N13BorderColor,l9_214,vec4(l9_212));
}
#else
{
l9_215=l9_214;
}
#endif
l9_167=l9_215;
}
#endif
vec3 l9_216=(l9_167.xyz*1.9921875)-vec3(1.0);
l9_164=vec4(l9_216.x,l9_216.y,l9_216.z,l9_167.w);
}
else
{
vec4 l9_217;
if (l9_112==2.0)
{
vec2 l9_218=l9_1-Port_Center_N015;
vec2 l9_219=(l9_218*vec2(Tweak_N22))+Port_Center_N015;
vec4 l9_220;
#if (Tweak_N17Layout==2)
{
bool l9_221=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N17)!=0));
float l9_222=l9_219.x;
sc_SoftwareWrapEarly(l9_222,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x);
float l9_223=l9_222;
float l9_224=l9_219.y;
sc_SoftwareWrapEarly(l9_224,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y);
float l9_225=l9_224;
vec2 l9_226;
float l9_227;
#if (SC_USE_UV_MIN_MAX_Tweak_N17)
{
bool l9_228;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_228=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x==3;
}
#else
{
l9_228=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_229=l9_223;
float l9_230=1.0;
sc_ClampUV(l9_229,Tweak_N17UvMinMax.x,Tweak_N17UvMinMax.z,l9_228,l9_230);
float l9_231=l9_229;
float l9_232=l9_230;
bool l9_233;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_233=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y==3;
}
#else
{
l9_233=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_234=l9_225;
float l9_235=l9_232;
sc_ClampUV(l9_234,Tweak_N17UvMinMax.y,Tweak_N17UvMinMax.w,l9_233,l9_235);
l9_227=l9_235;
l9_226=vec2(l9_231,l9_234);
}
#else
{
l9_227=1.0;
l9_226=vec2(l9_223,l9_225);
}
#endif
vec2 l9_236=sc_TransformUV(l9_226,(int(SC_USE_UV_TRANSFORM_Tweak_N17)!=0),Tweak_N17Transform);
float l9_237=l9_236.x;
float l9_238=l9_227;
sc_SoftwareWrapLate(l9_237,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x,l9_221,l9_238);
float l9_239=l9_236.y;
float l9_240=l9_238;
sc_SoftwareWrapLate(l9_239,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y,l9_221,l9_240);
float l9_241=l9_240;
vec3 l9_242=sc_SamplingCoordsViewToGlobal(vec2(l9_237,l9_239),Tweak_N17Layout,Tweak_N17GetStereoViewIndex());
vec4 l9_243=texture(Tweak_N17ArrSC,l9_242,0.0);
vec4 l9_244;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_244=mix(Tweak_N17BorderColor,l9_243,vec4(l9_241));
}
#else
{
l9_244=l9_243;
}
#endif
l9_220=l9_244;
}
#else
{
bool l9_245=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N17)!=0));
float l9_246=l9_219.x;
sc_SoftwareWrapEarly(l9_246,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x);
float l9_247=l9_246;
float l9_248=l9_219.y;
sc_SoftwareWrapEarly(l9_248,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y);
float l9_249=l9_248;
vec2 l9_250;
float l9_251;
#if (SC_USE_UV_MIN_MAX_Tweak_N17)
{
bool l9_252;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_252=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x==3;
}
#else
{
l9_252=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_253=l9_247;
float l9_254=1.0;
sc_ClampUV(l9_253,Tweak_N17UvMinMax.x,Tweak_N17UvMinMax.z,l9_252,l9_254);
float l9_255=l9_253;
float l9_256=l9_254;
bool l9_257;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_257=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y==3;
}
#else
{
l9_257=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N17)!=0);
}
#endif
float l9_258=l9_249;
float l9_259=l9_256;
sc_ClampUV(l9_258,Tweak_N17UvMinMax.y,Tweak_N17UvMinMax.w,l9_257,l9_259);
l9_251=l9_259;
l9_250=vec2(l9_255,l9_258);
}
#else
{
l9_251=1.0;
l9_250=vec2(l9_247,l9_249);
}
#endif
vec2 l9_260=sc_TransformUV(l9_250,(int(SC_USE_UV_TRANSFORM_Tweak_N17)!=0),Tweak_N17Transform);
float l9_261=l9_260.x;
float l9_262=l9_251;
sc_SoftwareWrapLate(l9_261,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).x,l9_245,l9_262);
float l9_263=l9_260.y;
float l9_264=l9_262;
sc_SoftwareWrapLate(l9_263,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N17,SC_SOFTWARE_WRAP_MODE_V_Tweak_N17).y,l9_245,l9_264);
float l9_265=l9_264;
vec3 l9_266=sc_SamplingCoordsViewToGlobal(vec2(l9_261,l9_263),Tweak_N17Layout,Tweak_N17GetStereoViewIndex());
vec4 l9_267=texture(Tweak_N17,l9_266.xy,0.0);
vec4 l9_268;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N17)
{
l9_268=mix(Tweak_N17BorderColor,l9_267,vec4(l9_265));
}
#else
{
l9_268=l9_267;
}
#endif
l9_220=l9_268;
}
#endif
vec3 l9_269=(l9_220.xyz*1.9921875)-vec3(1.0);
l9_217=vec4(l9_269.x,l9_269.y,l9_269.z,l9_220.w);
}
else
{
vec2 l9_270=l9_1-Port_Center_N019;
vec2 l9_271=(l9_270*vec2(Tweak_N21))+Port_Center_N019;
vec4 l9_272;
#if (Tweak_N20Layout==2)
{
bool l9_273=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N20)!=0));
float l9_274=l9_271.x;
sc_SoftwareWrapEarly(l9_274,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x);
float l9_275=l9_274;
float l9_276=l9_271.y;
sc_SoftwareWrapEarly(l9_276,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y);
float l9_277=l9_276;
vec2 l9_278;
float l9_279;
#if (SC_USE_UV_MIN_MAX_Tweak_N20)
{
bool l9_280;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_280=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x==3;
}
#else
{
l9_280=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_281=l9_275;
float l9_282=1.0;
sc_ClampUV(l9_281,Tweak_N20UvMinMax.x,Tweak_N20UvMinMax.z,l9_280,l9_282);
float l9_283=l9_281;
float l9_284=l9_282;
bool l9_285;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_285=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y==3;
}
#else
{
l9_285=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_286=l9_277;
float l9_287=l9_284;
sc_ClampUV(l9_286,Tweak_N20UvMinMax.y,Tweak_N20UvMinMax.w,l9_285,l9_287);
l9_279=l9_287;
l9_278=vec2(l9_283,l9_286);
}
#else
{
l9_279=1.0;
l9_278=vec2(l9_275,l9_277);
}
#endif
vec2 l9_288=sc_TransformUV(l9_278,(int(SC_USE_UV_TRANSFORM_Tweak_N20)!=0),Tweak_N20Transform);
float l9_289=l9_288.x;
float l9_290=l9_279;
sc_SoftwareWrapLate(l9_289,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x,l9_273,l9_290);
float l9_291=l9_288.y;
float l9_292=l9_290;
sc_SoftwareWrapLate(l9_291,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y,l9_273,l9_292);
float l9_293=l9_292;
vec3 l9_294=sc_SamplingCoordsViewToGlobal(vec2(l9_289,l9_291),Tweak_N20Layout,Tweak_N20GetStereoViewIndex());
vec4 l9_295=texture(Tweak_N20ArrSC,l9_294,0.0);
vec4 l9_296;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_296=mix(Tweak_N20BorderColor,l9_295,vec4(l9_293));
}
#else
{
l9_296=l9_295;
}
#endif
l9_272=l9_296;
}
#else
{
bool l9_297=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0)&&(!(int(SC_USE_UV_MIN_MAX_Tweak_N20)!=0));
float l9_298=l9_271.x;
sc_SoftwareWrapEarly(l9_298,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x);
float l9_299=l9_298;
float l9_300=l9_271.y;
sc_SoftwareWrapEarly(l9_300,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y);
float l9_301=l9_300;
vec2 l9_302;
float l9_303;
#if (SC_USE_UV_MIN_MAX_Tweak_N20)
{
bool l9_304;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_304=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x==3;
}
#else
{
l9_304=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_305=l9_299;
float l9_306=1.0;
sc_ClampUV(l9_305,Tweak_N20UvMinMax.x,Tweak_N20UvMinMax.z,l9_304,l9_306);
float l9_307=l9_305;
float l9_308=l9_306;
bool l9_309;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_309=ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y==3;
}
#else
{
l9_309=(int(SC_USE_CLAMP_TO_BORDER_Tweak_N20)!=0);
}
#endif
float l9_310=l9_301;
float l9_311=l9_308;
sc_ClampUV(l9_310,Tweak_N20UvMinMax.y,Tweak_N20UvMinMax.w,l9_309,l9_311);
l9_303=l9_311;
l9_302=vec2(l9_307,l9_310);
}
#else
{
l9_303=1.0;
l9_302=vec2(l9_299,l9_301);
}
#endif
vec2 l9_312=sc_TransformUV(l9_302,(int(SC_USE_UV_TRANSFORM_Tweak_N20)!=0),Tweak_N20Transform);
float l9_313=l9_312.x;
float l9_314=l9_303;
sc_SoftwareWrapLate(l9_313,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).x,l9_297,l9_314);
float l9_315=l9_312.y;
float l9_316=l9_314;
sc_SoftwareWrapLate(l9_315,ivec2(SC_SOFTWARE_WRAP_MODE_U_Tweak_N20,SC_SOFTWARE_WRAP_MODE_V_Tweak_N20).y,l9_297,l9_316);
float l9_317=l9_316;
vec3 l9_318=sc_SamplingCoordsViewToGlobal(vec2(l9_313,l9_315),Tweak_N20Layout,Tweak_N20GetStereoViewIndex());
vec4 l9_319=texture(Tweak_N20,l9_318.xy,0.0);
vec4 l9_320;
#if (SC_USE_CLAMP_TO_BORDER_Tweak_N20)
{
l9_320=mix(Tweak_N20BorderColor,l9_319,vec4(l9_317));
}
#else
{
l9_320=l9_319;
}
#endif
l9_272=l9_320;
}
#endif
vec3 l9_321=(l9_272.xyz*1.9921875)-vec3(1.0);
l9_217=vec4(l9_321.x,l9_321.y,l9_321.z,l9_272.w);
}
l9_164=l9_217;
}
l9_113=l9_164;
}
vec4 l9_322;
#if (materialParamsTexLayout==2)
{
bool l9_323=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_materialParamsTex)!=0));
float l9_324=l9_1.x;
sc_SoftwareWrapEarly(l9_324,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x);
float l9_325=l9_324;
float l9_326=l9_1.y;
sc_SoftwareWrapEarly(l9_326,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y);
float l9_327=l9_326;
vec2 l9_328;
float l9_329;
#if (SC_USE_UV_MIN_MAX_materialParamsTex)
{
bool l9_330;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_330=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x==3;
}
#else
{
l9_330=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_331=l9_325;
float l9_332=1.0;
sc_ClampUV(l9_331,materialParamsTexUvMinMax.x,materialParamsTexUvMinMax.z,l9_330,l9_332);
float l9_333=l9_331;
float l9_334=l9_332;
bool l9_335;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_335=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y==3;
}
#else
{
l9_335=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_336=l9_327;
float l9_337=l9_334;
sc_ClampUV(l9_336,materialParamsTexUvMinMax.y,materialParamsTexUvMinMax.w,l9_335,l9_337);
l9_329=l9_337;
l9_328=vec2(l9_333,l9_336);
}
#else
{
l9_329=1.0;
l9_328=vec2(l9_325,l9_327);
}
#endif
vec2 l9_338=sc_TransformUV(l9_328,(int(SC_USE_UV_TRANSFORM_materialParamsTex)!=0),materialParamsTexTransform);
float l9_339=l9_338.x;
float l9_340=l9_329;
sc_SoftwareWrapLate(l9_339,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x,l9_323,l9_340);
float l9_341=l9_338.y;
float l9_342=l9_340;
sc_SoftwareWrapLate(l9_341,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y,l9_323,l9_342);
float l9_343=l9_342;
vec3 l9_344=sc_SamplingCoordsViewToGlobal(vec2(l9_339,l9_341),materialParamsTexLayout,materialParamsTexGetStereoViewIndex());
vec4 l9_345=texture(materialParamsTexArrSC,l9_344,0.0);
vec4 l9_346;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_346=mix(materialParamsTexBorderColor,l9_345,vec4(l9_343));
}
#else
{
l9_346=l9_345;
}
#endif
l9_322=l9_346;
}
#else
{
bool l9_347=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0)&&(!(int(SC_USE_UV_MIN_MAX_materialParamsTex)!=0));
float l9_348=l9_1.x;
sc_SoftwareWrapEarly(l9_348,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x);
float l9_349=l9_348;
float l9_350=l9_1.y;
sc_SoftwareWrapEarly(l9_350,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y);
float l9_351=l9_350;
vec2 l9_352;
float l9_353;
#if (SC_USE_UV_MIN_MAX_materialParamsTex)
{
bool l9_354;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_354=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x==3;
}
#else
{
l9_354=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_355=l9_349;
float l9_356=1.0;
sc_ClampUV(l9_355,materialParamsTexUvMinMax.x,materialParamsTexUvMinMax.z,l9_354,l9_356);
float l9_357=l9_355;
float l9_358=l9_356;
bool l9_359;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_359=ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y==3;
}
#else
{
l9_359=(int(SC_USE_CLAMP_TO_BORDER_materialParamsTex)!=0);
}
#endif
float l9_360=l9_351;
float l9_361=l9_358;
sc_ClampUV(l9_360,materialParamsTexUvMinMax.y,materialParamsTexUvMinMax.w,l9_359,l9_361);
l9_353=l9_361;
l9_352=vec2(l9_357,l9_360);
}
#else
{
l9_353=1.0;
l9_352=vec2(l9_349,l9_351);
}
#endif
vec2 l9_362=sc_TransformUV(l9_352,(int(SC_USE_UV_TRANSFORM_materialParamsTex)!=0),materialParamsTexTransform);
float l9_363=l9_362.x;
float l9_364=l9_353;
sc_SoftwareWrapLate(l9_363,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).x,l9_347,l9_364);
float l9_365=l9_362.y;
float l9_366=l9_364;
sc_SoftwareWrapLate(l9_365,ivec2(SC_SOFTWARE_WRAP_MODE_U_materialParamsTex,SC_SOFTWARE_WRAP_MODE_V_materialParamsTex).y,l9_347,l9_366);
float l9_367=l9_366;
vec3 l9_368=sc_SamplingCoordsViewToGlobal(vec2(l9_363,l9_365),materialParamsTexLayout,materialParamsTexGetStereoViewIndex());
vec4 l9_369=texture(materialParamsTex,l9_368.xy,0.0);
vec4 l9_370;
#if (SC_USE_CLAMP_TO_BORDER_materialParamsTex)
{
l9_370=mix(materialParamsTexBorderColor,l9_369,vec4(l9_367));
}
#else
{
l9_370=l9_369;
}
#endif
l9_322=l9_370;
}
#endif
vec3 l9_371;
#if (!sc_ProjectiveShadowsCaster)
{
l9_371=mat3(l9_4,l9_2,l9_3)*l9_113.xyz;
}
#else
{
l9_371=vec3(0.0);
}
#endif
float l9_372=clamp(l9_13.w,0.0,1.0);
#if (sc_BlendMode_AlphaTest)
{
if (l9_372<alphaTestThreshold)
{
discard;
}
}
#endif
#if (ENABLE_STIPPLE_PATTERN_TEST)
{
if (l9_372<((mod(dot(floor(mod(gl_FragCoord.xy,vec2(4.0))),vec2(4.0,1.0))*9.0,16.0)+1.0)/17.0))
{
discard;
}
}
#endif
vec3 l9_373=max(l9_13.xyz,vec3(0.0));
vec4 l9_374;
#if (sc_ProjectiveShadowsCaster)
{
l9_374=vec4(l9_373,l9_372);
}
#else
{
l9_374=ngsCalculateLighting(l9_373,l9_372,l9_371,l9_5,l9_6,Port_Emissive_N006,clamp(l9_322.x,0.0,1.0),clamp(l9_322.y,0.0,1.0),clamp(vec3(l9_322.z),vec3(0.0),vec3(1.0)),Port_SpecularAO_N006);
}
#endif
vec4 l9_375=max(l9_374,vec4(0.0));
vec4 l9_376=mix(l9_13,l9_375,vec4(l9_322.z));
if (l9_0)
{
vec4 l9_377;
#if (sc_RayTracingCasterForceOpaque)
{
vec4 l9_378=l9_376;
l9_378.w=1.0;
l9_377=l9_378;
}
#else
{
l9_377=l9_376;
}
#endif
sc_writeFragData0(max(l9_377,vec4(0.0)));
return;
}
vec4 l9_379;
#if (sc_ProjectiveShadowsCaster)
{
float l9_380;
#if (((sc_BlendMode_Normal||sc_BlendMode_AlphaToCoverage)||sc_BlendMode_PremultipliedAlphaHardware)||sc_BlendMode_PremultipliedAlphaAuto)
{
l9_380=l9_376.w;
}
#else
{
float l9_381;
#if (sc_BlendMode_PremultipliedAlpha)
{
l9_381=clamp(l9_376.w*2.0,0.0,1.0);
}
#else
{
float l9_382;
#if (sc_BlendMode_AddWithAlphaFactor)
{
l9_382=clamp(dot(l9_376.xyz,vec3(l9_376.w)),0.0,1.0);
}
#else
{
float l9_383;
#if (sc_BlendMode_AlphaTest)
{
l9_383=1.0;
}
#else
{
float l9_384;
#if (sc_BlendMode_Multiply)
{
l9_384=(1.0-dot(l9_376.xyz,vec3(0.33333001)))*l9_376.w;
}
#else
{
float l9_385;
#if (sc_BlendMode_MultiplyOriginal)
{
l9_385=(1.0-clamp(dot(l9_376.xyz,vec3(1.0)),0.0,1.0))*l9_376.w;
}
#else
{
float l9_386;
#if (sc_BlendMode_ColoredGlass)
{
l9_386=clamp(dot(l9_376.xyz,vec3(1.0)),0.0,1.0)*l9_376.w;
}
#else
{
float l9_387;
#if (sc_BlendMode_Add)
{
l9_387=clamp(dot(l9_376.xyz,vec3(1.0)),0.0,1.0);
}
#else
{
float l9_388;
#if (sc_BlendMode_AddWithAlphaFactor)
{
l9_388=clamp(dot(l9_376.xyz,vec3(1.0)),0.0,1.0)*l9_376.w;
}
#else
{
float l9_389;
#if (sc_BlendMode_Screen)
{
l9_389=dot(l9_376.xyz,vec3(0.33333001))*l9_376.w;
}
#else
{
float l9_390;
#if (sc_BlendMode_Min)
{
l9_390=1.0-clamp(dot(l9_376.xyz,vec3(1.0)),0.0,1.0);
}
#else
{
float l9_391;
#if (sc_BlendMode_Max)
{
l9_391=clamp(dot(l9_376.xyz,vec3(1.0)),0.0,1.0);
}
#else
{
l9_391=1.0;
}
#endif
l9_390=l9_391;
}
#endif
l9_389=l9_390;
}
#endif
l9_388=l9_389;
}
#endif
l9_387=l9_388;
}
#endif
l9_386=l9_387;
}
#endif
l9_385=l9_386;
}
#endif
l9_384=l9_385;
}
#endif
l9_383=l9_384;
}
#endif
l9_382=l9_383;
}
#endif
l9_381=l9_382;
}
#endif
l9_380=l9_381;
}
#endif
l9_379=vec4(mix(sc_ShadowColor.xyz,sc_ShadowColor.xyz*l9_376.xyz,vec3(sc_ShadowColor.w)),sc_ShadowDensity*l9_380);
}
#else
{
vec4 l9_392;
#if (sc_RenderAlphaToColor)
{
l9_392=vec4(l9_376.w);
}
#else
{
vec4 l9_393;
#if (sc_BlendMode_Custom)
{
vec3 l9_394=sc_GetFramebufferColor().xyz;
vec3 l9_395=mix(l9_394,definedBlend(l9_394,l9_376.xyz).xyz,vec3(l9_376.w));
vec4 l9_396=vec4(l9_395.x,l9_395.y,l9_395.z,vec4(0.0).w);
l9_396.w=1.0;
l9_393=l9_396;
}
#else
{
vec4 l9_397;
#if (sc_Voxelization)
{
l9_397=vec4(varScreenPos.xyz,1.0);
}
#else
{
vec4 l9_398;
#if (sc_OutputBounds)
{
float l9_399=clamp(abs(gl_FragCoord.z),0.0,1.0);
l9_398=vec4(l9_399,1.0-l9_399,1.0,1.0);
}
#else
{
vec4 l9_400;
#if (sc_BlendMode_MultiplyOriginal)
{
float l9_401=l9_376.w;
l9_400=vec4(mix(vec3(1.0),l9_376.xyz,vec3(l9_401)),l9_401);
}
#else
{
vec4 l9_402;
#if (sc_BlendMode_Screen||sc_BlendMode_PremultipliedAlphaAuto)
{
float l9_403=l9_376.w;
float l9_404;
#if (sc_BlendMode_PremultipliedAlphaAuto)
{
l9_404=clamp(l9_403,0.0,1.0);
}
#else
{
l9_404=l9_403;
}
#endif
l9_402=vec4(l9_376.xyz*l9_404,l9_404);
}
#else
{
l9_402=l9_376;
}
#endif
l9_400=l9_402;
}
#endif
l9_398=l9_400;
}
#endif
l9_397=l9_398;
}
#endif
l9_393=l9_397;
}
#endif
l9_392=l9_393;
}
#endif
l9_379=l9_392;
}
#endif
vec4 l9_405;
if (PreviewEnabled==1)
{
vec4 l9_406;
if (((PreviewVertexSaved*1.0)!=0.0) ? true : false)
{
l9_406=PreviewVertexColor;
}
else
{
l9_406=vec4(0.0);
}
l9_405=l9_406;
}
else
{
l9_405=l9_379;
}
vec4 l9_407=sc_OutputMotionVectorIfNeeded(max(l9_405,vec4(0.0)));
vec4 l9_408=clamp(l9_407,vec4(0.0),vec4(1.0));
#if (sc_OITDepthBoundsPass)
{
#if (sc_OITDepthBoundsPass)
{
float l9_409=clamp(viewSpaceDepth()/1000.0,0.0,1.0);
sc_writeFragData0(vec4(max(0.0,1.0-(l9_409-0.0039215689)),min(1.0,l9_409+0.0039215689),0.0,0.0));
}
#endif
}
#else
{
#if (sc_OITDepthPrepass)
{
sc_writeFragData0(vec4(1.0));
}
#else
{
#if (sc_OITDepthGatherPass)
{
#if (sc_OITDepthGatherPass)
{
vec2 l9_410=sc_ScreenCoordsGlobalToView(gl_FragCoord.xy*sc_CurrentRenderTargetDims.zw);
#if (sc_OITMaxLayers4Plus1)
{
if ((gl_FragCoord.z-texture(sc_OITFrontDepthTexture,l9_410).x)<=getFrontLayerZTestEpsilon())
{
discard;
}
}
#endif
int l9_411=encodeDepth(viewSpaceDepth(),texture(sc_OITFilteredDepthBoundsTexture,l9_410).xy);
float l9_412=packValue(l9_411);
int l9_419=int(l9_408.w*255.0);
float l9_420=packValue(l9_419);
sc_writeFragData0(vec4(packValue(l9_411),packValue(l9_411),packValue(l9_411),packValue(l9_411)));
}
#endif
}
#else
{
#if (sc_OITCompositingPass)
{
#if (sc_OITCompositingPass)
{
vec2 l9_423=sc_ScreenCoordsGlobalToView(gl_FragCoord.xy*sc_CurrentRenderTargetDims.zw);
#if (sc_OITMaxLayers4Plus1)
{
if ((gl_FragCoord.z-texture(sc_OITFrontDepthTexture,l9_423).x)<=getFrontLayerZTestEpsilon())
{
discard;
}
}
#endif
int l9_424[8];
int l9_425[8];
int l9_426=0;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_426<8)
{
l9_424[l9_426]=0;
l9_425[l9_426]=0;
l9_426++;
continue;
}
else
{
break;
}
}
int l9_427;
#if (sc_OITMaxLayers8)
{
l9_427=2;
}
#else
{
l9_427=1;
}
#endif
int l9_428=0;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_428<l9_427)
{
vec4 l9_429;
vec4 l9_430;
vec4 l9_431;
if (l9_428==0)
{
l9_431=texture(sc_OITAlpha0,l9_423);
l9_430=texture(sc_OITDepthLow0,l9_423);
l9_429=texture(sc_OITDepthHigh0,l9_423);
}
else
{
l9_431=vec4(0.0);
l9_430=vec4(0.0);
l9_429=vec4(0.0);
}
vec4 l9_432;
vec4 l9_433;
vec4 l9_434;
if (l9_428==1)
{
l9_434=texture(sc_OITAlpha1,l9_423);
l9_433=texture(sc_OITDepthLow1,l9_423);
l9_432=texture(sc_OITDepthHigh1,l9_423);
}
else
{
l9_434=l9_431;
l9_433=l9_430;
l9_432=l9_429;
}
if (any(notEqual(l9_432,vec4(0.0)))||any(notEqual(l9_433,vec4(0.0))))
{
int l9_435[8]=l9_424;
unpackValues(l9_432.w,l9_428,l9_435);
unpackValues(l9_432.z,l9_428,l9_435);
unpackValues(l9_432.y,l9_428,l9_435);
unpackValues(l9_432.x,l9_428,l9_435);
unpackValues(l9_433.w,l9_428,l9_435);
unpackValues(l9_433.z,l9_428,l9_435);
unpackValues(l9_433.y,l9_428,l9_435);
unpackValues(l9_433.x,l9_428,l9_435);
int l9_444[8]=l9_425;
unpackValues(l9_434.w,l9_428,l9_444);
unpackValues(l9_434.z,l9_428,l9_444);
unpackValues(l9_434.y,l9_428,l9_444);
unpackValues(l9_434.x,l9_428,l9_444);
}
l9_428++;
continue;
}
else
{
break;
}
}
vec4 l9_449=texture(sc_OITFilteredDepthBoundsTexture,l9_423);
vec2 l9_450=l9_449.xy;
int l9_451;
#if (sc_SkinBonesCount>0)
{
l9_451=encodeDepth(((1.0-l9_449.x)*1000.0)+getDepthOrderingEpsilon(),l9_450);
}
#else
{
l9_451=0;
}
#endif
int l9_452=encodeDepth(viewSpaceDepth(),l9_450);
vec4 l9_453;
l9_453=l9_408*l9_408.w;
vec4 l9_454;
int l9_455=0;
for (int snapLoopIndex=0; snapLoopIndex==0; snapLoopIndex+=0)
{
if (l9_455<8)
{
int l9_456=l9_424[l9_455];
int l9_457=l9_452-l9_451;
bool l9_458=l9_456<l9_457;
bool l9_459;
if (l9_458)
{
l9_459=l9_424[l9_455]>0;
}
else
{
l9_459=l9_458;
}
if (l9_459)
{
vec3 l9_460=l9_453.xyz*(1.0-(float(l9_425[l9_455])/255.0));
l9_454=vec4(l9_460.x,l9_460.y,l9_460.z,l9_453.w);
}
else
{
l9_454=l9_453;
}
l9_453=l9_454;
l9_455++;
continue;
}
else
{
break;
}
}
sc_writeFragData0(l9_453);
#if (sc_OITMaxLayersVisualizeLayerCount)
{
discard;
}
#endif
}
#endif
}
#else
{
#if (sc_OITFrontLayerPass)
{
#if (sc_OITFrontLayerPass)
{
if (abs(gl_FragCoord.z-texture(sc_OITFrontDepthTexture,sc_ScreenCoordsGlobalToView(gl_FragCoord.xy*sc_CurrentRenderTargetDims.zw)).x)>getFrontLayerZTestEpsilon())
{
discard;
}
sc_writeFragData0(l9_408);
}
#endif
}
#else
{
sc_writeFragData0(l9_407);
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif
}
#endif // #if SC_RT_RECEIVER_MODE
#endif // #elif defined FRAGMENT_SHADER // #if defined VERTEX_SHADER
