// ShoeTryOn.js
// Version : 12.0.0
// Event: -
// Description: Add virtual shoes to legs using feet tracking, target shoe removal, pants segmentation, virtual shoes placment.


// @input Asset.ObjectPrefab footControllerObject
// @input Asset.ObjectPrefab shoesRemoval
// @input Asset.Material lowerGarmentOccluder;

// @input SceneObject leftFootAnchor {"label" : "Left Foot"} 
// @input SceneObject rightFootAnchor {"label" : "Right Foot"}

//@ui {"widget":"separator"}
// @input bool useInpainting {"label" : "Erase Shoes","hint": "Use ML model to erase footwear. Please note that this may affect lens performance"}
// @input bool useOcclusion {"label" : "Occlude Feet","hint": "Use Segmentation texture to occlude foot attached objects. Please note that this may affect lens performance"}

//@ui {"widget":"separator"}
//@input bool advanced
//@input SceneObject eraserLayerReference  {"showIf": "advanced"}
//@input SceneObject occluderLayerReference  {"showIf": "advanced"}

const FEET_PREVIEW_POSITION = new vec3(10,0,0);

// Import module
var eventModule = require("./Scripts/EventModule");
var sceneObjectHelper = require("./Scripts/SceneObjectHelpersModule");
 
// Event Wrapper
if (!global.feetFoundEvent) {
    global.feetFoundEvent = new eventModule.EventWrapper();
    global.feetLostEvent = new eventModule.EventWrapper();
}

var feetFoundEvent = global.feetFoundEvent;
var feetLostEvent = global.feetLostEvent;    

if (!global.footTracking) {
    global.footTracking = {};
}


var targetFeetRemoval;
var targetFeetRemovalEffect;
var pantsSegmentationSO; 
var feetTracking;
var camera;
var isTracking = false;
var footController;

var minRenderOrder = 0;
var maxRenderOrder = 1;


/* Internal */
function checkTracking() {        
    if (footController && script.enabled) {        
        if (footController.isTracking() && !isTracking) { //tracking resumed         
            trackingFound();            
        } else if (!footController.isTracking() && isTracking) { //tracking lost
            trackingLost();
        }
    }
}

function getMinMaxRenderOrder() {            
    var getMinRO = function(mv) {
        minRenderOrder = Math.min(mv.getRenderOrder(), minRenderOrder);
        maxRenderOrder = Math.max(mv.getRenderOrder(), maxRenderOrder);
    };   
    sceneObjectHelper.getComponentsRecursive(script.leftFootAnchor, "Component.RenderMeshVisual").forEach(getMinRO);
    sceneObjectHelper.getComponentsRecursive(script.rightFootAnchor, "Component.RenderMeshVisual").forEach(getMinRO);        
}

function addOcclusion() {
    if (pantsSegmentationSO) {
        return;        
    }
    
    if (global.footTracking.pantsSegmentationSO) {        
        pantsSegmentationSO = global.footTracking.pantsSegmentationSO;
        pantsSegmentationSO.enabled = true;
        return;
    }
    
    pantsSegmentationSO = global.scene.createSceneObject("LGSegmentation");           
    
    var pantsSegmentationPostEffect = pantsSegmentationSO.createComponent("Component.PostEffectVisual");
    pantsSegmentationPostEffect.addMaterial(script.lowerGarmentOccluder);
    pantsSegmentationPostEffect.setRenderOrder(maxRenderOrder + 1);   
    // set layer to current CC layer
    if (script.occluderLayerReference) {
        pantsSegmentationSO.layer = script.occluderLayerReference.layer;
    } else {
        pantsSegmentationSO.layer = script.getSceneObject().layer;
    }
    
    
    global.footTracking.pantsSegmentationSO = pantsSegmentationSO;
}

function addInpainting() {
    if (targetFeetRemoval) {
        return;
    }
    
    if ("targetFeetRemoval" in global.footTracking) {           
        targetFeetRemoval = global.footTracking.targetFeetRemoval;        
        global.footTracking.targetFeetRemovalUsers++;
        global.footTracking.targetFeetRemovalEnabled++;
        targetFeetRemoval.enabled = true;
        return;
    }
    
    targetFeetRemoval = global.scene.createSceneObject("Shoe Removal");
    targetFeetRemovalEffect = script.shoesRemoval.instantiate(targetFeetRemoval);
    var targetFeetRemovalMV = targetFeetRemovalEffect.getComponent("Component.BaseMeshVisual");
    targetFeetRemovalMV.setRenderOrder(minRenderOrder - 1);        
    
    // set layer to current CC layer
    if (script.eraserLayerReference) {
        targetFeetRemovalEffect.layer = script.eraserLayerReference.layer;
    } else {
        targetFeetRemovalEffect.layer = script.getSceneObject().layer;
    }
    

    global.footTracking.targetFeetRemoval = targetFeetRemoval;    
    global.footTracking.targetFeetRemovalUsers = 1;
    global.footTracking.targetFeetRemovalEnabled = 1;
}


function initialize() {
    /* get reference to camera and parent scene object*/
    var parent = script.getSceneObject().getParent();
    if (!parent) {
        print("Warning: initialize shoe try on - place component as child of designated camera");        
        return;
    }
    camera = sceneObjectHelper.getComponentInParentRecursive(script.getSceneObject(), "Component.Camera");
    if (!camera) {
        print("Warning: initialize shoe try on - place component as child of designated camera");        
        return;
    }

    // create empty SO if no feet anchor attached
    if (!script.leftFootAnchor) {
        script.leftFootAnchor = global.scene.createSceneObject("leftFootAnchor");
        script.leftFootAnchor.setParent(camera.getSceneObject());        
    }
    
    if (!script.rightFootAnchor) {         
        script.rightFootAnchor = global.scene.createSceneObject("rightFootAnchor");
        script.rightFootAnchor.setParent(camera.getSceneObject());
    }
    
    // change position in order to show nicer on preview    
    script.leftFootAnchor.getTransform().setWorldPosition(FEET_PREVIEW_POSITION);
    script.rightFootAnchor.getTransform().setWorldPosition(FEET_PREVIEW_POSITION.uniformScale(-1));
  
    
    getMinMaxRenderOrder();

    /* add feet tracking */
    feetTracking = script.footControllerObject.instantiate(script.getSceneObject());   
    footController = feetTracking.getComponent("Component.ScriptComponent");        
    
    /* Callbacks */
    script.createEvent("OnDestroyEvent").bind(cleanUp);  
    script.createEvent("OnStartEvent").bind(onStart);    

    // add a function callback for each frame after feet ML is updated
    script.onTrackingUpdate = footController.onTrackingUpdate;
}

function onStart() {
    // instantiate these here so they won't appear in preview
    /* add shoe removal prefab*/
    if (script.useInpainting) {
        addInpainting();
    }    

    /* add pants segmentation */              
    if (script.useOcclusion) {
        addOcclusion();
    }

    // try this after component was instantiated    
    footController.camera = camera;
    footController.setShoes(script.leftFootAnchor, script.rightFootAnchor);
    footController.initialize();
    footController.onTrackingUpdate.add(checkTracking);    

    //disable shoes, they will be enabled when tracking starts    
    trackingState(false);

    script.createEvent("OnDisableEvent").bind(disable);
    script.createEvent("OnEnableEvent").bind(enable);  
}

/* remove instansiated objects */
function cleanUp() {
    if (!isNull(feetTracking)) {
        feetTracking.destroy();
    }
    if (!isNull(targetFeetRemoval)) {                
        global.footTracking.targetFeetRemovalUsers--;
        if (global.footTracking.targetFeetRemovalUsers == 0) { 
            targetFeetRemoval.destroy();            
        }
    }
    if (!isNull(pantsSegmentationSO)) {
        pantsSegmentationSO.destroy();
    }
                

    if (!isNull(footController) && footController.onTrackingUpdate) {
        footController.onTrackingUpdate.remove(checkTracking);
    }
}

/* disable instansiated objects and virtual shoes */
function disable() {    
    trackingState(false);
    footController.pause();

    if (pantsSegmentationSO) {
        pantsSegmentationSO.enabled = false;    
    }
    
    if (targetFeetRemoval) {
        global.footTracking.targetFeetRemovalEnabled--;        
        targetFeetRemoval.enabled = global.footTracking.targetFeetRemovalEnabled > 0;
    }
       
}

/* enable instansiated objects and virtual shoes */
function enable() {    
    trackingState(true);
    footController.resume();
    if (pantsSegmentationSO) {
        pantsSegmentationSO.enabled = true;    
    }
    
    if (targetFeetRemoval) {
        global.footTracking.targetFeetRemovalEnabled++;
        targetFeetRemoval.enabled = true;
    }
    
}

/* act according to tracking state */
function trackingState(state) {    
    isTracking = state;          
    if (targetFeetRemoval) {
        targetFeetRemoval.enabled = state && script.useInpainting;
    }
    setShoes(state);
}

/* set shoes assets*/
function setShoes(state) {
    if (script.leftFootAnchor) { 
        script.leftFootAnchor.getTransform().setWorldScale(new vec3(0.1,0.1,0.1));
        script.leftFootAnchor.enabled = state;        
    }
    if (script.rightFootAnchor) {
        script.rightFootAnchor.getTransform().setWorldScale(new vec3(0.1,0.1,0.1));
        script.rightFootAnchor.enabled = state;
    }
}

function trackingLost() {
    trackingState(false);    
    feetLostEvent.trigger(script);
}

function trackingFound() {        
    trackingState(true);
    feetFoundEvent.trigger(script);
}

/*API*/
//#region API
script.setShoes = function(leftShoe, rightShoe) {
    if (!leftShoe.uniqueIdentifier || !rightShoe.uniqueIdentifier) {
        print("Warning: Make sure both shoes are valid scene objects before trying to call setShoes");
        return; 
    }
    footController.setShoes(script.leftFootAnchor, script.rightFootAnchor);    
};
    
script.isTracking = function() {
    return isTracking;
};

Object.defineProperty(script, "leftFoot", {
    get: function() {
        return script.leftFootAnchor; 
    },
    set: function(sceneObject) {               
        script.leftFootAnchor = sceneObject;
        footController.setShoes(script.leftFootAnchor, script.rightFootAnchor);
    }
});


Object.defineProperty(script, "rightFoot", {
    get: function() {
        return script.rightFootAnchor; 
    },
    set: function(sceneObject) {       
        script.rightFootAnchor = sceneObject;
        footController.setShoes(script.leftFootAnchor, script.rightFootAnchor);   
    }
});

Object.defineProperty(script, "eraseFeet", {
    get: function() {
        return script.useInpainting; 
    },
    set: function(state) {       
        script.useInpainting = state; 
        if (state) {
            addInpainting();
        }    
        if (targetFeetRemoval) {
            targetFeetRemoval.enabled = isTracking && state;    
        } 
    }
});

Object.defineProperty(script, "occludeFeet", {
    get: function() {
        return script.useOcclusion; 
    },
    set: function(state) {       
        script.useOcclusion = state; 
        if (state) {
            addOcclusion();
        }    
        if (pantsSegmentationSO) {
            pantsSegmentationSO.enabled = state;    
        } 
    }
});

script.setEraserLayer = function(layer) {
    targetFeetRemovalEffect.layer = layer;
};

script.setOccluderLayer = function(layer) {
    pantsSegmentationSO.layer = layer;
};
//#endregion API

initialize();

// events
script.feetFoundEvent = feetFoundEvent;
script.feetLostEvent = feetLostEvent;