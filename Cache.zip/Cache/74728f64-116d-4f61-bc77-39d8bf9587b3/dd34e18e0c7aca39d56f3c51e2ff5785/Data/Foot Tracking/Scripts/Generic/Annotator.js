

var DecoderLib = require("./GenericDecoders");

var AnnotatorLib = {};

var FootAnnotator = function(modelConfig) {
    this.cfg = modelConfig;
    this.previous_instances = [];

    if (this.cfg.decoder_set === "HE_LE1") {
        if (this.cfg.outputCenterClassName === "MP_CENTER_GAUSSIANS") {
            this.center_decoder = new DecoderLib.ShoeCenterGaussDetectDecoder(modelConfig);
        } else {
            this.center_decoder = new DecoderLib.ShoeCenterDetectDecoder(modelConfig);
        }
        this.center_track_decoder = new DecoderLib.CenterTrackDecoder(modelConfig);
        this.center_match_decoder = new DecoderLib.CenterKeypointMatchingDecoder(modelConfig);
        this.integral_keypoint_decoder = new DecoderLib.IntegralKeypointDecoder(modelConfig);
        this.sparse_lr_decoder = new DecoderLib.SparseLeftRightDecoder(modelConfig);
        this.center_hysteresis_decoder = new DecoderLib.CenterHysteresisDecoder(modelConfig);

    } else if (this.cfg.decoder_set === "LE2") {
        this.gaussian_keypoint_decoder = new DecoderLib.GaussianKeypointDecoder(modelConfig);
        this.sparse_lr_decoder = new DecoderLib.SparseLeftRightDecoder(modelConfig);
        this.sample_seg_decoder = new DecoderLib.JointSampleSegmentationDecoder(modelConfig);
    }
};

FootAnnotator.prototype = {
    annotate: function(mlComponent) {
        var annotation = {};
        if (this.cfg.decoder_set === "HE_LE1") {
            annotation["previous_instances"] = this.previous_instances;
            annotation = this.center_decoder.decode_centers(mlComponent, annotation);
            this.center_track_decoder.decode_track_centers(mlComponent, annotation);
            this.center_hysteresis_decoder.decode_hysteresis_center(mlComponent, annotation);
            this.integral_keypoint_decoder.decode_keypoints(mlComponent, annotation);
            this.sparse_lr_decoder.decode_sparse_lr(mlComponent, annotation);
            this.center_match_decoder.decode_match(mlComponent, annotation);
            this.previous_instances = this.create_previous_instances_list(annotation);
        } else if (this.cfg.decoder_set === "LE2") {
            this.gaussian_keypoint_decoder.decode_keypoints(mlComponent, annotation);
            this.sample_seg_decoder.decode_sample_segmentation(mlComponent, annotation);
            this.sparse_lr_decoder.decode_sparse_lr(mlComponent, annotation);
        }
        return annotation;
    },

    create_previous_instances_list: function(annotation) {
        var new_instances = [];
        var seen_ids = [];
        for (var i = 0; i < annotation["instances"].length; ++i) {
            new_instances.push(annotation["instances"][i]);
            seen_ids.push(annotation["instances"].id);
        }

        for (var i = 0; i < annotation["previous_instances"].length; ++i) {
            if (!annotation["previous_instances"][i].matched) {
                annotation["previous_instances"][i].age += 1;
                if (annotation["previous_instances"][i].age < this.cfg.memory_cliff && seen_ids.indexOf(annotation["previous_instances"][i].id)===-1) {
                    new_instances.push(annotation["previous_instances"][i]);
                }
            }
        }

        return new_instances;
    },
};

AnnotatorLib.FootAnnotator = FootAnnotator;

module.exports.version = "1.0.0";
module.exports.FootAnnotator = FootAnnotator;