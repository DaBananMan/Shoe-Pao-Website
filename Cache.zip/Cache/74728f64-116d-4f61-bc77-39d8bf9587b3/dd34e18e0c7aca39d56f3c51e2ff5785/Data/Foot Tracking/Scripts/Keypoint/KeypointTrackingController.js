// TrackingController.js
// Version: 0.0.1
// Event: Lens Initialized
// Description: Tracking controller for foot bindings

// @input SceneObject leftFoot
// @input SceneObject rightFoot
// @input bool advanced = false

// @ui {"widget":"group_start", "label":"Settings", "showIf" : "advanced"}
// @input Component.MLComponent mlComponent
// @input Asset.MLAsset mlAsset
// @input Asset.Texture deviceTexture
// @ui {"widget":"group_end"}

const AnnotatorLib = require("../Generic/Annotator");
const sceneObjectHelper = require("../SceneObjectHelpersModule");
const OpticalFlow = require("./OpticalFlow");
const Solver = require("./Solver");
const MathLib = require("../Generic/NewJSMathLibrary");
const HelperLib = require("../Generic/GenericHelperScript");
const eventModule = require("../EventModule");
// NOTE: values assigned here will override remote config
var modelConfig = {};

var isTracking = false;
var onTrackingUpdate = new eventModule.EventWrapper();
var isInit = false;
var isPaused = false;

script.onTrackingUpdate = onTrackingUpdate;

/** Add slice function to Float32 and Uint8Array
 * https://stackoverflow.com/a/31898534
 * */
if (!Float32Array.prototype.slice) {
    Float32Array.prototype.slice = function(begin, end) {
        var target = new Float32Array(end - begin);

        for (var i = 0; i < begin + end; ++i) {
            target[i] = this[begin + i];
        }
        return target;
    };
}

var SIZE;
var SIZE2;
const TYPE = {
    LEFT: 0,
    RIGHT: 1
};

var allPointsShape;

var isFirstFrame = true;

var trackingCamera = null;

var opticalFlow = null;
var smoothStep = null;

var annotator = null;
var solver = [null, null];
var mlComponent = null;
var mlAsset = null;

var outputVisibilitiesTensor = null;
var outputVisibilitiesTensorShape = null;
var visibilityMask = null;
var prevVisibilityMask = null;

var outTensor = null;
var outTensorLeft = null;
var outTensorRight = null;
var annotations = null;

var prevOutTensor = null;
var newOutTensor = null;
var maxProbabilities = null;

var TrackingCamera = function(camera) {
    this.camera = camera;
    this.cameraSize = null;
    this.intrinsics = null;
};

TrackingCamera.prototype = {
    update: function() {
        this.cameraSize = new vec2(script.deviceTexture.getWidth(), script.deviceTexture.getHeight());

        this.intrinsics = MathLib.makeIntrinsicsMatrix(this.cameraSize, this.camera.fov);
    },
    calcCameraSize: function() {
        return new vec2(script.deviceTexture.getWidth(), script.deviceTexture.getHeight());
    }
};

function initOpticalFlow() {
    allPointsShape = new vec3(2, SIZE2, 1);
    smoothStep = new OpticalFlow.SmoothStep();
    smoothStep.resize(SIZE2);  // both left and right keypoints!
    opticalFlow = new OpticalFlow.OpticalFlow(modelConfig);
}

function createSolver(type) {
    solver[type] = new Solver.Solver(modelConfig, type, modelConfig.keypoints3d_left);
    solver[type].resize(SIZE);
    solver[type].camera = trackingCamera;
    solver[type].invalidateFoot();
}

function copy_left_points(all_points, left_points) {
    for (var k = 0; k < SIZE2; ++k) {
        left_points[k] = all_points[k];
    }
}

function copy_right_points(all_points, right_points) {
    for (var k = 0; k < SIZE2; ++k) {
        right_points[k] = all_points[k + SIZE2];
    }
}

function processOutputData() {
    annotations = annotator.annotate(mlComponent);

    visibilityMask = annotations["model_keypoints_vis"];
    outTensor = annotations["model_keypoints"];

    solver[TYPE.LEFT].addVisibilityMask(visibilityMask.slice(0, SIZE), 1.0);
    solver[TYPE.RIGHT].addVisibilityMask(visibilityMask.slice(SIZE, SIZE2), 1.0);
}

function onCameraChanged() {
    var curCameraSize = trackingCamera.calcCameraSize();
    if (trackingCamera.cameraSize.x === curCameraSize.x && trackingCamera.cameraSize.y === curCameraSize.y) {
        if (trackingCamera.cameraFov !== trackingCamera.camera.fov) {
            trackingCamera.update();
        }
        return;
    }

    trackingCamera.update();

    if (opticalFlow != null && opticalFlow.textureSize != null) {
        opticalFlow.initializeTexture(script.deviceTexture);
    }
}

function initCamera() {
    script.camera = sceneObjectHelper.getComponentInParentRecursive(script.getSceneObject(), "Component.Camera");
    if (! script.camera) {
        print("Warning: initialize shoe try on - place component as child of designated camera");
        return;
    }

    trackingCamera = new TrackingCamera(script.camera);
    trackingCamera.update();

    script.createEvent("CameraFrontEvent").bind(onCameraChanged);
    script.createEvent("CameraBackEvent").bind(onCameraChanged);
}

function build_ML_generic(strech_flag) {
    /**
     * This function builds the ML model from the asset, using the model's inputs and outputs. Works with
     * one input and an arbitrary number of outputs and output resolutions. Using the input argument
     * stretch_flag we can set whether the input image will be stretched to the model size or just
     * resized and padded.
     *
     * (Based on the code provided here:
     * https://docs.google.com/document/d/101S_wiJ1atYZZVQxbuoGytyk_787I___D-ficS0v4I4/edit#bookmark=id.lc2kxkh2bken)
     */

    var list_of_model_inputs_outputs = [];

    var imageInputShape = mlComponent.getInput(modelConfig.inputName).shape;
    var transformer = MachineLearning.createTransformerBuilder().setStretch(strech_flag).build();
    var imageInput = MachineLearning.createInputBuilder().setName(modelConfig.inputName)
        .setShape(imageInputShape).setInputTexture(script.deviceTexture)
        .setTransformer(transformer).build();
    list_of_model_inputs_outputs.push(imageInput);

    var list_of_model_outputs = mlComponent.getOutputs();

    for (var i = 0; i < list_of_model_outputs.length; i++) {
        var cur_output_name = list_of_model_outputs[i].name;
        var cur_output_shape = mlComponent.getOutput(cur_output_name).shape;
        var cur_output = MachineLearning.createOutputBuilder().setName(cur_output_name)
            .setShape(cur_output_shape).setOutputMode(MachineLearning.OutputMode.Data).build();
        list_of_model_inputs_outputs.push(cur_output);
    }
    mlComponent.renderOrder = 1;
    mlComponent.inferenceMode = MachineLearning.InferenceMode.Auto;
    mlComponent.build(list_of_model_inputs_outputs);
}

function onLoaded() {
    var data = mlComponent.getInput(modelConfig.inputName);
    data.texture = script.deviceTexture;

    modelConfig.textureSize = new vec2(data.shape.x, data.shape.y);
    modelConfig.inputWidth = data.shape.x;
    modelConfig.inputHeight = data.shape.y;

    outputVisibilitiesTensor = mlComponent.getOutput(modelConfig.outputVisibilitiesName).data;  // 160 x 192 x 16
    outputVisibilitiesTensorShape = mlComponent.getOutput(modelConfig.outputVisibilitiesName).shape;  // 160 x 192 x 16

    SIZE = outputVisibilitiesTensorShape.z / 2;
    SIZE2 = SIZE * 2;

    outTensor = new Float32Array(SIZE2 * 2);
    outTensorLeft = new Float32Array(SIZE2);
    outTensorRight = new Float32Array(SIZE2);

    prevOutTensor = new Float32Array(SIZE2 * 2);
    newOutTensor = new Float32Array(SIZE2 * 2);

    maxProbabilities = new Float32Array(SIZE2);
    visibilityMask = new Uint8Array(SIZE2); // 16 x 1, has visibility 0 or 1 values for every keypoint
    prevVisibilityMask = new Uint8Array(SIZE2); // 16 x 1, has visibility 0 or 1 values for every keypoint

    initAfterMlLoaded();

    mlComponent.onRunningFinished = onUpdate;
    mlComponent.runScheduled(true, MachineLearning.FrameTiming.Update, MachineLearning.FrameTiming.Update);
}

function getModelMetadata(input_mlComponent, input_mlAsset) {
    var component_modelConfig;
    if (input_mlComponent) { //Getting metadata from mlComponent.model !!
        component_modelConfig = mlComponent.model.getMetadata();
    } else if (input_mlAsset) { //Getting metadata from mlAsset !!
        component_modelConfig = input_mlAsset.getMetadata();
    }

    if (component_modelConfig) {
        modelConfig = component_modelConfig;
        modelConfig.optical_flow.WIN_SIZE_OPT_FLOW = new vec2(
            modelConfig.optical_flow.WIN_SIZE_OPT_FLOW[0],
            modelConfig.optical_flow.WIN_SIZE_OPT_FLOW[1]
        );

        modelConfig.textureSize = new vec2(
            modelConfig.textureSize[0], modelConfig.textureSize[1]);
    }

    SIZE = modelConfig.keypoints3d_left.length / 3;
    SIZE2 = SIZE * 2;
}

function initMLComponent() {
    mlComponent = script.mlComponent;
    mlComponent.onLoadingFinished = onLoaded;
    mlAsset = script.mlAsset;
    mlComponent.model = mlAsset;
    getModelMetadata(null, mlAsset);
    build_ML_generic(false);
}

function onUpdate() {
    processOutputData();
    script.rightFoot.enabled = false;
    script.leftFoot.enabled = false;
    isTracking = false;

    if (isPaused) {
        return;
    }

    if ((solver[TYPE.LEFT] && !solver[TYPE.LEFT].isFootVisible) &&
        (solver[TYPE.RIGHT] && !solver[TYPE.RIGHT].isFootVisible)) {
        onTrackingUpdate.trigger();
        return;
    }

    isTracking = true;
    onCameraChanged(); //this is here to handle zoom changes

    var crop_width = modelConfig.textureSize.x;
    var crop_height = modelConfig.textureSize.y;
    var image_width = script.camera.renderTarget.getWidth();
    var image_height = script.camera.renderTarget.getHeight();

    if (isFirstFrame) {
        opticalFlow.initializeTexture(script.deviceTexture);
        isFirstFrame = false;
    }

    for (var i = 0; i < SIZE2; i++) {
        var texture_vec = new vec2(outTensor[2 * i], outTensor[2 * i + 1]);
        var screenPosition2D = HelperLib.tex2img_coords(texture_vec, image_width, image_height, crop_width, crop_height);
        outTensor[2 * i] = screenPosition2D.x;
        outTensor[2 * i + 1] = screenPosition2D.y;
    }

    opticalFlow.apply(
        prevOutTensor,
        newOutTensor,
        allPointsShape
    );

    for (var j = 0; j < SIZE2; ++j) {
        /** if at previous frame the point was invisible then use detection instead of optical flow!*/
        if (prevVisibilityMask[j] == 0) {
            newOutTensor[j * 2] = outTensor[j * 2];
            newOutTensor[j * 2 + 1] = outTensor[j * 2 + 1];
        }
    }

    /** Mix optical flow and detections*/
    smoothStep.apply(
        prevOutTensor,
        outTensor,
        newOutTensor
    );

    prevOutTensor.set(outTensor, 0);
    prevVisibilityMask.set(visibilityMask, 0);

    copy_left_points(outTensor, outTensorLeft);
    copy_right_points(outTensor, outTensorRight);

    if (solver[TYPE.LEFT] && solver[TYPE.LEFT].isFootVisible && solver[TYPE.RIGHT] && solver[TYPE.RIGHT].isFootVisible) {
        var b1 = MathLib.makeBoundingBox(outTensorLeft, solver[TYPE.LEFT].visibilityMask);
        var b2 = MathLib.makeBoundingBox(outTensorRight, solver[TYPE.RIGHT].visibilityMask);

        if (MathLib.isBoxIntersection(b1, b2)) { // HANDLE OVERLAP
            var intersection = MathLib.getBoxIntersection(b1, b2);
            var b1Area = MathLib.getBoxArea(b1);
            var b2Area = MathLib.getBoxArea(b2);
            var intersectionArea = MathLib.getBoxArea(intersection);
            if (intersectionArea / b1Area > modelConfig.kOverlayThreshold ||
                intersectionArea / b2Area > modelConfig.kOverlayThreshold) {
                if (b1Area > modelConfig.kOverlayGreaterThreshold * b2Area) {
                    solver[TYPE.RIGHT].invalidateFoot();
                } else if (b2Area > modelConfig.kOverlayGreaterThreshold * b1Area) {
                    solver[TYPE.LEFT].invalidateFoot();
                } else {
                    TensorMath.max(outputVisibilitiesTensor, outputVisibilitiesTensorShape, maxProbabilities);
                    var leftProb = 1.0;
                    for (var m = 0; m < SIZE; ++m) {
                        leftProb *= maxProbabilities[m];
                    }
                    var rightProb = 1.0;
                    for (var n = SIZE; n < 2 * SIZE; ++n) {
                        rightProb *= maxProbabilities[n];
                    }

                    if (leftProb < rightProb) {
                        solver[TYPE.LEFT].invalidateFoot();
                    } else {
                        solver[TYPE.RIGHT].invalidateFoot();
                    }
                }
            }
        }
    }

    var transform;
    if (solver[TYPE.LEFT] && solver[TYPE.LEFT].isFootVisible) {
        transform = solver[TYPE.LEFT].apply(outTensorLeft);
        if (solver[TYPE.LEFT].isFootVisible) {
            script.leftFoot.getTransform().setWorldPosition(transform[0]);
            script.leftFoot.getTransform().setWorldRotation(transform[1]);
            script.leftFoot.enabled = true;
        }
    }

    if (solver[TYPE.RIGHT] && solver[TYPE.RIGHT].isFootVisible) {
        transform = solver[TYPE.RIGHT].apply(outTensorRight);
        if (solver[TYPE.RIGHT].isFootVisible) {
            script.rightFoot.getTransform().setWorldPosition(transform[0]);
            script.rightFoot.getTransform().setWorldRotation(transform[1]);
            script.rightFoot.enabled = true;
        }
    }

    onTrackingUpdate.trigger();
}

function initAfterMlLoaded() {
    annotator = new AnnotatorLib.FootAnnotator(modelConfig);
    initCamera();
    initOpticalFlow();

    createSolver(TYPE.LEFT);
    createSolver(TYPE.RIGHT);
    isInit = true;
}

function init() {
    initMLComponent();
}

script.setShoes = function(_leftShoe, _rightShoe) {
    script.leftFoot = _leftShoe;
    script.rightFoot = _rightShoe;
};

script.initialize = init;
script.isTracking = function() {
    return isTracking;
};

script.pause = function() {
    if (!isInit) {
        return;
    }
    isPaused = true;
    mlComponent.runScheduled(false, MachineLearning.FrameTiming.Update, MachineLearning.FrameTiming.Update);
};

script.resume = function() {
    if (!isInit) {
        return;
    }
    isPaused = false;
    mlComponent.runScheduled(true, MachineLearning.FrameTiming.Update, MachineLearning.FrameTiming.Update);
};