// MLEraser.js
// Version: 0.3.0

// @input Asset.Texture inputMask
var inputMask = script.inputMask;

// @input Asset.MLAsset mlAsset
// @input float eraserMix = 1 {"widget":"slider", "min":0.0, "max":1.0, "step":0.001}
var eraserMix = script.eraserMix;

// @input Asset.Material outputMaterial

// @input bool advanced
// @ui {"widget" : "separator", "showIf":"advanced"}

// @input Asset.Texture imageInputTexture {"showIf":"advanced"}
// @input bool useFallback {"showIf":"advanced"}
// @input int startingRenderOrder = -10 {"showIf":"advanced", "label": "Render Order"}

// @input Asset.Material maskRTMaterial
// @input Asset.Material simpleScreenMaterial

//@input Asset.ObjectPrefab fallbackShaderEraser

var maskRT, eraserScript, mlComponent, postEffect, dontUseMLInpainting;
var featureInput, expCoeffInput, featureOutput, prevTexture, prevMaskTexture, prevMaskRT, prevTexRT;

var expCoeffData = new Float32Array(1);
expCoeffData[0] = 0.5; // Wil be set by meta-info if exists

mlComponent = script.getSceneObject().createComponent("Component.MLComponent");
postEffect = script.getSceneObject().createComponent("Component.PostEffectVisual");
postEffect.addMaterial(script.outputMaterial);
postEffect.enabled = false;
postEffect.renderOrder = -1;

function setupInputMask(renderOrder) {
    script.maskRTMaterial.mainPass.inputMask = inputMask;
    // Setup input mask
    maskRT = createRenderTarget(true);
    var maskCam = createCamera(maskRT, renderOrder, "maskRT");
    var maskPostEffect = createPostEffect(maskCam.renderLayer, script.maskRTMaterial, renderOrder, "maskRT");
    maskPostEffect.setParent(maskCam.getSceneObject());
    script.outputMaterial.mainPass.opacityTex = maskRT;
}


function setupMLComponent(
    imageInputShape,
    previmageInputShape,
    maskInputShape,
    predictedOutputShape,
    featureShapes,
    smoothFeatures,
    renderOrder) {
    var transformer = MachineLearning.createTransformerBuilder().setStretch(true).build();
    // Inputs
    var imageInput = MachineLearning.createInputBuilder().setName("image")
        .setShape(imageInputShape).setInputTexture(script.imageInputTexture)
        .setTransformer(transformer).build();

    var maskInput = MachineLearning.createInputBuilder().setName("mask")
        .setShape(maskInputShape).setInputTexture(maskRT)
        .setTransformer(transformer).build();

    var prevMaskInput = MachineLearning.createInputBuilder().setName("prev_mask")
        .setShape(maskInputShape).setInputTexture(prevMaskRT)
        .setTransformer(transformer).build();

    expCoeffInput = undefined;
    try {
        // Here we expect mlComponent to have input "exp_coeff".
        // In case it doesn't, an exception will be 
        // thrown, so we catch it and leave expCoeffInput
        // undefined
        mlComponent.getInput("exp_coeff");
        expCoeffInput = (MachineLearning.
            createInputBuilder().
            setName("exp_coeff").
            setShape(new vec3(1, 1, 1)).
            build());
    } catch (error) {
        // We need a statement here.
        // Otherwise the error is not cought
        // because Javascript is problematic
        print("");
    }

    var prevImageInput = MachineLearning.createInputBuilder().setName("prev_image")
        .setShape(previmageInputShape).setInputTexture(prevImageRT)
        .setTransformer(transformer).build();

    featureInputs = [];
    featureOutputs = [];

    smoothFeatures.forEach(function(x, i) {
        var prev = x[0];
        var curr = x[1];
        var shape = featureShapes[i];

        featureInputs.push(
            MachineLearning.
            createInputBuilder().
            setName(prev).
            setShape(shape).
            build());

        featureOutputs.push(
            MachineLearning.
            createOutputBuilder().
            setName(curr).
            setShape(shape).
            build());
    });

    // Outputs
    var predictedOutput = MachineLearning.createOutputBuilder().setName("predicted")
        .setShape(predictedOutputShape).setOutputMode(MachineLearning.OutputMode.Texture).build();


    mlComponent.renderOrder = renderOrder;
    mlComponent.onLoadingFinished = onLoadingFinished;
    var buildList = [];
    buildList.push(imageInput);
    buildList.push(maskInput);
    featureInputs.forEach(function(fIn) {
        buildList.push(fIn);
    });
    buildList.push(prevImageInput);
    buildList.push(prevMaskInput);

    if (expCoeffInput) {
        buildList.push(expCoeffInput);
    }

    featureOutputs.forEach(function(fOut) {
        buildList.push(fOut);
    });
    buildList.push(predictedOutput);


    mlComponent.build(buildList);
}


function createPostEffect(renderLayer, material, renderOrder, name) {
    var postEffectObject = global.scene.createSceneObject(name +" Post Effect");
    var postEffectComponent = postEffectObject.createComponent("Component.PostEffectVisual");

    postEffectObject.layer = renderLayer;

    postEffectComponent.clearMaterials();
    postEffectComponent.addMaterial(material);
    postEffectComponent.setRenderOrder(renderOrder);

    return postEffectObject;
}

function createRenderTarget(fullScreen) {
    var renderTarget = global.scene.createRenderTargetTexture();
    renderTarget.control.useScreenResolution = fullScreen;

    renderTarget.control.clearColor = new vec4(0.0, 0.0, 0.0, 0.0);
    renderTarget.control.clearDepthEnabled = false;
    renderTarget.control.fxaa = false;
    renderTarget.control.msaa = false;
    return renderTarget;
}

function createCamera(renderTargets, renderOrder, name) {
  
    var cameraObject = global.scene.createSceneObject("Camera " + name);
    var cameraComponent = cameraObject.createComponent("Component.Camera");
    cameraComponent.enabled = true;

    cameraComponent.renderLayer = LayerSet.makeUnique();
    cameraComponent.near = 1.0;
    cameraComponent.far = 1000.0;
    cameraComponent.devicePropertyUsage = Camera.DeviceProperty.All;
    cameraComponent.renderOrder = renderOrder;
    cameraComponent.renderTarget = renderTargets;
    return cameraComponent;
}


function initialize() {
    if (!inputMask) {
        print("[ML Eraser] Warning: input mask is required")
        return;
    }        
    
    mlComponent.model = script.mlAsset;
    prevTexture = script.imageInputTexture;
    // Set render order: render cur mask then ml component and the latest is prev mask - 
    // to render the current mask as next interation prev mask
    
    // This needs to happen before mlComponent run in order to get mask of current frame    
    var curMaskRenderOrder = script.startingRenderOrder;
    var mlComponentRenderOrder = curMaskRenderOrder + 1;
    // This needs to happen after mlComponent run in order to have a delay of one frame
    // When using prevFrame as input to mlComponent
    var prevFrameRenderingOrder = mlComponentRenderOrder + 1;
    setupInputMask(curMaskRenderOrder);
    
    try {
        dontUseMLInpainting = mlComponent.model.getMetadata()["dont_use_ml_inpainting"];        
    } catch (error) {                
        dontUseMLInpainting = true;
    }
    
    if (script.useFallback || dontUseMLInpainting) {        
        postEffect.enabled = false;
    }
    else {
        // Read smooth features def
        try {
            const metaData = mlComponent.model.getMetadata();
            smoothFeatures = metaData['smoothFeatures'];

            if (!smoothFeatures) {
                smoothFeatures = [["prev_feat_1", "cur_feat_1"]];
            }
        } catch(error) {
            smoothFeatures = [["prev_feat_1", "cur_feat_1"]];
        }


        // Read expCoeff data
        try {
            const metaData = mlComponent.model.getMetadata();
            const x = metaData["expCoeff"];
            if (x) {
                expCoeffData[0] = x;
            }
        } catch (error) {
        }

        var imageInputShape = mlComponent.getInput("image").shape;
        var maskInputShape = mlComponent.getInput("mask").shape;
        
        var previmageInputShape = mlComponent.getInput("prev_image").shape;

        var featureShapes = [];
        smoothFeatures.forEach(function(x) {
            var prev = x[0];
            var curr = x[1];
            featureShapes.push(mlComponent.getInput(prev).shape);
        });

        var predictedOutputShape = mlComponent.getOutput("predicted").shape;
        
        // Setup prev input mask
        prevMaskRT = createRenderTarget(true);
        var prevMaskCam = createCamera(prevMaskRT, prevFrameRenderingOrder, "prevMaskRT");
        var prevMaskMaterial = script.maskRTMaterial;
        var prevMaskRTPostEffect = createPostEffect(prevMaskCam.renderLayer, prevMaskMaterial, prevFrameRenderingOrder,"prevMaskRT");
        prevMaskRTPostEffect.setParent(prevMaskCam.getSceneObject());

        // Setup prev input image
        prevImageRT = createRenderTarget(true);
        var prevImageCam = createCamera(prevImageRT, prevFrameRenderingOrder, "prevImageRT");
        var prevImageMaterial = script.simpleScreenMaterial.clone();
        prevImageMaterial.mainPass.baseTex0 = script.imageInputTexture;
        var prevImagePostEffect = createPostEffect(prevImageCam.renderLayer, prevImageMaterial, prevFrameRenderingOrder,"prevImageRT");
        prevImagePostEffect.setParent(prevImageCam.getSceneObject());

        setupMLComponent(
            imageInputShape,
            previmageInputShape,
            maskInputShape,
            predictedOutputShape,
            featureShapes,
            smoothFeatures,
            mlComponentRenderOrder);
    }
    createShaderEraser(); // enable shader by default
       
    script.eraserMix = eraserMix;
    
    script.createEvent("OnDestroyEvent").bind(onDestroy);
    script.createEvent("OnEnableEvent").bind(onEnable);
    script.createEvent("OnDisableEvent").bind(onDisable);
    
}

// This funciton should be call
// before runing the network on the first time
// Since we don't want to blend first
function resetExpCoeff() {
    var data = new Float32Array(1);
    data[0] = 1000;
    if (expCoeffInput){
        expCoeffInput.data.set(data);
    }
}

function onLoadingFinished() {
    script.outputMaterial.mainPass.baseTex = mlComponent.getOutput("predicted").texture;
    postEffect.enabled = true;
    if (eraserScript) {
        eraserScript.disableEraser();
    }

    resetExpCoeff();
    mlComponent.runScheduled(true, MachineLearning.FrameTiming.OnRender, MachineLearning.FrameTiming.OnRender);

    mlComponent.onRunningFinished = function() {    
        featureInputs.forEach(function(fIn, i) {
            const fOut = featureOutputs[i];
            fIn.data.set(fOut.data);
        });

        if (expCoeffInput) {
            expCoeffInput.data.set(expCoeffData);
        }

    }
}

function createShaderEraser() {
    var eraser = script.fallbackShaderEraser.instantiate(script.getSceneObject());
    eraserScript = eraser.getComponent("Component.ScriptComponent");    
    eraserScript.initWithTexture(maskRT);
}

function onDestroy() {   
    mlComponent.enabled = false;
    postEffect.enabled = false;
    
    if (dontUseMLInpainting || script.useFallback) {        
        if (eraserScript) {            
            eraserScript.disableEraser();
            eraserScript.getSceneObject().destroy();
        }
    }    
}

function onEnable() {
    resetExpCoeff();
    mlComponent.enabled = true;
    postEffect.enabled = true;

    if (dontUseMLInpainting || script.useFallback) {
        if (eraserScript) {
            eraserScript.enableEraser();
        }
    }
}

function onDisable() {
    mlComponent.enabled = false;
    postEffect.enabled = false;

    if (dontUseMLInpainting || script.useFallback) {
        if (eraserScript) {
            eraserScript.disableEraser();
        }
    }
}

script.createEvent("OnStartEvent").bind(initialize);


// API 
Object.defineProperty(script, "inputMask", {
    get: function() {
        return script.maskRTMaterial.mainPass.inputMask; 
    },
    set: function(inputTex) {
        script.maskRTMaterial.mainPass.inputMask = inputTex;
    }
});

Object.defineProperty(script, "eraserMix", {
    get: function() {
        return script.outputMaterial.mainPass.opacity; 
    },
    set: function(mix) {        
        script.outputMaterial.mainPass.opacity = mix;
        if (eraserScript) {
           eraserScript.eraserMix = mix;
        }
    }
});
